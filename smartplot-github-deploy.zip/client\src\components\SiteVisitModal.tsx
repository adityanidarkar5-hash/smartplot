import React, { useState } from 'react';
import { X, Calendar, User, Phone, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { Venture, Plot, Appointment, Language } from '../types';
import { translations } from '../i18n';
import { api } from '../api';
import { syncAppointmentToFirebase } from '../firebase';

interface SiteVisitModalProps {
  isOpen: boolean;
  onClose: () => void;
  ventures: Venture[];
  initialVentureId?: number;
  initialPlot?: Plot | null;
  currentLang?: Language;
}

export const SiteVisitModal: React.FC<SiteVisitModalProps> = ({
  isOpen,
  onClose,
  ventures,
  initialVentureId,
  initialPlot,
  currentLang = 'en',
}) => {
  if (!isOpen) return null;

  const t = translations[currentLang];

  const [ventureId, setVentureId] = useState<number>(initialVentureId || (ventures[0]?.id || 1));
  const [plotNumber, setPlotNumber] = useState<string>(initialPlot?.plot_number || '');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDateStr = tomorrow.toISOString().split('T')[0];
  
  const [preferredDate, setPreferredDate] = useState(minDateStr);
  const [timeSlot, setTimeSlot] = useState('10:00 AM');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedAppointment, setSavedAppointment] = useState<Appointment | null>(null);

  const timeSlots = [
    '10:00 AM',
    '11:30 AM',
    '02:00 PM',
    '04:00 PM',
    '05:30 PM'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!customerName.trim() || !customerPhone.trim()) {
      setError(currentLang === 'te' ? 'దయచేసి మీ పేరు మరియు ఫోన్ నెంబర్ నమోదు చేయండి.' : 'Please enter your name and mobile number.');
      return;
    }

    const cleanedPhone = customerPhone.replace(/\D/g, '');
    if (cleanedPhone.length < 10) {
      setError(currentLang === 'te' ? 'సరైన 10 అంకెల మొబైల్ నెంబర్ నమోదు చేయండి.' : 'Please enter a valid 10-digit mobile number.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.bookAppointment({
        venture_id: Number(ventureId),
        plot_id: initialPlot?.id || null,
        plot_number: plotNumber || null,
        customer_name: customerName,
        customer_phone: customerPhone,
        preferred_date: preferredDate,
        time_slot: timeSlot,
      });

      setSavedAppointment(res.appointment);

      // Firebase Cloud Sync (mirrors site visit lead to Cloud Firestore)
      syncAppointmentToFirebase({
        venture_id: Number(ventureId),
        plot_number: plotNumber || undefined,
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        preferred_date: preferredDate,
        time_slot: timeSlot,
        reference_code: res.appointment?.reference_code || 'BNV-VISIT',
      });
    } catch (err: any) {
      setError(err.message || 'Failed to submit appointment request.');
    } finally {
      setLoading(false);
    }
  };

  const selectedVentureObj = ventures.find(v => v.id === Number(ventureId));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border-2 border-emerald-500 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-navy-950 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-white/70 hover:text-white p-1 rounded-full hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-wider mb-1">
            <Calendar className="w-4 h-4" /> B.N Ventures
          </div>
          <h3 className="font-display font-black text-2xl text-white">
            {t.siteVisitTitle}
          </h3>
          <p className="text-emerald-100 text-xs mt-1">
            {t.siteVisitSubtitle}
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {savedAppointment ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
                  {currentLang === 'te' ? 'సైట్ విజిట్ ఖరారైంది' : 'Site Visit Confirmed'}
                </span>
                <h4 className="font-display font-black text-2xl text-navy-950 pt-2">
                  {currentLang === 'te' ? 'అపాయింట్‌మెంట్ నమోదైంది!' : 'Appointment Scheduled!'}
                </h4>
                <p className="text-sm text-navy-600">
                  {currentLang === 'te'
                    ? `${savedAppointment.customer_name} గారు, మీ అభ్యర్థన విజయవంతంగా నమోదైంది. మా వెంచర్ కోఆర్డినేటర్ మీకు కాల్ చేస్తారు.`
                    : `Thank you, ${savedAppointment.customer_name}. Your visit has been logged.`}
                </p>
              </div>

              {/* Saved Details Box */}
              <div className="bg-slate-50 border border-navy-200 rounded-2xl p-4 text-left space-y-2 text-xs">
                <div className="flex justify-between items-center border-b border-navy-200 pb-2">
                  <span className="text-navy-500 font-bold">Booking Ref ID:</span>
                  <span className="font-mono font-black text-sm text-emerald-700 bg-white px-2 py-0.5 rounded border border-emerald-300">
                    {savedAppointment.reference_code}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-navy-500 font-medium">Venture:</span>
                  <strong className="text-navy-900">{selectedVentureObj?.name}</strong>
                </div>
                {savedAppointment.plot_number && (
                  <div className="flex justify-between items-center">
                    <span className="text-navy-500 font-medium">Plot:</span>
                    <strong className="text-navy-900">Plot {savedAppointment.plot_number}</strong>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-navy-500 font-medium">Date & Time:</span>
                  <strong className="text-navy-900">{savedAppointment.preferred_date} at {savedAppointment.time_slot}</strong>
                </div>
              </div>

              <button
                onClick={onClose}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-6 rounded-xl transition shadow-md text-xs sm:text-sm"
              >
                {currentLang === 'te' ? 'ముగించు (Close)' : 'Close Window'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              {/* Venture & Plot Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {currentLang === 'te' ? 'వెంచర్ ఎంచుకోండి *' : 'Select Venture *'}
                  </label>
                  <select
                    value={ventureId}
                    onChange={(e) => setVentureId(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2 text-xs sm:text-sm font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {ventures.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.city})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {currentLang === 'te' ? 'ప్లాట్ నెంబర్ (ఐచ్ఛికం)' : 'Plot # (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={plotNumber}
                    onChange={(e) => setPlotNumber(e.target.value)}
                    placeholder="e.g. P-104"
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2 text-xs sm:text-sm font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {t.fullName} *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-navy-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. K. Satyanarayana"
                      className="w-full bg-slate-50 border border-navy-200 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {t.phoneNumber} *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-navy-400 absolute left-3 top-3" />
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="10-digit mobile"
                      className="w-full bg-slate-50 border border-navy-200 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Date & Time Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {t.visitDate} *
                  </label>
                  <input
                    type="date"
                    required
                    min={minDateStr}
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {t.timeSlot} *
                  </label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2 text-xs sm:text-sm font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm disabled:opacity-50"
              >
                {loading ? 'Submitting...' : t.submitVisit}
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-[11px] text-center text-navy-500">
                {currentLang === 'te' 
                  ? 'పూర్తిగా ఉచిత వాహన రవాణా సదుపాయం కల్పించబడుతుంది.' 
                  : 'Complimentary chauffeured pickup & site drop arranged by B.N Ventures.'}
              </p>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
