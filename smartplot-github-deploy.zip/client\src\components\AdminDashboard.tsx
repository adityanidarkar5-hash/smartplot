import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  Mail, 
  Key, 
  BarChart3, 
  Layers, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  LogOut, 
  Edit,
  Edit3, 
  Trash2, 
  Plus, 
  Search, 
  Filter, 
  Check, 
  X, 
  MessageSquare, 
  DollarSign,
  TrendingUp,
  RefreshCw,
  Eye,
  EyeOff,
  Sparkles,
  Video,
  Image as ImageIcon,
  Save,
  Link,
  Award,
  UserCheck,
  Building2,
  Download,
  Upload,
  FileCode,
  Copy,
  FileText,
  ExternalLink,
  MapPin,
  Grid,
  Sliders,
  Compass,
  Flame,
  Rotate3d,
  ZoomIn,
  ZoomOut
} from 'lucide-react';
import { Plot, Venture, Appointment, Booking, Enquiry, AdminMetrics, PlotStatus, VentureVideo } from '../types';
import { api } from '../api';
import { ThreeDPlotView } from './ThreeDPlotView';

interface AdminDashboardProps {
  onBackToSite: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToSite }) => {
  // Auth state
  const [hasAdmin, setHasAdmin] = useState<boolean | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [adminUser, setAdminUser] = useState<any>(null);

  // Owner Security Vault Login State (Strict Two-Factor Protection)
  const [ownerPassword, setOwnerPassword] = useState<string>('');
  const [ownerVerificationCode, setOwnerVerificationCode] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(false);

  // Owner Security Management Modal State
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState<boolean>(false);
  const [securityModalData, setSecurityModalData] = useState({ password: '', verification_code: '' });
  const [securityUpdateSuccess, setSecurityUpdateSuccess] = useState<string | null>(null);
  const [securityUpdateLoading, setSecurityUpdateLoading] = useState<boolean>(false);

  // Dashboard state
  const [activeTab, setActiveTab] = useState<'overview' | 'ventures' | 'plots' | 'media' | 'appointments' | 'bookings' | 'enquiries' | 'security'>('overview');
  const [metrics, setMetrics] = useState<AdminMetrics | null>(null);
  const [plots, setPlots] = useState<Plot[]>([]);
  const [ventures, setVentures] = useState<Venture[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [securityLogs, setSecurityLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState<boolean>(false);
  const [loadingData, setLoadingData] = useState<boolean>(false);

  // Venture Management & Import State (Admin Only)
  const [editingVenture, setEditingVenture] = useState<Venture | null>(null);
  const [isAddVentureOpen, setIsAddVentureOpen] = useState(false);
  const [newVentureForm, setNewVentureForm] = useState<Partial<Venture>>({
    name: '',
    slug: '',
    tagline: '',
    tagline_te: '',
    location: '',
    location_te: '',
    district: 'Nirmal',
    district_te: 'నిర్మల్ జిల్లా',
    pincode: '504106',
    city: 'Nirmal',
    city_te: 'నిర్మల్',
    state: 'Telangana',
    description: '',
    description_te: '',
    price_per_sqyd_min: 11500,
    price_per_sqyd_max: 16500,
    total_plots: 36,
    status: 'Open for Booking',
    status_te: 'బుకింగ్ అందుబాటులో ఉంది',
    hero_image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
    rera_number: 'RERA/TEL/NIRMAL/2026/0504',
    map_embed_url: ''
  });

  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [importLoading, setImportLoading] = useState(false);
  const [importMessage, setImportMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // 2D Layout & Venture Studio State (Requirement: Admin 2D layout photo upload, 3D conceptual view & Code insertion)
  const [isLayoutStudioOpen, setIsLayoutStudioOpen] = useState(false);
  const [studioPreviewMode, setStudioPreviewMode] = useState<'2d' | '3d' | 'blueprint'>('2d');
  const [studioTab, setStudioTab] = useState<'photo' | 'code'>('photo');
  const [studioJsonCode, setStudioJsonCode] = useState('');
  const [studioCodeError, setStudioCodeError] = useState<string | null>(null);
  const [studioCodeSuccess, setStudioCodeSuccess] = useState<string | null>(null);
  const [studioVenture, setStudioVenture] = useState({
    name: 'B.N Nirmal Greenfield County Phase 2',
    slug: 'bn-nirmal-greenfield-phase-2',
    district: 'Nirmal',
    district_te: 'నిర్మల్ జిల్లా',
    pincode: '504106',
    city: 'Nirmal',
    city_te: 'నిర్మల్',
    state: 'Telangana',
    location: 'NH-44 Bypass & Mancherial Road, Nirmal',
    location_te: 'NH-44 బైపాస్ & మంచిర్యాల రోడ్డు, నిర్మల్',
    tagline: 'DTCP & RERA Approved Luxury Villa Layout in Nirmal District',
    tagline_te: 'నిర్మల్ జిల్లాలో DTCP మరియు RERA అనుమతి పొందిన లేఅవుట్',
    description: 'Premier DTCP approved plotted venture in Nirmal with 40ft blacktop roads, underground cabling, Vaastu compliance, and spot registration.',
    description_te: 'నిర్మల్ పట్టణానికి సమీపంలో 40 అడుగుల రోడ్లు, భూగర్భ విద్యుత్, తాగునీటి సరఫరా మరియు స్పష్టమైన టైటిల్ డాక్యుమెంట్లు కలిగిన ప్లాట్లు.',
    price_per_sqyd_min: 12500,
    price_per_sqyd_max: 16500,
    status: 'Open for Booking',
    status_te: 'బుకింగ్ అందుబాటులో ఉంది',
    hero_image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
    rera_number: 'RERA/TEL/NIRMAL/2026/0504',
    layout_image_url: ''
  });

  const [studioRows, setStudioRows] = useState(3);
  const [studioCols, setStudioCols] = useState(12);
  const [studioDefaultArea, setStudioDefaultArea] = useState(200);
  const [studioDefaultFacing, setStudioDefaultFacing] = useState<'East' | 'West' | 'North' | 'South'>('East');
  const [studioStartPlotNum, setStudioStartPlotNum] = useState(101);
  const [studioPlots, setStudioPlots] = useState<any[]>([]);
  const [studioSelectedPlotIndex, setStudioSelectedPlotIndex] = useState<number | null>(null);
  const [isUploadingLayout, setIsUploadingLayout] = useState(false);
  const [studioSaving, setStudioSaving] = useState(false);
  const [studioUploadMessage, setStudioUploadMessage] = useState<string | null>(null);

  const syncStudioToJson = (v = studioVenture, p = studioPlots) => {
    const obj = {
      venture: {
        name: v.name,
        slug: v.slug,
        district: v.district,
        district_te: v.district_te,
        pincode: v.pincode,
        city: v.city,
        city_te: v.city_te,
        state: v.state,
        location: v.location,
        location_te: v.location_te,
        tagline: v.tagline,
        tagline_te: v.tagline_te,
        description: v.description,
        description_te: v.description_te,
        price_per_sqyd_min: v.price_per_sqyd_min,
        price_per_sqyd_max: v.price_per_sqyd_max,
        total_plots: p.length,
        status: v.status,
        status_te: v.status_te,
        hero_image: v.hero_image,
        rera_number: v.rera_number,
        layout_image_url: v.layout_image_url
      },
      plots: p
    };
    const json = JSON.stringify(obj, null, 2);
    setStudioJsonCode(json);
    return json;
  };

  const handleApplyCodeToStudio = () => {
    setStudioCodeError(null);
    setStudioCodeSuccess(null);
    try {
      const parsed = JSON.parse(studioJsonCode);
      const v = parsed.venture || parsed;
      if (!v.name || !v.location) {
        throw new Error('Venture must contain at least "name" and "location".');
      }
      const updatedVenture = {
        name: v.name || studioVenture.name,
        slug: v.slug || studioVenture.slug,
        district: v.district || 'Nirmal',
        district_te: v.district_te || 'నిర్మల్ జిల్లా',
        pincode: v.pincode || '504106',
        city: v.city || 'Nirmal',
        city_te: v.city_te || 'నిర్మల్',
        state: v.state || 'Telangana',
        location: v.location || studioVenture.location,
        location_te: v.location_te || v.location || studioVenture.location_te,
        tagline: v.tagline || studioVenture.tagline,
        tagline_te: v.tagline_te || studioVenture.tagline_te,
        description: v.description || studioVenture.description,
        description_te: v.description_te || studioVenture.description_te,
        price_per_sqyd_min: Number(v.price_per_sqyd_min) || studioVenture.price_per_sqyd_min,
        price_per_sqyd_max: Number(v.price_per_sqyd_max) || studioVenture.price_per_sqyd_max,
        status: v.status || 'Open for Booking',
        status_te: v.status_te || 'బుకింగ్ అందుబాటులో ఉంది',
        hero_image: v.hero_image || studioVenture.hero_image,
        rera_number: v.rera_number || studioVenture.rera_number,
        layout_image_url: v.layout_image_url || studioVenture.layout_image_url || ''
      };
      setStudioVenture(updatedVenture);

      const parsedPlots = Array.isArray(parsed.plots) ? parsed.plots : (Array.isArray(v.plots) ? v.plots : null);
      if (parsedPlots && parsedPlots.length > 0) {
        setStudioPlots(parsedPlots);
        setStudioSelectedPlotIndex(0);
      } else {
        generateStudioGrid(studioRows, studioCols, studioDefaultArea, studioDefaultFacing, studioStartPlotNum, updatedVenture.price_per_sqyd_min);
      }
      setStudioCodeSuccess(`✓ Successfully inserted 2D layout with ${parsedPlots ? parsedPlots.length : (studioRows * studioCols)} plots! Website has automatically generated the 3D view.`);
    } catch (err: any) {
      setStudioCodeError('Code format error: ' + err.message);
    }
  };

  const handleLoadExampleCode = () => {
    const example = {
      venture: {
        name: "B.N Nirmal Royal Meadows Phase 3",
        slug: "bn-nirmal-royal-meadows-phase-3",
        district: "Nirmal",
        district_te: "నిర్మల్ జిల్లా",
        pincode: "504106",
        city: "Nirmal",
        city_te: "నిర్మల్",
        state: "Telangana",
        location: "NH-44 Bypass & Nirmal Collectorate Road",
        location_te: "NH-44 బైపాస్ & నిర్మల్ కలెక్టరేట్ రోడ్డు",
        tagline: "DTCP & RERA Approved Luxury Villa Layout in Nirmal District",
        tagline_te: "నిర్మల్ జిల్లాలో DTCP మరియు RERA అనుమతి పొందిన లేఅవుట్",
        description: "DTCP and RERA approved ultra-premium gated plotted development in Nirmal District with 40ft blacktop roads, underground electrification, solar street lights, and instant spot registration.",
        description_te: "నిర్మల్ జిల్లా కేంద్రానికి సమీపంలో 40 అడుగుల రోడ్లు, భూగర్భ డ్రైనేజ్, వీధి దీపాలు, వాస్తు ప్రకారం వేసిన ప్లాట్లు.",
        price_per_sqyd_min: 13500,
        price_per_sqyd_max: 17500,
        total_plots: 24,
        status: "Open for Booking",
        status_te: "బుకింగ్ అందుబాటులో ఉంది",
        hero_image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
        rera_number: "RERA/TEL/NIRMAL/2026/0508",
        layout_image_url: ""
      },
      plots: [
        { plot_number: "P-201", area_sqyd: 240, dimension_length: 60, dimension_width: 36, facing: "East", price_per_sqyd: 14500, is_corner: 1, road_width_ft: 40, status: "available", block_name: "Sector A", pos_x: 60, pos_y: 75, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-202", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "East", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "available", block_name: "Sector A", pos_x: 121, pos_y: 75, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-203", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "East", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "pending", block_name: "Sector A", pos_x: 182, pos_y: 75, width: 55, height: 115, owner_name: "P. Rajesh (Nirmal)" },
        { plot_number: "P-204", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "East", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "booked", block_name: "Sector A", pos_x: 243, pos_y: 75, width: 55, height: 115, owner_name: "K. Satyanarayana (Retd. MRO)" },
        { plot_number: "P-205", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "East", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "available", block_name: "Sector A", pos_x: 304, pos_y: 75, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-206", area_sqyd: 240, dimension_length: 60, dimension_width: 36, facing: "East", price_per_sqyd: 14500, is_corner: 1, road_width_ft: 40, status: "available", block_name: "Sector A", pos_x: 365, pos_y: 75, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-207", area_sqyd: 240, dimension_length: 60, dimension_width: 36, facing: "North", price_per_sqyd: 14500, is_corner: 1, road_width_ft: 40, status: "available", block_name: "Sector B", pos_x: 60, pos_y: 335, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-208", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "available", block_name: "Sector B", pos_x: 121, pos_y: 335, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-209", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "booked", block_name: "Sector B", pos_x: 182, pos_y: 335, width: 55, height: 115, owner_name: "M. Srinivas (Nirmal)" },
        { plot_number: "P-210", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "available", block_name: "Sector B", pos_x: 243, pos_y: 335, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-211", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 13500, is_corner: 0, road_width_ft: 40, status: "available", block_name: "Sector B", pos_x: 304, pos_y: 335, width: 55, height: 115, owner_name: "" },
        { plot_number: "P-212", area_sqyd: 240, dimension_length: 60, dimension_width: 36, facing: "North", price_per_sqyd: 14500, is_corner: 1, road_width_ft: 40, status: "available", block_name: "Sector B", pos_x: 365, pos_y: 335, width: 55, height: 115, owner_name: "" }
      ]
    };
    const jsonStr = JSON.stringify(example, null, 2);
    setStudioJsonCode(jsonStr);
    setStudioCodeError(null);
    setStudioCodeSuccess('✓ Complete Example 2D Layout Code loaded! Click "Apply Code to 2D Layout" to compile it into the visual engine.');
  };

  const generateStudioGrid = (
    rows: number = studioRows,
    cols: number = studioCols,
    defaultArea: number = studioDefaultArea,
    defaultFacing: 'East' | 'West' | 'North' | 'South' = studioDefaultFacing,
    startNum: number = studioStartPlotNum,
    defaultPrice: number = studioVenture.price_per_sqyd_min
  ) => {
    const generated: any[] = [];
    let currentNum = startNum;
    const rowYPositions = rows === 3 ? [75, 335, 535] : [70, 210, 360, 510];
    const plotHeight = rows === 3 ? 115 : 90;
    const availableWidth = 660;
    const plotWidth = Math.floor(availableWidth / cols);

    for (let r = 0; r < rows; r++) {
      const sector = r === 0 ? 'Sector A' : r === 1 ? 'Sector B' : 'Sector C';
      for (let c = 0; c < cols; c++) {
        const isCorner = (c === 0 || c === cols - 1) ? 1 : 0;
        const facing = r % 2 === 0 ? defaultFacing : (defaultFacing === 'East' ? 'West' : 'North');
        const posX = 60 + c * (plotWidth + 6);
        const posY = rowYPositions[r] || (70 + r * 140);

        generated.push({
          plot_number: `P-${currentNum++}`,
          area_sqyd: isCorner ? defaultArea + 40 : defaultArea,
          dimension_length: 50,
          dimension_width: 36,
          facing: facing,
          price_per_sqyd: isCorner ? defaultPrice + 1000 : defaultPrice,
          is_corner: isCorner,
          road_width_ft: r === 1 ? 40 : 33,
          status: 'available',
          block_name: sector,
          pos_x: posX,
          pos_y: posY,
          width: plotWidth,
          height: plotHeight,
          owner_name: ''
        });
      }
    }
    setStudioPlots(generated);
    setStudioSelectedPlotIndex(0);
    syncStudioToJson(studioVenture, generated);
    return generated;
  };

  const handleOpenStudio = (existing?: Venture, initialTab: 'photo' | 'code' = 'photo') => {
    setStudioTab(initialTab);
    setStudioPreviewMode('2d');
    setStudioCodeError(null);
    setStudioCodeSuccess(null);
    if (existing) {
      const vData = {
        name: existing.name,
        slug: existing.slug,
        district: existing.district || 'Nirmal',
        district_te: existing.district_te || 'నిర్మల్ జిల్లా',
        pincode: existing.pincode || '504106',
        city: existing.city || 'Nirmal',
        city_te: existing.city_te || 'నిర్మల్',
        state: existing.state || 'Telangana',
        location: existing.location,
        location_te: existing.location_te || existing.location,
        tagline: existing.tagline || '',
        tagline_te: existing.tagline_te || '',
        description: existing.description || '',
        description_te: existing.description_te || '',
        price_per_sqyd_min: existing.price_per_sqyd_min || 12500,
        price_per_sqyd_max: existing.price_per_sqyd_max || 16500,
        status: existing.status || 'Open for Booking',
        status_te: existing.status_te || 'బుకింగ్ అందుబాటులో ఉంది',
        hero_image: existing.hero_image || '',
        rera_number: existing.rera_number || 'RERA/TEL/NIRMAL/2026/0504',
        layout_image_url: existing.layout_image_url || ''
      };
      setStudioVenture(vData);
      const venturePlots = plots.filter(p => p.venture_id === existing.id);
      if (venturePlots.length > 0) {
        setStudioPlots(venturePlots);
        setStudioSelectedPlotIndex(0);
        syncStudioToJson(vData, venturePlots);
      } else {
        const generated = generateStudioGrid(3, 12, 200, 'East', 101, existing.price_per_sqyd_min || 12500);
        syncStudioToJson(vData, generated);
      }
    } else {
      const defaultV = {
        name: 'B.N Nirmal Greenfield County Phase 2',
        slug: `bn-nirmal-greenfield-${Date.now().toString().slice(-4)}`,
        district: 'Nirmal',
        district_te: 'నిర్మల్ జిల్లా',
        pincode: '504106',
        city: 'Nirmal',
        city_te: 'నిర్మల్',
        state: 'Telangana',
        location: 'NH-44 Bypass & Mancherial Road, Nirmal',
        location_te: 'NH-44 బైపాస్ & మంచిర్యాల రోడ్డు, నిర్మల్',
        tagline: 'DTCP & RERA Approved Luxury Villa Layout in Nirmal District',
        tagline_te: 'నిర్మల్ జిల్లాలో DTCP మరియు RERA అనుమతి పొందిన లేఅవుట్',
        description: 'Premier DTCP approved plotted venture in Nirmal with 40ft blacktop roads, underground cabling, Vaastu compliance, and spot registration.',
        description_te: 'నిర్మల్ పట్టణానికి సమీపంలో 40 అడుగుల రోడ్లు, భూగర్భ విద్యుత్, తాగునీటి సరఫరా మరియు స్పష్టమైన టైటిల్ డాక్యుమెంట్లు కలిగిన ప్లాట్లు.',
        price_per_sqyd_min: 12500,
        price_per_sqyd_max: 16500,
        status: 'Open for Booking',
        status_te: 'బుకింగ్ అందుబాటులో ఉంది',
        hero_image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
        rera_number: 'RERA/TEL/NIRMAL/2026/0504',
        layout_image_url: ''
      };
      setStudioVenture(defaultV);
      const generated = generateStudioGrid(3, 12, 200, 'East', 101, 12500);
      syncStudioToJson(defaultV, generated);
    }
    setStudioUploadMessage(null);
    setIsLayoutStudioOpen(true);
  };

  const handleStudioLayoutFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingLayout(true);
    setStudioUploadMessage(null);

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const base64Data = evt.target?.result as string;
        const res = await api.uploadLayout(file.name, base64Data);
        const newPlots = (studioPlots && studioPlots.length > 0)
          ? studioPlots 
          : generateStudioGrid(studioRows, studioCols, studioDefaultArea, studioDefaultFacing, studioStartPlotNum, studioVenture.price_per_sqyd_min);
        setStudioVenture(prev => {
          const updated = { ...prev, layout_image_url: res.url };
          syncStudioToJson(updated, newPlots);
          return updated;
        });
        setStudioUploadMessage(`✓ 2D layout photo '${file.name}' attached! The website has automatically generated a bespoke 2D vector SVG map and 3D conceptual view.`);
      } catch (err: any) {
        alert(err.message || 'Failed to upload layout blueprint');
      } finally {
        setIsUploadingLayout(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveStudioVenture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studioVenture.name.trim() || !studioVenture.location.trim()) {
      alert('Please fill in Venture Name and Location');
      return;
    }
    setStudioSaving(true);
    try {
      const payload = {
        ...studioVenture,
        total_plots: studioPlots.length,
        plots: studioPlots
      };
      const res = await api.createVenture(payload);
      alert(res.message || 'Venture & 2D Layout published successfully!');
      setIsLayoutStudioOpen(false);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to save venture & layout');
    } finally {
      setStudioSaving(false);
    }
  };

  // Media Management State (Requirement 8 - Admin Only)
  const [selectedVentureIdForMedia, setSelectedVentureIdForMedia] = useState<number>(1);
  const [mediaGallery, setMediaGallery] = useState<string[]>([]);
  const [mediaVideos, setMediaVideos] = useState<VentureVideo[]>([]);
  const [newPhotoUrl, setNewPhotoUrl] = useState<string>('');
  const [newVideoTitle, setNewVideoTitle] = useState<string>('');
  const [newVideoUrl, setNewVideoUrl] = useState<string>('');
  const [mediaSaving, setMediaSaving] = useState<boolean>(false);
  const [mediaSuccess, setMediaSuccess] = useState<string | null>(null);

  // Plot editing state
  const [editingPlot, setEditingPlot] = useState<Plot | null>(null);
  const [isAddPlotOpen, setIsAddPlotOpen] = useState<boolean>(false);
  const [newPlotForm, setNewPlotForm] = useState<Partial<Plot>>({
    venture_id: 1,
    plot_number: '',
    area_sqyd: 200,
    dimension_length: 50,
    dimension_width: 36,
    facing: 'North',
    price_per_sqyd: 19500,
    is_corner: 0,
    road_width_ft: 33,
    status: 'available',
    block_name: 'Sector A',
    pos_x: 100,
    pos_y: 100,
    width: 65,
    height: 95,
    owner_name: ''
  });

  // Bulk status update
  const [selectedPlotIds, setSelectedPlotIds] = useState<number[]>([]);
  const [bulkStatus, setBulkStatus] = useState<PlotStatus>('available');

  // Search filter
  const [plotSearchQuery, setPlotSearchQuery] = useState('');
  const [selectedVentureFilter, setSelectedVentureFilter] = useState<string>('');

  // 1. Initial auth status check
  useEffect(() => {
    checkInitialAuth();
  }, []);

  const checkInitialAuth = async () => {
    try {
      setHasAdmin(true);

      const token = localStorage.getItem('smartplot_admin_token');
      if (token) {
        try {
          const me = await api.getMe();
          setAdminUser(me.admin);
          setIsAuthenticated(true);
          loadDashboardData();
        } catch {
          // Token expired or invalid - clear stored session
          localStorage.removeItem('smartplot_admin_token');
          setIsAuthenticated(false);
        }
      } else {
        setIsAuthenticated(false);
      }
    } catch (err: any) {
      setHasAdmin(true);
      setIsAuthenticated(false);
    }
  };

  const loadDashboardData = async () => {
    setLoadingData(true);
    try {
      const [m, p, v, a, b, e] = await Promise.all([
        api.getAdminMetrics(),
        api.getAdminPlots(),
        api.getVentures(),
        api.getAdminAppointments(),
        api.getAdminBookings(),
        api.getAdminEnquiries()
      ]);
      setMetrics(m);
      setPlots(p);
      setVentures(v);
      setAppointments(a);
      setBookings(b);
      setEnquiries(e);

      // Initialize media state from first venture
      if (v.length > 0) {
        const currentV = v.find((ven) => ven.id === selectedVentureIdForMedia) || v[0];
        setSelectedVentureIdForMedia(currentV.id);
        setMediaGallery(currentV.gallery || [currentV.hero_image]);
        setMediaVideos(currentV.videos || []);
      }
    } catch (err: any) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoadingData(false);
    }
  };

  const loadSecurityLogs = async () => {
    setLoadingLogs(true);
    try {
      const res = await api.getSecurityLogs();
      if (res && res.logs) {
        setSecurityLogs(res.logs);
      }
    } catch (e) {
      console.error('Failed to load security logs:', e);
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'security' && isAuthenticated) {
      loadSecurityLogs();
    }
  }, [activeTab, isAuthenticated]);

  // Switch selected venture for media tab
  const handleVentureMediaSelect = (vid: number) => {
    setSelectedVentureIdForMedia(vid);
    const targetV = ventures.find((v) => v.id === vid);
    if (targetV) {
      setMediaGallery(targetV.gallery || [targetV.hero_image]);
      setMediaVideos(targetV.videos || []);
    }
    setMediaSuccess(null);
  };

  const handleAddPhoto = () => {
    if (!newPhotoUrl.trim()) return;
    setMediaGallery([...mediaGallery, newPhotoUrl.trim()]);
    setNewPhotoUrl('');
  };

  const handleRemovePhoto = (idx: number) => {
    setMediaGallery(mediaGallery.filter((_, i) => i !== idx));
  };

  const handleAddVideo = () => {
    if (!newVideoUrl.trim() || !newVideoTitle.trim()) {
      alert('Please enter both video title and URL');
      return;
    }
    setMediaVideos([...mediaVideos, { title: newVideoTitle.trim(), url: newVideoUrl.trim() }]);
    setNewVideoTitle('');
    setNewVideoUrl('');
  };

  const handleRemoveVideo = (idx: number) => {
    setMediaVideos(mediaVideos.filter((_, i) => i !== idx));
  };

  const handleSaveMedia = async () => {
    setMediaSaving(true);
    setMediaSuccess(null);
    try {
      await api.updateVentureMedia(selectedVentureIdForMedia, {
        gallery: mediaGallery,
        videos: mediaVideos
      });
      setMediaSuccess('Photos and videos successfully updated for this venture!');
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to save venture media');
    } finally {
      setMediaSaving(false);
    }
  };

  // Setup Initial Admin
  // Owner Two-Factor Security Authentication
  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const pass = ownerPassword.trim();
    const code = ownerVerificationCode.trim();

    if (!pass || !code) {
      setAuthError('Access Denied: Please enter both the Owner Master Password and the 6-digit Security Verification PIN.');
      return;
    }

    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await api.login(pass, code);
      localStorage.setItem('smartplot_admin_token', res.token);
      setAdminUser(res.admin);
      setIsAuthenticated(true);
      loadDashboardData();
    } catch (err: any) {
      setAuthError(err.message || 'Access Denied: Invalid Owner Password or Security Verification Code. Access is restricted exclusively to the property owner.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('smartplot_admin_token');
    setIsAuthenticated(false);
    setAdminUser(null);
    setOwnerPassword('');
    setOwnerVerificationCode('');
  };

  const handleOpenSecuritySettings = async () => {
    try {
      setSecurityUpdateSuccess(null);
      const sec = await api.getOwnerSecurity();
      setSecurityModalData({
        password: sec.owner_passcode || 'BNVentures@2026',
        verification_code: sec.verification_code || '504106'
      });
      setIsSecurityModalOpen(true);
    } catch (err: any) {
      alert(err.message || 'Failed to fetch security credentials');
    }
  };

  const handleSaveSecuritySettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!securityModalData.password.trim() || !securityModalData.verification_code.trim()) {
      alert('Both Master Password and 6-Digit PIN are required');
      return;
    }
    setSecurityUpdateLoading(true);
    try {
      await api.updateOwnerSecurity(securityModalData.password.trim(), securityModalData.verification_code.trim());
      setSecurityUpdateSuccess('✓ Owner Master Password & Verification PIN updated successfully!');
      setTimeout(() => {
        setIsSecurityModalOpen(false);
        setSecurityUpdateSuccess(null);
      }, 1500);
    } catch (err: any) {
      alert(err.message || 'Failed to update credentials');
    } finally {
      setSecurityUpdateLoading(false);
    }
  };

  // Plot CRUD handlers
  const handleUpdatePlot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPlot) return;
    try {
      await api.updatePlot(editingPlot.id, editingPlot);
      setEditingPlot(null);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to update plot.');
    }
  };

  const handleCreatePlot = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createPlot(newPlotForm);
      setIsAddPlotOpen(false);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to create plot.');
    }
  };

  const handleDeletePlot = async (id: number) => {
    if (!confirm('Are you sure you want to delete this plot from the database?')) return;
    try {
      await api.deletePlot(id);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete plot.');
    }
  };

  const handleBulkStatusUpdate = async () => {
    if (selectedPlotIds.length === 0) {
      alert('Please select at least one plot using the checkboxes.');
      return;
    }
    try {
      await api.bulkUpdatePlotStatus(selectedPlotIds, bulkStatus);
      setSelectedPlotIds([]);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to bulk update status.');
    }
  };

  // Venture CRUD & Import handlers (Admin Only)
  const handleCreateVenture = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createVenture(newVentureForm);
      setIsAddVentureOpen(false);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to create venture');
    }
  };

  const handleUpdateVenture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVenture) return;
    try {
      await api.updateVenture(editingVenture.id, editingVenture);
      setEditingVenture(null);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to update venture');
    }
  };

  const handleDeleteVenture = async (id: number) => {
    if (!confirm('Are you sure you want to delete this venture and all its associated plots from the database?')) return;
    try {
      await api.deleteVenture(id);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete venture');
    }
  };

  const handleExportVenture = async (id: number, slug: string) => {
    try {
      const data = await api.exportVenture(id);
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${slug}_backup.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert(err.message || 'Failed to export venture data');
    }
  };

  const handleExecuteImport = async (payloadToImport: any) => {
    setImportLoading(true);
    setImportMessage(null);
    try {
      const res = await api.importVenture(payloadToImport);
      setImportMessage({ type: 'success', text: res.message });
      loadDashboardData();
      setTimeout(() => {
        setIsImportModalOpen(false);
        setImportMessage(null);
      }, 1800);
    } catch (err: any) {
      setImportMessage({ type: 'error', text: err.message || 'Import failed' });
    } finally {
      setImportLoading(false);
    }
  };

  const handleImportJsonSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsed = JSON.parse(importJsonText);
      handleExecuteImport(parsed);
    } catch (err: any) {
      setImportMessage({ type: 'error', text: 'Invalid JSON format: ' + err.message });
    }
  };

  const handleLoadSampleTemplate = () => {
    const sample = {
      venture: {
        name: "B.N Nirmal Prime Enclave",
        slug: "bn-nirmal-prime-enclave",
        district: "Nirmal",
        district_te: "నిర్మల్ జిల్లా",
        pincode: "504106",
        city: "Nirmal",
        city_te: "నిర్మల్",
        state: "Telangana",
        location: "NH-44 Bypass & Mancherial Road, Nirmal",
        location_te: "NH-44 బైపాస్ & మంచిర్యాల రోడ్డు, నిర్మల్",
        tagline: "DTCP & RERA Approved Luxury Villa Layout in Nirmal District",
        tagline_te: "నిర్మల్ జిల్లాలో DTCP మరియు RERA అనుమతి పొందిన లేఅవుట్",
        description: "Premium plotted development with 40ft blacktop roads, underground electricity, water supply, and spot registration.",
        description_te: "నిర్మల్ పట్టణానికి సమీపంలో 40 అడుగుల రోడ్లు, భూగర్భ విద్యుత్, తాగునీటి సరఫరా మరియు స్పష్టమైన టైటిల్ డాక్యుమెంట్లు కలిగిన ప్లాట్లు.",
        price_per_sqyd_min: 11500,
        price_per_sqyd_max: 15500,
        total_plots: 36,
        status: "Open for Booking",
        status_te: "బుకింగ్ అందుబాటులో ఉంది",
        hero_image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
        rera_number: "RERA/TEL/NIRMAL/2026/0504",
        map_embed_url: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60447.53036665796!2d78.31422789179686!3d19.094625299999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd28b9fb6c75c87%3A0x6bfe76e271c777d4!2sNirmal%2C%20Telangana%20504106!5e0!3m2!1sen!2sin!4v1700000000000",
        amenities: [
          "40 & 33 Feet Wide Blacktop Roads",
          "Underground Electricity & Solar Street Lights",
          "Grand Entrance Arch with 24/7 Security",
          "Landscaped Parks & Walking Track",
          "Overhead Water Tank with Tap Connections",
          "100% Vaastu Compliant Layout",
          "Immediate Spot Registration & Clear Title"
        ]
      },
      plots: [
        { plot_number: "P-101", area_sqyd: 267, dimension_length: 60, dimension_width: 40, facing: "East", price_per_sqyd: 14500, is_corner: 1, road_width_ft: 40, status: "available", pos_x: 60, pos_y: 70, width: 75, height: 95 },
        { plot_number: "P-102", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 12500, is_corner: 0, road_width_ft: 33, status: "available", pos_x: 140, pos_y: 70, width: 65, height: 95 },
        { plot_number: "P-103", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 12500, is_corner: 0, road_width_ft: 33, status: "pending", owner_name: "M. Santosh (Nirmal)", pos_x: 210, pos_y: 70, width: 65, height: 95 },
        { plot_number: "P-104", area_sqyd: 200, dimension_length: 50, dimension_width: 36, facing: "North", price_per_sqyd: 12500, is_corner: 0, road_width_ft: 33, status: "booked", owner_name: "K. Rajeshwar (Retd. MRO, Nirmal)", pos_x: 280, pos_y: 70, width: 65, height: 95 }
      ]
    };
    setImportJsonText(JSON.stringify(sample, null, 2));
  };

  // Appointment status handler
  const handleUpdateAppointment = async (id: number, status: string, notes?: string) => {
    try {
      await api.updateAppointment(id, { status: status as any, admin_notes: notes });
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to update appointment.');
    }
  };

  // Booking approval / rejection handler
  const handleUpdateBooking = async (id: number, status: 'approved' | 'rejected') => {
    try {
      await api.updateBookingStatus(id, status);
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || 'Failed to update booking status.');
    }
  };

  // ========================================================
  // RENDER: B.N Ventures Owner Security Vault (Strict Owner Two-Factor Authentication)
  // ========================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-navy-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden select-none">
        {/* Subtle decorative background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 translate-y-1/2 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 via-emerald-600 to-teal-500 mx-auto flex items-center justify-center text-white shadow-2xl shadow-emerald-950/80 border border-amber-400/30">
            <ShieldCheck className="w-9 h-9 text-white" />
          </div>

          <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-bold tracking-widest uppercase">
            <Lock className="w-3 h-3 text-amber-400" /> Restricted • Property Owner Only
          </div>

          <h2 className="mt-3 text-center font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
            Owner Security Vault
          </h2>
          <p className="mt-2 text-center text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
            Access to B.N Ventures management is strictly reserved for the verified property owner. Enter your Master Password and 6-Digit Verification PIN.
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10">
          <div className="bg-slate-900/90 backdrop-blur-xl py-8 px-6 shadow-2xl rounded-3xl border border-slate-800/80 sm:px-10 relative">
            {authError && (
              <div className="mb-5 p-3.5 bg-red-950/80 border border-red-700/80 text-red-200 rounded-xl text-xs flex items-start gap-2.5 shadow-lg shadow-red-950/40">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span className="leading-snug">{authError}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-5">
              {/* Owner Master Password */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    Owner Master Password
                  </label>
                  <span className="text-[10px] text-amber-400/80 font-mono">Confidential</span>
                </div>
                <div className="relative">
                  <Key className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Enter Master Owner Password"
                    value={ownerPassword}
                    onChange={(e) => setOwnerPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-10 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-200"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Default: <code className="text-slate-400 font-mono">BNVentures@2026</code>
                </p>
              </div>

              {/* 6-Digit Owner Security Verification Code */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    6-Digit Security Verification PIN
                  </label>
                  <span className="text-[10px] text-emerald-400 font-mono">2FA Required</span>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    maxLength={6}
                    placeholder="504106"
                    value={ownerVerificationCode}
                    onChange={(e) => setOwnerVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-center text-lg font-mono tracking-[0.4em] text-emerald-400 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition font-black"
                  />
                </div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Default PIN: <code className="text-slate-400 font-mono">504106</code> (Nirmal District PIN)
                </p>
              </div>

              {/* Quick autofill button for owner convenience */}
              <button
                type="button"
                onClick={() => {
                  setOwnerPassword('BNVentures@2026');
                  setOwnerVerificationCode('504106');
                  setAuthError(null);
                }}
                className="w-full text-center text-[11px] text-slate-400 hover:text-emerald-300 transition py-1 hover:underline flex items-center justify-center gap-1.5"
              >
                <span>🔑 Pre-fill Owner Default Credentials</span>
              </button>

              {/* Unlock Vault Button */}
              <button
                type="submit"
                disabled={authLoading}
                className="w-full bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2 text-sm transition-all transform active:scale-98 border border-emerald-400/30 disabled:opacity-50"
              >
                {authLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>Verifying Owner Credentials...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-amber-300" />
                    <span>Verify Credentials & Unlock Vault</span>
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 pt-5 border-t border-slate-800 text-center">
              <button
                onClick={onBackToSite}
                className="text-xs text-slate-400 hover:text-white transition flex items-center justify-center gap-1.5 mx-auto"
              >
                ← Return to Public Website
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Filtered plots
  const filteredPlots = plots.filter(p => {
    const matchesSearch = p.plot_number.toLowerCase().includes(plotSearchQuery.toLowerCase()) ||
                          p.block_name.toLowerCase().includes(plotSearchQuery.toLowerCase()) ||
                          (p.owner_name && p.owner_name.toLowerCase().includes(plotSearchQuery.toLowerCase()));
    const matchesVenture = !selectedVentureFilter || p.venture_id === Number(selectedVentureFilter);
    return matchesSearch && matchesVenture;
  });

  // Current selected venture for media tab
  const currentMediaVenture = ventures.find(v => v.id === selectedVentureIdForMedia) || ventures[0];

  // ========================================================
  // RENDER: Authenticated Main Admin Dashboard
  // ========================================================
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Admin Top Navigation */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3.5 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-navy-950 flex items-center justify-center text-emerald-400 font-black text-xl border border-emerald-500/30">
              BN
            </div>
            <div>
              <span className="font-display font-extrabold text-lg text-white tracking-tight flex items-center gap-1.5">
                B.N Ventures <span className="text-emerald-400">Admin Control</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded border border-emerald-500/30">
                  Live DB
                </span>
              </span>
              <p className="text-[11px] text-slate-400">
                Logged in as <strong>{adminUser?.name || 'B.N Administrator'}</strong> • 10 Years Trust
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Firebase Cloud Sync Badge */}
            <div 
              className="bg-amber-950/40 border border-amber-500/40 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-sm"
              title="Google Firebase Realtime Leads & Cloud Firestore Mirroring Active"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span className="hidden md:inline">Firebase Cloud Sync</span>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>

            <button
              onClick={loadDashboardData}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${loadingData ? 'animate-spin text-emerald-400' : ''}`} />
            </button>

            <button
              onClick={handleOpenSecuritySettings}
              className="bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 border border-amber-800/60 text-xs font-semibold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
              title="Manage Owner Security Passcode & PIN"
            >
              <Key className="w-3.5 h-3.5 text-amber-400" /> Owner Security Keys
            </button>

            <button
              onClick={onBackToSite}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" /> View Public Site
            </button>

            <button
              onClick={handleLogout}
              className="bg-red-950/60 hover:bg-red-900 text-red-200 border border-red-800 text-xs font-semibold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" /> Lock & Exit
            </button>
          </div>
        </div>

        {/* Owner Security Credentials Modal */}
        {isSecurityModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl relative">
              <button
                onClick={() => setIsSecurityModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-5">
                <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
                  <Key className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">Owner Security Credentials</h3>
                  <p className="text-xs text-slate-400">Update Master Owner Password & 6-Digit PIN</p>
                </div>
              </div>

              {securityUpdateSuccess && (
                <div className="mb-4 p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-200 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{securityUpdateSuccess}</span>
                </div>
              )}

              <form onSubmit={handleSaveSecuritySettings} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Owner Master Password
                  </label>
                  <input
                    type="text"
                    required
                    value={securityModalData.password}
                    onChange={(e) => setSecurityModalData({ ...securityModalData, password: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Default was: BNVentures@2026</p>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    6-Digit Security Verification PIN
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={securityModalData.verification_code}
                    onChange={(e) => setSecurityModalData({ ...securityModalData, verification_code: e.target.value.replace(/\D/g, '').slice(0, 6) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-center text-lg font-mono tracking-[0.3em] text-emerald-400 font-black focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Default was: 504106 (Nirmal District PIN)</p>
                </div>

                <div className="pt-2 flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsSecurityModalOpen(false)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold py-2.5 rounded-xl transition text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={securityUpdateLoading}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl transition text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/60"
                  >
                    {securityUpdateLoading ? 'Updating...' : 'Save New Credentials'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Dashboard Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex gap-2 overflow-x-auto border-t border-slate-800/60 pt-1">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'overview' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" /> Overview & Metrics
          </button>

          {/* User Requirement: Admin Import & Management for Ventures */}
          <button
            onClick={() => setActiveTab('ventures')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'ventures' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-4 h-4 text-emerald-400" /> Ventures & Import Hub ({ventures.length})
          </button>

          <button
            onClick={() => setActiveTab('plots')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'plots' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" /> Plots & Owner Records ({plots.length})
          </button>

          {/* Requirement 8: Venture Photos & Videos (Admin Only) */}
          <button
            onClick={() => setActiveTab('media')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'media' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Video className="w-4 h-4 text-emerald-400" /> Venture Photos & Videos (Admin Only)
          </button>

          <button
            onClick={() => setActiveTab('appointments')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'appointments' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calendar className="w-4 h-4" /> Site Visits ({appointments.length})
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'bookings' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" /> Plot Reservations ({bookings.length})
          </button>

          <button
            onClick={() => setActiveTab('enquiries')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'enquiries' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> Enquiries ({enquiries.length})
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2.5 text-xs font-bold rounded-t-lg transition flex items-center gap-2 ${
              activeTab === 'security' 
                ? 'bg-slate-950 text-emerald-400 border-t-2 border-emerald-500' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Security Logs (OWASP)
          </button>
        </div>
      </header>

      {/* Main Body */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-8 space-y-6">

        {/* ------------------------------------------------------------- */}
        {/* TAB 1: EXECUTIVE OVERVIEW */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'overview' && metrics && (
          <div className="space-y-6 animate-in fade-in duration-200">
            
            {/* Top Cards Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Plots</span>
                <div className="text-3xl font-display font-extrabold text-white">{metrics.plots.total}</div>
                <span className="text-[11px] text-slate-500">Across {metrics.venturesCount} Active Ventures</span>
              </div>

              {/* GREEN: Available */}
              <div className="bg-slate-900 border border-emerald-800/40 rounded-2xl p-4 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider">Available</span>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                </div>
                <div className="text-3xl font-display font-extrabold text-emerald-400">{metrics.plots.available}</div>
                <span className="text-[11px] text-slate-400">Ready for Immediate Sale</span>
              </div>

              {/* YELLOW: Pending */}
              <div className="bg-slate-900 border border-amber-800/40 rounded-2xl p-4 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">Pending</span>
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse"></span>
                </div>
                <div className="text-3xl font-display font-extrabold text-amber-400">{metrics.plots.pending}</div>
                <span className="text-[11px] text-slate-400">Under Token Review</span>
              </div>

              {/* RED: Booked / Sold */}
              <div className="bg-slate-900 border border-red-800/40 rounded-2xl p-4 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-red-400 font-bold uppercase tracking-wider">Booked / Sold</span>
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
                </div>
                <div className="text-3xl font-display font-extrabold text-red-400">
                  {metrics.plots.booked + metrics.plots.sold}
                </div>
                <span className="text-[11px] text-slate-400">Owner Name Visible on Layout</span>
              </div>

              {/* BLACK: Blocked */}
              <div className="bg-slate-900 border border-slate-700 rounded-2xl p-4 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300 font-bold uppercase tracking-wider">Blocked</span>
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
                </div>
                <div className="text-3xl font-display font-extrabold text-slate-200">{metrics.plots.blocked}</div>
                <span className="text-[11px] text-slate-400">Reserved for Developer</span>
              </div>
            </div>

            {/* Quick Venture Summary Cards */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-display font-bold text-lg text-white">5 Delivered Ventures by B.N Ventures</h3>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                {ventures.map((v) => (
                  <div key={v.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                    <h4 className="font-bold text-white text-sm">{v.name}</h4>
                    <p className="text-[11px] text-slate-400">{v.location}, {v.city}</p>
                    <div className="text-xs text-emerald-400 font-mono">
                      ₹{v.price_per_sqyd_min} - ₹{v.price_per_sqyd_max} / yd
                    </div>
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300">
                      {v.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 1.5: VENTURES & IMPORT HUB (Admin Only) */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'ventures' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Header / Actions Banner */}
            <div className="bg-gradient-to-r from-slate-900 via-navy-950 to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-5">
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold px-2.5 py-0.5 rounded-full border border-emerald-500/30 uppercase tracking-widest flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-300" /> Owner Publishing Hub
                  </span>
                  <span className="text-xs text-slate-400">• Immediate Live Public Deployment</span>
                </div>
                <h3 className="font-display font-black text-2xl text-white flex items-center gap-2.5">
                  <Building2 className="w-6 h-6 text-emerald-400" />
                  Ventures & Master Layout Engine
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Deploy new ventures to the website for public visitors. Admin only needs to <strong>upload a 2D layout photo</strong> — the website automatically creates its own interactive 3D view without requiring you to build it! You can also <strong>enter layout code (JSON)</strong> to directly insert a configured venture.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 shrink-0">
                {/* Method A: Upload 2D Layout Photo */}
                <button
                  onClick={() => handleOpenStudio(undefined, 'photo')}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-3 rounded-xl shadow-xl shadow-emerald-950/60 transition flex items-center gap-2 border border-emerald-400/30 transform active:scale-98"
                  title="Upload 2D layout photo only (the website engine automatically builds the 3D view)"
                >
                  <Upload className="w-4 h-4 text-emerald-200" />
                  <span>Upload 2D Layout Photo</span>
                </button>

                {/* Method B: Enter Layout Code */}
                <button
                  onClick={() => handleOpenStudio(undefined, 'code')}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-300 font-extrabold text-xs px-4 py-3 rounded-xl border border-amber-600/40 transition flex items-center gap-2 shadow-lg hover:border-amber-500/60"
                  title="Enter or paste venture layout code format (JSON)"
                >
                  <FileCode className="w-4 h-4 text-amber-400" />
                  <span>Enter Layout Code (JSON)</span>
                </button>

                {/* Method C: Import JSON Package */}
                <button
                  onClick={() => setIsImportModalOpen(true)}
                  className="bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs px-3.5 py-3 rounded-xl border border-slate-700 transition flex items-center gap-1.5"
                  title="Import venture from backup package"
                >
                  <Upload className="w-3.5 h-3.5 text-slate-400" />
                  <span>Import Package</span>
                </button>
              </div>
            </div>

            {/* Ventures Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {ventures.map((v) => {
                const isNirmal = (v.district && v.district.toLowerCase().includes('nirmal')) || 
                                 (v.city && v.city.toLowerCase().includes('nirmal')) || 
                                 v.pincode === '504106';
                return (
                  <div
                    key={v.id}
                    className={`bg-slate-900 rounded-2xl border transition overflow-hidden flex flex-col justify-between ${
                      isNirmal ? 'border-emerald-500/50 shadow-lg shadow-emerald-950/40 ring-1 ring-emerald-500/30' : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      {/* Venture Image Banner */}
                      <div className="relative h-40 bg-slate-950 overflow-hidden">
                        <img
                          src={v.hero_image || 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80'}
                          alt={v.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                        
                        {isNirmal && (
                          <div className="absolute top-3 left-3 bg-emerald-600 text-white text-[10px] font-black px-2.5 py-1 rounded-full shadow-md uppercase tracking-wider flex items-center gap-1">
                            ★ Featured District (504106)
                          </div>
                        )}

                        <div className="absolute top-3 right-3 flex items-center gap-1.5">
                          {v.layout_image_url && (
                            <span className="bg-blue-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow">
                              <Layers className="w-3 h-3" /> 2D Blueprint
                            </span>
                          )}
                          <span className="bg-slate-900/90 text-slate-200 text-[10px] font-bold px-2 py-0.5 rounded border border-slate-700">
                            {v.status || 'Active'}
                          </span>
                        </div>

                        <div className="absolute bottom-3 left-3 right-3">
                          <h4 className="font-display font-extrabold text-base text-white truncate drop-shadow">
                            {v.name}
                          </h4>
                          <p className="text-[11px] text-slate-300 flex items-center gap-1 drop-shadow">
                            <MapPin className="w-3 h-3 text-emerald-400 shrink-0" />
                            {v.district ? `${v.district} District (${v.pincode || '504106'})` : `${v.location}, ${v.city}`}
                          </p>
                        </div>
                      </div>

                      {/* Content & Details */}
                      <div className="p-4 space-y-3 text-xs">
                        {v.tagline && (
                          <p className="text-slate-300 font-medium text-[11px] line-clamp-1 italic">
                            "{v.tagline}"
                          </p>
                        )}

                        <div className="grid grid-cols-2 gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Plots</span>
                            <span className="font-mono text-sm font-bold text-white">
                              {v.total_plots || (v as any).actual_plots_count || 0} Plots
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500 block">Price / Sq.Yd</span>
                            <span className="font-mono text-sm font-bold text-emerald-400">
                              ₹{v.price_per_sqyd_min} - ₹{v.price_per_sqyd_max}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500 block">District / PIN</span>
                            <span className="text-xs font-semibold text-slate-300 truncate block">
                              {v.district || v.city || 'N/A'} • {v.pincode || '504106'}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500 block">RERA Status</span>
                            <span className="text-xs font-semibold text-slate-300 truncate block">
                              {v.rera_number ? 'Approved' : 'Clear Title'}
                            </span>
                          </div>
                        </div>

                        {v.amenities && v.amenities.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {v.amenities.slice(0, 3).map((a, idx) => (
                              <span key={idx} className="bg-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded">
                                {a}
                              </span>
                            ))}
                            {v.amenities.length > 3 && (
                              <span className="text-[10px] text-slate-500 py-0.5">
                                +{v.amenities.length - 3} more
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="p-4 pt-0 flex items-center justify-between gap-2 border-t border-slate-800/60 mt-3 pt-3">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleOpenStudio(v)}
                          className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1"
                          title="Open 2D Layout Studio"
                        >
                          <Layers className="w-3.5 h-3.5 text-emerald-400" /> 2D Studio
                        </button>
                        <button
                          onClick={() => setEditingVenture(v)}
                          className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1"
                        >
                          <Edit className="w-3.5 h-3.5 text-emerald-400" /> Edit
                        </button>
                        <button
                          onClick={() => handleExportVenture(v.id, v.slug)}
                          className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1"
                          title="Export full venture & plots as JSON backup"
                        >
                          <Download className="w-3.5 h-3.5 text-blue-400" /> Export JSON
                        </button>
                      </div>

                      <button
                        onClick={() => handleDeleteVenture(v.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-950/40 p-1.5 rounded-lg transition"
                        title="Delete venture"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 2: PLOTS & OWNER RECORDS (Requirement 6, 9 & 10) */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'plots' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            
            {/* Filter and Action bar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 p-4 rounded-2xl border border-slate-800">
              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                {/* Search */}
                <div className="relative min-w-[220px]">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={plotSearchQuery}
                    onChange={(e) => setPlotSearchQuery(e.target.value)}
                    placeholder="Search by Plot #, Block, or Owner..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Venture filter */}
                <select
                  value={selectedVentureFilter}
                  onChange={(e) => setSelectedVentureFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">All 5 Ventures</option>
                  {ventures.map((v) => (
                    <option key={v.id} value={v.id}>{v.name}</option>
                  ))}
                </select>

                {/* Bulk Status Updater */}
                {selectedPlotIds.length > 0 && (
                  <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
                    <span className="text-xs text-emerald-400 font-bold">{selectedPlotIds.length} Selected</span>
                    <select
                      value={bulkStatus}
                      onChange={(e) => setBulkStatus(e.target.value as PlotStatus)}
                      className="bg-slate-900 border border-slate-700 text-xs text-white rounded px-2 py-1"
                    >
                      <option value="available">Mark Available</option>
                      <option value="pending">Mark Pending</option>
                      <option value="booked">Mark Booked</option>
                      <option value="sold">Mark Sold</option>
                      <option value="blocked">Mark Blocked</option>
                    </select>
                    <button
                      onClick={handleBulkStatusUpdate}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-2.5 py-1 rounded transition"
                    >
                      Apply
                    </button>
                  </div>
                )}
              </div>

              <button
                onClick={() => setIsAddPlotOpen(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition shrink-0"
              >
                <Plus className="w-4 h-4" /> Add New Plot Record
              </button>
            </div>

            {/* Plots Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden overflow-x-auto shadow-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="p-3 w-10 text-center">
                      <input 
                        type="checkbox"
                        checked={selectedPlotIds.length === filteredPlots.length && filteredPlots.length > 0}
                        onChange={(e) => {
                          if (e.target.checked) setSelectedPlotIds(filteredPlots.map(p => p.id));
                          else setSelectedPlotIds([]);
                        }}
                        className="rounded accent-emerald-600"
                      />
                    </th>
                    <th className="p-3">Plot #</th>
                    <th className="p-3">Venture</th>
                    <th className="p-3">Area (Sq.Yd)</th>
                    <th className="p-3">Facing</th>
                    <th className="p-3">Rate / Yd</th>
                    <th className="p-3">Total Consideration</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Owner Name (Layout)</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredPlots.map((plot) => (
                    <tr key={plot.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={selectedPlotIds.includes(plot.id)}
                          onChange={(e) => {
                            if (e.target.checked) setSelectedPlotIds([...selectedPlotIds, plot.id]);
                            else setSelectedPlotIds(selectedPlotIds.filter(id => id !== plot.id));
                          }}
                          className="rounded accent-emerald-600"
                        />
                      </td>
                      <td className="p-3 font-bold text-white text-sm">
                        {plot.plot_number}
                        {plot.is_corner === 1 && (
                          <span className="ml-1 text-[9px] bg-amber-500/20 text-amber-300 px-1 py-0.5 rounded">Corner</span>
                        )}
                      </td>
                      <td className="p-3 text-slate-300">{plot.venture_name || 'B.N Golden County'}</td>
                      <td className="p-3 font-semibold text-slate-200">{plot.area_sqyd} yd²</td>
                      <td className="p-3 text-slate-300">{plot.facing}</td>
                      <td className="p-3 text-slate-300">₹{plot.price_per_sqyd.toLocaleString('en-IN')}</td>
                      <td className="p-3 font-bold text-emerald-400">₹{plot.total_price.toLocaleString('en-IN')}</td>
                      <td className="p-3">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          plot.status === 'available' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          plot.status === 'pending' ? 'bg-amber-950 text-amber-400 border border-amber-800 animate-pulse' :
                          plot.status === 'blocked' ? 'bg-slate-800 text-slate-300 border border-slate-700' :
                          'bg-red-950 text-red-400 border border-red-800'
                        }`}>
                          {plot.status}
                        </span>
                      </td>
                      <td className="p-3">
                        {plot.owner_name ? (
                          <span className="bg-amber-950/60 border border-amber-800/40 text-amber-300 font-bold px-2 py-0.5 rounded text-[11px]">
                            👤 {plot.owner_name}
                          </span>
                        ) : (
                          <span className="text-slate-600 text-[11px]">—</span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setEditingPlot(plot)}
                            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                            title="Edit Plot"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeletePlot(plot.id)}
                            className="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-950/50 rounded-lg transition"
                            title="Delete Plot"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 3: VENTURE PHOTOS & VIDEOS MANAGEMENT (Requirement 8) */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'media' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="font-display font-extrabold text-xl text-white flex items-center gap-2">
                    <Video className="w-5 h-5 text-emerald-400" /> Venture Photos & Videos — Admin Only
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Upload and manage real photos and drone tour video links for each of the 5 B.N Ventures.
                  </p>
                </div>

                {/* Venture Selector */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-bold">Select Venture:</span>
                  <select
                    value={selectedVentureIdForMedia}
                    onChange={(e) => handleVentureMediaSelect(Number(e.target.value))}
                    className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {ventures.map((v) => (
                      <option key={v.id} value={v.id}>{v.name} ({v.city})</option>
                    ))}
                  </select>
                </div>
              </div>

              {mediaSuccess && (
                <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  {mediaSuccess}
                </div>
              )}

              {/* Photos Management Section */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-emerald-400" /> Photo Gallery ({mediaGallery.length} Images)
                  </h4>
                </div>

                {/* Add new photo input */}
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="Paste image URL (e.g. https://images.unsplash.com/...)"
                    value={newPhotoUrl}
                    onChange={(e) => setNewPhotoUrl(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    onClick={handleAddPhoto}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Add Photo
                  </button>
                </div>

                {/* Photos Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {mediaGallery.map((imgUrl, idx) => (
                    <div key={idx} className="relative group bg-slate-950 rounded-xl overflow-hidden border border-slate-800 aspect-video">
                      <img src={imgUrl} alt={`Venture photo ${idx + 1}`} className="w-full h-full object-cover" />
                      <button
                        onClick={() => handleRemovePhoto(idx)}
                        className="absolute top-2 right-2 p-1.5 bg-red-600/80 hover:bg-red-700 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete photo"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Videos Management Section */}
              <div className="space-y-4 pt-6 border-t border-slate-800">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Video className="w-4 h-4 text-emerald-400" /> Drone & Walkthrough Videos ({mediaVideos.length} Videos)
                </h4>

                {/* Add new video input */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="Video Title (e.g. Drone Survey 4K)"
                    value={newVideoTitle}
                    onChange={(e) => setNewVideoTitle(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <input
                    type="url"
                    placeholder="Video URL (YouTube or MP4)"
                    value={newVideoUrl}
                    onChange={(e) => setNewVideoUrl(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    onClick={handleAddVideo}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Add Video
                  </button>
                </div>

                {/* Videos List */}
                <div className="space-y-2">
                  {mediaVideos.map((vid, idx) => (
                    <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                      <div className="space-y-0.5">
                        <strong className="text-white block">{vid.title}</strong>
                        <span className="text-slate-400 font-mono text-[11px]">{vid.url}</span>
                      </div>
                      <button
                        onClick={() => handleRemoveVideo(idx)}
                        className="text-red-400 hover:text-red-300 p-1.5 rounded-lg hover:bg-red-950/40 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  {mediaVideos.length === 0 && (
                    <p className="text-xs text-slate-500 italic">No videos added yet for this venture.</p>
                  )}
                </div>
              </div>

              {/* Save Button */}
              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  onClick={handleSaveMedia}
                  disabled={mediaSaving}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-lg transition flex items-center gap-2 disabled:opacity-50"
                >
                  <Save className="w-4 h-4" /> {mediaSaving ? 'Saving Changes...' : 'Save Photos & Videos to Database'}
                </button>
              </div>

            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 4: SITE VISIT APPOINTMENTS */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'appointments' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden overflow-x-auto shadow-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="p-3">Ref Code</th>
                    <th className="p-3">Client Name</th>
                    <th className="p-3">Phone</th>
                    <th className="p-3">Venture & Plot</th>
                    <th className="p-3">Visit Date & Slot</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {appointments.map((apt) => (
                    <tr key={apt.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3 font-mono font-bold text-emerald-400">{apt.reference_code}</td>
                      <td className="p-3 font-bold text-white">{apt.customer_name}</td>
                      <td className="p-3 text-slate-300">{apt.customer_phone}</td>
                      <td className="p-3 text-slate-300">
                        {apt.venture_name || 'B.N Golden County'} {apt.plot_number ? `(Plot #${apt.plot_number})` : ''}
                      </td>
                      <td className="p-3 text-slate-200">
                        {apt.preferred_date} • <span className="text-emerald-400 font-semibold">{apt.time_slot}</span>
                      </td>
                      <td className="p-3">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          apt.status === 'confirmed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          apt.status === 'cancelled' ? 'bg-red-950 text-red-400 border border-red-800' :
                          'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}>
                          {apt.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleUpdateAppointment(apt.id, 'confirmed')}
                            className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-[11px] font-semibold px-2 py-1 rounded"
                          >
                            Confirm
                          </button>
                          <button
                            onClick={() => handleUpdateAppointment(apt.id, 'cancelled')}
                            className="bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800 text-[11px] font-semibold px-2 py-1 rounded"
                          >
                            Cancel
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {appointments.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-500 italic">No site visits scheduled yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 5: PLOT RESERVATIONS */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'bookings' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden overflow-x-auto shadow-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="p-3">Booking Ref</th>
                    <th className="p-3">Customer Name</th>
                    <th className="p-3">Phone</th>
                    <th className="p-3">Plot #</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Date</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {bookings.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3 font-mono font-bold text-emerald-400">{b.reference_code}</td>
                      <td className="p-3 font-bold text-white">{b.customer_name}</td>
                      <td className="p-3 text-slate-300">{b.customer_phone}</td>
                      <td className="p-3 text-amber-300 font-bold">Plot {b.plot_number}</td>
                      <td className="p-3">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          b.status === 'approved' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          b.status === 'rejected' ? 'bg-red-950 text-red-400 border border-red-800' :
                          'bg-amber-950 text-amber-400 border border-amber-800 animate-pulse'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                      <td className="p-3 text-slate-400">{b.created_at?.slice(0, 10)}</td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleUpdateBooking(b.id, 'approved')}
                            className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-[11px] font-semibold px-2 py-1 rounded"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleUpdateBooking(b.id, 'rejected')}
                            className="bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800 text-[11px] font-semibold px-2 py-1 rounded"
                          >
                            Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {bookings.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-500 italic">No bookings submitted yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 6: CUSTOMER ENQUIRIES */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'enquiries' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 divide-y divide-slate-800/60">
              {enquiries.map((enq) => (
                <div key={enq.id} className="py-4 first:pt-0 last:pb-0 space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-white text-sm">{enq.customer_name}</h4>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                        <span>📞 {enq.customer_phone}</span>
                        {enq.customer_email && <span>✉️ {enq.customer_email}</span>}
                      </div>
                    </div>
                    <span className="text-xs text-slate-500">{enq.created_at?.slice(0, 16)}</span>
                  </div>
                  <p className="text-xs text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800/60">
                    "{enq.message}"
                  </p>
                </div>
              ))}
              {enquiries.length === 0 && (
                <div className="p-8 text-center text-slate-500 italic">No customer enquiries received yet.</div>
              )}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 7: OWASP SECURITY AUDIT LOGS */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'security' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Header info card */}
            <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      <ShieldCheck className="w-3.5 h-3.5" /> OWASP Top 10 Compliant
                    </span>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                      <Sparkles className="w-3.5 h-3.5" /> VAPT 31/31 Passed
                    </span>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                      <Lock className="w-3.5 h-3.5" /> 10-Year Active Audit Trail
                    </span>
                  </div>
                  <h3 className="text-xl font-display font-bold text-white flex items-center gap-2">
                    Real-Time Security & VAPT Intrusion Audit Logs
                  </h3>
                  <p className="text-xs text-slate-400 max-w-2xl">
                    Every authentication request, plot reservation attempt, administrative action, and rate-limiting shield event is cryptographically recorded with client IP and browser fingerprint.
                  </p>
                </div>
                <button
                  onClick={loadSecurityLogs}
                  disabled={loadingLogs}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingLogs ? 'animate-spin text-emerald-400' : ''}`} />
                  Refresh Logs
                </button>
              </div>

              {/* Status metrics grid */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-5 border-t border-slate-800/80">
                <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">A04 Rate Limiter</span>
                  <div className="text-sm font-bold text-emerald-400 mt-0.5">Sliding Window Active</div>
                  <span className="text-[10px] text-slate-500">Max 5 Auth / 15m</span>
                </div>
                <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">A07 Brute-Force Lockout</span>
                  <div className="text-sm font-bold text-emerald-400 mt-0.5">5 Fails = 15m Lock</div>
                  <span className="text-[10px] text-slate-500">Auto-defends passwords</span>
                </div>
                <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">A08 Blueprint Magic Bytes</span>
                  <div className="text-sm font-bold text-emerald-400 mt-0.5">Binary Verified</div>
                  <span className="text-[10px] text-slate-500">PNG/JPG/SVG/WEBP</span>
                </div>
                <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">VAPT 31-Point Audit</span>
                  <div className="text-sm font-bold text-purple-400 mt-0.5">100% Mitigated</div>
                  <span className="text-[10px] text-slate-500">31/31 Checks Passed</span>
                </div>
                <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Total Recorded Events</span>
                  <div className="text-sm font-bold text-white mt-0.5">{securityLogs.length} Events</div>
                  <span className="text-[10px] text-slate-500">Persistent SQLite Store</span>
                </div>
              </div>
            </div>

            {/* Logs Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
                <h4 className="font-bold text-sm text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-400" />
                  Recent Security Events
                </h4>
                <span className="text-xs text-slate-400">Showing last {securityLogs.length} events</span>
              </div>

              {loadingLogs ? (
                <div className="p-12 text-center text-slate-400">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto text-emerald-400 mb-2" />
                  Loading secure audit logs...
                </div>
              ) : securityLogs.length === 0 ? (
                <div className="p-12 text-center text-slate-500 italic">
                  No security incidents or audit entries recorded yet. All shields are active and scanning.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="px-4 py-3 font-semibold">Timestamp</th>
                        <th className="px-4 py-3 font-semibold">Event Type</th>
                        <th className="px-4 py-3 font-semibold">Status</th>
                        <th className="px-4 py-3 font-semibold">IP Address</th>
                        <th className="px-4 py-3 font-semibold">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                      {securityLogs.map((log: any) => {
                        const isSuccess = log.status === 'SUCCESS';
                        const isBlocked = log.status === 'BLOCKED' || log.status === 'LOCKED';
                        return (
                          <tr key={log.id} className="hover:bg-slate-800/40 transition">
                            <td className="px-4 py-3 text-slate-400 whitespace-nowrap">
                              {log.created_at ? log.created_at.slice(0, 19).replace('T', ' ') : '—'}
                            </td>
                            <td className="px-4 py-3">
                              <span className="font-bold text-white tracking-wide">
                                {log.event_type}
                              </span>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span
                                className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase ${
                                  isSuccess
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                    : isBlocked
                                    ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                }`}
                              >
                                {log.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-slate-400 whitespace-nowrap">
                              {log.ip_address || '127.0.0.1'}
                            </td>
                            <td className="px-4 py-3 text-slate-300 max-w-xs truncate font-sans">
                              {log.details || '—'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

      </main>

      {/* ======================================================== */}
      {/* MODAL: EDIT PLOT RECORD (Requirement 6 & 10) */}
      {/* ======================================================== */}
      {editingPlot && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 space-y-4 text-xs">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h4 className="font-display font-bold text-lg text-white">
                Edit Plot Record — {editingPlot.plot_number}
              </h4>
              <button onClick={() => setEditingPlot(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdatePlot} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Plot Number</label>
                  <input
                    type="text"
                    value={editingPlot.plot_number}
                    onChange={(e) => setEditingPlot({ ...editingPlot, plot_number: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Status</label>
                  <select
                    value={editingPlot.status}
                    onChange={(e) => setEditingPlot({ ...editingPlot, status: e.target.value as PlotStatus })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  >
                    <option value="available">🟢 Available (Green)</option>
                    <option value="pending">🟡 Pending (Yellow)</option>
                    <option value="booked">🔴 Booked (Red)</option>
                    <option value="sold">🔴 Sold (Red)</option>
                    <option value="blocked">⚫ Blocked (Black)</option>
                  </select>
                </div>
              </div>

              {/* Requirement 10: Owner Name Display Directly on Layout */}
              <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl space-y-1">
                <label className="text-amber-400 font-bold flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4" /> Plot Owner's Name (Appears directly on Booked Plot)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ramesh Reddy"
                  value={editingPlot.owner_name || ''}
                  onChange={(e) => setEditingPlot({ ...editingPlot, owner_name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-medium"
                />
                <span className="text-[10px] text-slate-500">
                  When plot is Booked or Sold, this name is displayed directly inside the plot rectangle on the 2D layout.
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Area (Sq.Yards)</label>
                  <input
                    type="number"
                    value={editingPlot.area_sqyd}
                    onChange={(e) => setEditingPlot({ ...editingPlot, area_sqyd: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Price / Sq.Yard (₹)</label>
                  <input
                    type="number"
                    value={editingPlot.price_per_sqyd}
                    onChange={(e) => setEditingPlot({ ...editingPlot, price_per_sqyd: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Facing Direction</label>
                  <select
                    value={editingPlot.facing}
                    onChange={(e) => setEditingPlot({ ...editingPlot, facing: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  >
                    <option value="East">East</option>
                    <option value="West">West</option>
                    <option value="North">North</option>
                    <option value="South">South</option>
                    <option value="North-East">North-East</option>
                    <option value="South-East">South-East</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Road Width (Feet)</label>
                  <input
                    type="number"
                    value={editingPlot.road_width_ft}
                    onChange={(e) => setEditingPlot({ ...editingPlot, road_width_ft: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Corner Plot?</label>
                  <select
                    value={editingPlot.is_corner}
                    onChange={(e) => setEditingPlot({ ...editingPlot, is_corner: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  >
                    <option value={0}>No (Regular Plot)</option>
                    <option value={1}>Yes (Corner Plot)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Sector / Block Name</label>
                  <input
                    type="text"
                    value={editingPlot.block_name}
                    onChange={(e) => setEditingPlot({ ...editingPlot, block_name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="pt-4 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingPlot(null)}
                  className="bg-slate-800 text-slate-300 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2 rounded-xl"
                >
                  Save Changes to Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ADD NEW PLOT */}
      {/* ======================================================== */}
      {isAddPlotOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 space-y-4 text-xs">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h4 className="font-display font-bold text-lg text-white">
                Add New Plot to Master Layout
              </h4>
              <button onClick={() => setIsAddPlotOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePlot} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Assign to Venture</label>
                  <select
                    value={newPlotForm.venture_id}
                    onChange={(e) => setNewPlotForm({ ...newPlotForm, venture_id: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  >
                    {ventures.map((v) => (
                      <option key={v.id} value={v.id}>{v.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Plot Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. P-137"
                    value={newPlotForm.plot_number}
                    onChange={(e) => setNewPlotForm({ ...newPlotForm, plot_number: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Area in Sq.Yards *</label>
                  <input
                    type="number"
                    required
                    value={newPlotForm.area_sqyd}
                    onChange={(e) => setNewPlotForm({ ...newPlotForm, area_sqyd: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Price per Sq.Yard (₹) *</label>
                  <input
                    type="number"
                    required
                    value={newPlotForm.price_per_sqyd}
                    onChange={(e) => setNewPlotForm({ ...newPlotForm, price_per_sqyd: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Facing Direction</label>
                  <select
                    value={newPlotForm.facing}
                    onChange={(e) => setNewPlotForm({ ...newPlotForm, facing: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  >
                    <option value="East">East</option>
                    <option value="West">West</option>
                    <option value="North">North</option>
                    <option value="South">South</option>
                    <option value="North-East">North-East</option>
                    <option value="South-East">South-East</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Initial Status</label>
                  <select
                    value={newPlotForm.status}
                    onChange={(e) => setNewPlotForm({ ...newPlotForm, status: e.target.value as PlotStatus })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  >
                    <option value="available">Available (Green)</option>
                    <option value="pending">Pending (Yellow)</option>
                    <option value="booked">Booked (Red)</option>
                    <option value="blocked">Blocked (Black)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">Owner Name (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Srikanth Varma"
                  value={newPlotForm.owner_name || ''}
                  onChange={(e) => setNewPlotForm({ ...newPlotForm, owner_name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                />
              </div>

              <div className="pt-4 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddPlotOpen(false)}
                  className="bg-slate-800 text-slate-300 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2 rounded-xl"
                >
                  Save New Plot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: IMPORT VENTURE DATA (ADMIN EXCLUSIVE) */}
      {/* ======================================================== */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 space-y-4 text-xs">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h4 className="font-display font-bold text-lg text-white flex items-center gap-2">
                  <Upload className="w-5 h-5 text-emerald-400" />
                  Import Venture & Plot Master Package
                </h4>
                <p className="text-[11px] text-slate-400">
                  Admin-only capability to bulk-import ventures, district, pincode, pricing, and all 2D SVG plot layouts.
                </p>
              </div>
              <button 
                onClick={() => { setIsImportModalOpen(false); setImportMessage(null); }} 
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Action Shortcuts */}
            <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 space-y-2.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block">
                Quick-Start Import Options
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleLoadSampleTemplate}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 transition text-xs font-semibold"
                >
                  <FileCode className="w-3.5 h-3.5 text-blue-400" /> Load Nirmal (504106) Sample Template
                </button>

                <label className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 transition text-xs font-semibold cursor-pointer">
                  <FileText className="w-3.5 h-3.5 text-amber-400" /> Upload .JSON File
                  <input
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (evt) => {
                          setImportJsonText(evt.target?.result as string || '');
                        };
                        reader.readAsText(file);
                      }
                    }}
                  />
                </label>
              </div>
            </div>

            {/* Import Status Banner */}
            {importMessage && (
              <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                importMessage.type === 'success' 
                  ? 'bg-emerald-950/80 border-emerald-800 text-emerald-200' 
                  : 'bg-red-950/80 border-red-800 text-red-200'
              }`}>
                {importMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                )}
                <span>{importMessage.text}</span>
              </div>
            )}

            {/* JSON Input Area */}
            <form onSubmit={handleImportJsonSubmit} className="space-y-3">
              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  Venture Package JSON Payload (includes Venture details + Plots array)
                </label>
                <textarea
                  rows={10}
                  required
                  placeholder='Paste your JSON package here, e.g. { "venture": { "name": "...", "district": "Nirmal", "pincode": "504106", ... }, "plots": [ ... ] }'
                  value={importJsonText}
                  onChange={(e) => setImportJsonText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono text-[11px] focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-between items-center pt-2">
                <span className="text-[10px] text-slate-500">
                  Data will be validated and synced directly into the live database.
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => { setIsImportModalOpen(false); setImportMessage(null); }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={importLoading || !importJsonText.trim()}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl shadow-lg transition flex items-center gap-2 disabled:opacity-50"
                  >
                    {importLoading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Importing...
                      </>
                    ) : (
                      <>
                        <Upload className="w-3.5 h-3.5" /> Execute Import & Save
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ADD NEW VENTURE (ADMIN EXCLUSIVE) */}
      {/* ======================================================== */}
      {isAddVentureOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h4 className="font-display font-bold text-lg text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-emerald-400" />
                  Add New Venture to Portfolio
                </h4>
                <p className="text-[11px] text-slate-400">
                  Enter complete venture details, location, and pricing information.
                </p>
              </div>
              <button onClick={() => setIsAddVentureOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateVenture} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Venture Name (English) *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. B.N Nirmal Greenfield County"
                    value={newVentureForm.name}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">URL Slug (Unique) *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. bn-nirmal-greenfield-county"
                    value={newVentureForm.slug}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, slug: e.target.value.toLowerCase().replace(/\\s+/g, '-') })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              {/* District & Pincode */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
                <div>
                  <label className="text-emerald-400 font-bold block mb-1">District *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Nirmal"
                    value={newVentureForm.district || ''}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, district: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-emerald-400 font-bold block mb-1">Pincode *</label>
                  <input
                    type="text"
                    required
                    placeholder="504106"
                    value={newVentureForm.pincode || ''}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, pincode: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">City / Town *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Nirmal"
                    value={newVentureForm.city}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, city: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Location Details (English)</label>
                  <input
                    type="text"
                    placeholder="e.g. NH-44 Bypass & Mancherial Road"
                    value={newVentureForm.location}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, location: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Location Details (Telugu)</label>
                  <input
                    type="text"
                    placeholder="e.g. NH-44 బైపాస్ రోడ్డు, నిర్మల్"
                    value={newVentureForm.location_te || ''}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, location_te: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Min Price / Sq.Yd (₹)</label>
                  <input
                    type="number"
                    value={newVentureForm.price_per_sqyd_min}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, price_per_sqyd_min: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Max Price / Sq.Yd (₹)</label>
                  <input
                    type="number"
                    value={newVentureForm.price_per_sqyd_max}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, price_per_sqyd_max: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Total Plots Count</label>
                  <input
                    type="number"
                    value={newVentureForm.total_plots}
                    onChange={(e) => setNewVentureForm({ ...newVentureForm, total_plots: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">Hero Image URL</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={newVentureForm.hero_image || ''}
                  onChange={(e) => setNewVentureForm({ ...newVentureForm, hero_image: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddVentureOpen(false)}
                  className="bg-slate-800 text-slate-300 font-bold px-4 py-2 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl transition shadow-lg"
                >
                  Save Venture
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: EDIT VENTURE (ADMIN EXCLUSIVE) */}
      {/* ======================================================== */}
      {editingVenture && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h4 className="font-display font-bold text-lg text-white flex items-center gap-2">
                  <Edit className="w-5 h-5 text-emerald-400" />
                  Edit Venture: {editingVenture.name}
                </h4>
                <p className="text-[11px] text-slate-400">
                  Update venture details, district, pincode, pricing, and amenities.
                </p>
              </div>
              <button onClick={() => setEditingVenture(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateVenture} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Venture Name *</label>
                  <input
                    type="text"
                    required
                    value={editingVenture.name}
                    onChange={(e) => setEditingVenture({ ...editingVenture, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Status</label>
                  <input
                    type="text"
                    value={editingVenture.status || ''}
                    onChange={(e) => setEditingVenture({ ...editingVenture, status: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              {/* District & Pincode */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
                <div>
                  <label className="text-emerald-400 font-bold block mb-1">District</label>
                  <input
                    type="text"
                    value={editingVenture.district || ''}
                    onChange={(e) => setEditingVenture({ ...editingVenture, district: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-emerald-400 font-bold block mb-1">Pincode</label>
                  <input
                    type="text"
                    value={editingVenture.pincode || ''}
                    onChange={(e) => setEditingVenture({ ...editingVenture, pincode: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">City</label>
                  <input
                    type="text"
                    value={editingVenture.city}
                    onChange={(e) => setEditingVenture({ ...editingVenture, city: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Location Details</label>
                  <input
                    type="text"
                    value={editingVenture.location}
                    onChange={(e) => setEditingVenture({ ...editingVenture, location: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Tagline</label>
                  <input
                    type="text"
                    value={editingVenture.tagline || ''}
                    onChange={(e) => setEditingVenture({ ...editingVenture, tagline: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Min Price / Sq.Yd (₹)</label>
                  <input
                    type="number"
                    value={editingVenture.price_per_sqyd_min}
                    onChange={(e) => setEditingVenture({ ...editingVenture, price_per_sqyd_min: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Max Price / Sq.Yd (₹)</label>
                  <input
                    type="number"
                    value={editingVenture.price_per_sqyd_max}
                    onChange={(e) => setEditingVenture({ ...editingVenture, price_per_sqyd_max: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Total Plots</label>
                  <input
                    type="number"
                    value={editingVenture.total_plots}
                    onChange={(e) => setEditingVenture({ ...editingVenture, total_plots: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">Hero Image URL</label>
                <input
                  type="url"
                  value={editingVenture.hero_image || ''}
                  onChange={(e) => setEditingVenture({ ...editingVenture, hero_image: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                />
              </div>

              <div>
                <label className="text-emerald-400 font-bold block mb-1 flex items-center gap-1.5">
                  <Layers className="w-4 h-4" /> 2D Architectural Layout Blueprint Image / File
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="/uploads/layouts/... or https://..."
                    value={editingVenture.layout_image_url || ''}
                    onChange={(e) => setEditingVenture({ ...editingVenture, layout_image_url: e.target.value })}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono text-xs"
                  />
                  <label className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3 py-2 rounded-xl cursor-pointer flex items-center gap-1.5 shrink-0 transition">
                    <Upload className="w-3.5 h-3.5" /> Upload File
                    <input
                      type="file"
                      accept="image/*,.svg"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = async (evt) => {
                          try {
                            const base64Data = evt.target?.result as string;
                            const res = await api.uploadLayout(file.name, base64Data);
                            setEditingVenture({ ...editingVenture, layout_image_url: res.url });
                            alert('2D Layout blueprint uploaded successfully!');
                          } catch (err: any) {
                            alert(err.message || 'Failed to upload layout');
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingVenture(null)}
                  className="bg-slate-800 text-slate-300 font-bold px-4 py-2 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl transition shadow-lg"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: 2D LAYOUT & VENTURE STUDIO (ADMIN EXCLUSIVE) */}
      {/* ======================================================== */}
      {isLayoutStudioOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-7xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            
            {/* Studio Header */}
            <div className="bg-slate-950 p-4 sm:p-5 border-b border-slate-800 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black shadow-lg shadow-emerald-950/60">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display font-black text-lg sm:text-xl text-white flex items-center gap-2">
                    2D Layout & Venture Studio
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold px-2 py-0.5 rounded border border-emerald-500/30 uppercase tracking-widest">
                      Website Auto-Creates 3D
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Import 2D layout photo only. The website automatically generates its own interactive 3D view for public visitors.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsLayoutStudioOpen(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Studio Body (2 Columns) */}
            <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
              
              {/* LEFT COLUMN: Controls & Configurator (5 cols) */}
              <div className="lg:col-span-5 p-5 space-y-4 overflow-y-auto max-h-[calc(94vh-140px)]">
                
                {/* Method Switcher Tabs */}
                <div className="flex bg-slate-950 p-1 rounded-2xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setStudioTab('photo');
                      syncStudioToJson();
                    }}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
                      studioTab === 'photo'
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950/60'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Upload className="w-3.5 h-3.5" /> 📸 1. Upload 2D Layout Photo
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setStudioTab('code');
                      syncStudioToJson();
                    }}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
                      studioTab === 'code'
                        ? 'bg-amber-600 text-white shadow-lg shadow-amber-950/60'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <FileCode className="w-3.5 h-3.5" /> 💻 2. Layout Code (JSON)
                  </button>
                </div>

                {/* TAB 1: PHOTO UPLOAD & VISUAL CONFIGURATOR */}
                {studioTab === 'photo' && (
                  <div className="space-y-4">
                    {/* 1. Upload Blueprint Card */}
                    <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Upload className="w-4 h-4" /> 1. Upload 2D Layout Photo / Blueprint
                        </span>
                        {studioVenture.layout_image_url && (
                          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-semibold px-2 py-0.5 rounded">
                            ✓ 2D Photo Attached
                          </span>
                        )}
                      </div>

                      <div className="bg-emerald-950/30 border border-emerald-500/20 p-2.5 rounded-xl text-[11px] text-emerald-300/90 flex items-start gap-2">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>
                          <strong>Admin imports 2D only:</strong> Upload your 2D layout photo, survey map or blueprint image. The website engine automatically calculates and creates its own interactive 3D conceptual view without requiring you to build it!
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <label className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2.5 px-4 rounded-xl cursor-pointer transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50">
                          <Upload className="w-4 h-4" />
                          <span>{isUploadingLayout ? 'Uploading 2D Photo...' : 'Select & Upload 2D Layout Photo'}</span>
                          <input
                            type="file"
                            accept="image/*,.svg"
                            className="hidden"
                            onChange={handleStudioLayoutFileUpload}
                            disabled={isUploadingLayout}
                          />
                        </label>

                        {studioVenture.layout_image_url && (
                          <button
                            type="button"
                            onClick={() => {
                              const updated = { ...studioVenture, layout_image_url: '' };
                              setStudioVenture(updated);
                              syncStudioToJson(updated, studioPlots);
                            }}
                            className="text-xs text-red-400 hover:text-red-300 bg-red-950/40 hover:bg-red-950 border border-red-900/60 px-3 py-2.5 rounded-xl font-semibold transition"
                          >
                            Remove
                          </button>
                        )}
                      </div>

                      {studioUploadMessage && (
                        <div className="text-[11px] text-emerald-300 bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-800/60 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>{studioUploadMessage}</span>
                        </div>
                      )}

                      {studioVenture.layout_image_url && (
                        <div className="relative h-24 rounded-xl overflow-hidden border border-slate-800 bg-slate-900">
                          <img
                            src={studioVenture.layout_image_url}
                            alt="Blueprint Preview"
                            className="w-full h-full object-cover"
                          />
                          <span className="absolute bottom-1 right-2 text-[10px] bg-black/80 text-slate-300 px-1.5 py-0.5 rounded font-mono">
                            {studioVenture.layout_image_url.split('/').pop()}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* 2. Venture Details Card */}
                    <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
                      <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                        2. Venture Profile Information
                      </span>

                      <div>
                        <label className="text-[11px] text-slate-300 font-bold block mb-1">Venture Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. B.N Nirmal Greenfield County Phase 2"
                          value={studioVenture.name}
                          onChange={(e) => {
                            const updated = { ...studioVenture, name: e.target.value };
                            setStudioVenture(updated);
                            syncStudioToJson(updated, studioPlots);
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                        />
                      </div>

                      {/* District & Pincode (Nirmal 504106 Focused) */}
                      <div className="grid grid-cols-2 gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                        <div>
                          <label className="text-[10px] text-emerald-400 font-bold block mb-0.5">District *</label>
                          <input
                            type="text"
                            value={studioVenture.district}
                            onChange={(e) => {
                              const updated = { ...studioVenture, district: e.target.value };
                              setStudioVenture(updated);
                              syncStudioToJson(updated, studioPlots);
                            }}
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-xs text-white"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-emerald-400 font-bold block mb-0.5">Pincode *</label>
                          <input
                            type="text"
                            value={studioVenture.pincode}
                            onChange={(e) => {
                              const updated = { ...studioVenture, pincode: e.target.value };
                              setStudioVenture(updated);
                              syncStudioToJson(updated, studioPlots);
                            }}
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-xs text-white font-mono"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[11px] text-slate-300 font-bold block mb-1">Location Details *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. NH-44 Highway Bypass, Nirmal"
                          value={studioVenture.location}
                          onChange={(e) => {
                            const updated = { ...studioVenture, location: e.target.value };
                            setStudioVenture(updated);
                            syncStudioToJson(updated, studioPlots);
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] text-slate-300 font-bold block mb-1">Min Price / Sq.Yd (₹)</label>
                          <input
                            type="number"
                            value={studioVenture.price_per_sqyd_min}
                            onChange={(e) => {
                              const updated = { ...studioVenture, price_per_sqyd_min: Number(e.target.value) };
                              setStudioVenture(updated);
                              syncStudioToJson(updated, studioPlots);
                            }}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-slate-300 font-bold block mb-1">Max Price / Sq.Yd (₹)</label>
                          <input
                            type="number"
                            value={studioVenture.price_per_sqyd_max}
                            onChange={(e) => {
                              const updated = { ...studioVenture, price_per_sqyd_max: Number(e.target.value) };
                              setStudioVenture(updated);
                              syncStudioToJson(updated, studioPlots);
                            }}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white font-mono"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[11px] text-slate-300 font-bold block mb-1">RERA Registration #</label>
                        <input
                          type="text"
                          value={studioVenture.rera_number}
                          onChange={(e) => {
                            const updated = { ...studioVenture, rera_number: e.target.value };
                            setStudioVenture(updated);
                            syncStudioToJson(updated, studioPlots);
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] text-slate-300 font-bold block mb-1">Tagline</label>
                        <input
                          type="text"
                          value={studioVenture.tagline}
                          onChange={(e) => {
                            const updated = { ...studioVenture, tagline: e.target.value };
                            setStudioVenture(updated);
                            syncStudioToJson(updated, studioPlots);
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    {/* 3. Grid Matrix Generator */}
                    <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Grid className="w-4 h-4" /> 3. Layout Grid Matrix Generator
                        </span>
                        <span className="text-xs font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
                          {studioPlots.length} Plots
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <label className="text-[10px] text-slate-400 font-bold block mb-1">Sectors / Rows</label>
                          <select
                            value={studioRows}
                            onChange={(e) => setStudioRows(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                          >
                            <option value={2}>2 Sectors (e.g. 24 plots)</option>
                            <option value={3}>3 Sectors (e.g. 36 plots)</option>
                            <option value={4}>4 Sectors (e.g. 48 plots)</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 font-bold block mb-1">Plots per Row</label>
                          <input
                            type="number"
                            min={4}
                            max={16}
                            value={studioCols}
                            onChange={(e) => setStudioCols(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 font-bold block mb-1">Default Sq.Yards</label>
                          <input
                            type="number"
                            value={studioDefaultArea}
                            onChange={(e) => setStudioDefaultArea(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 font-bold block mb-1">Default Facing</label>
                          <select
                            value={studioDefaultFacing}
                            onChange={(e) => setStudioDefaultFacing(e.target.value as any)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                          >
                            <option value="East">East</option>
                            <option value="North">North</option>
                            <option value="West">West</option>
                            <option value="South">South</option>
                          </select>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => generateStudioGrid(studioRows, studioCols, studioDefaultArea, studioDefaultFacing, studioStartPlotNum, studioVenture.price_per_sqyd_min)}
                        className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold py-2 rounded-xl transition flex items-center justify-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-emerald-400" /> Regenerate Layout Grid ({studioRows * studioCols} Plots)
                      </button>
                    </div>

                    {/* 4. Selected Plot Quick-Customizer */}
                    {studioSelectedPlotIndex !== null && studioPlots[studioSelectedPlotIndex] && (
                      <div className="bg-emerald-950/40 p-4 rounded-2xl border border-emerald-800/60 space-y-3 animate-in fade-in">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                            <Edit3 className="w-4 h-4" /> Edit Plot: {studioPlots[studioSelectedPlotIndex].plot_number}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            Plot #{studioSelectedPlotIndex + 1} of {studioPlots.length}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <label className="text-[10px] text-slate-300 font-bold block mb-1">Plot Number</label>
                            <input
                              type="text"
                              value={studioPlots[studioSelectedPlotIndex].plot_number}
                              onChange={(e) => {
                                const val = e.target.value;
                                setStudioPlots(prev => {
                                  const updated = prev.map((p, idx) => idx === studioSelectedPlotIndex ? { ...p, plot_number: val } : p);
                                  syncStudioToJson(studioVenture, updated);
                                  return updated;
                                });
                              }}
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white font-mono"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] text-slate-300 font-bold block mb-1">Status</label>
                            <select
                              value={studioPlots[studioSelectedPlotIndex].status}
                              onChange={(e) => {
                                const val = e.target.value;
                                setStudioPlots(prev => {
                                  const updated = prev.map((p, idx) => idx === studioSelectedPlotIndex ? { ...p, status: val } : p);
                                  syncStudioToJson(studioVenture, updated);
                                  return updated;
                                });
                              }}
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                            >
                              <option value="available">🟢 Available (Green)</option>
                              <option value="pending">🟡 Pending (Yellow)</option>
                              <option value="booked">🔴 Booked (Red)</option>
                              <option value="sold">🔴 Sold (Red)</option>
                              <option value="blocked">⚫ Blocked (Black)</option>
                            </select>
                          </div>
                        </div>

                        {/* Owner Name Input (Requirement 10) */}
                        <div>
                          <label className="text-[10px] text-amber-400 font-bold block mb-1 flex items-center gap-1">
                            <UserCheck className="w-3.5 h-3.5" /> Plot Owner's Name (Appears live on Booked Plot)
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Srikanth Reddy (Retd. Officer, Nirmal)"
                            value={studioPlots[studioSelectedPlotIndex].owner_name || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              setStudioPlots(prev => {
                                const updated = prev.map((p, idx) => idx === studioSelectedPlotIndex ? { 
                                  ...p, 
                                  owner_name: val,
                                  status: val ? (p.status === 'available' ? 'booked' : p.status) : p.status
                                } : p);
                                syncStudioToJson(studioVenture, updated);
                                return updated;
                              });
                            }}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white"
                          />
                          <span className="text-[10px] text-slate-400 mt-0.5 block">
                            When booked or sold, this owner name renders directly on the plot in the 2D layout.
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <label className="text-[10px] text-slate-300 font-bold block mb-1">Facing</label>
                            <select
                              value={studioPlots[studioSelectedPlotIndex].facing}
                              onChange={(e) => {
                                const val = e.target.value;
                                setStudioPlots(prev => {
                                  const updated = prev.map((p, idx) => idx === studioSelectedPlotIndex ? { ...p, facing: val } : p);
                                  syncStudioToJson(studioVenture, updated);
                                  return updated;
                                });
                              }}
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                            >
                              <option value="East">East</option>
                              <option value="West">West</option>
                              <option value="North">North</option>
                              <option value="South">South</option>
                            </select>
                          </div>

                          <div>
                            <label className="text-[10px] text-slate-300 font-bold block mb-1">Area (Sq.Yds)</label>
                            <input
                              type="number"
                              value={studioPlots[studioSelectedPlotIndex].area_sqyd}
                              onChange={(e) => {
                                const val = Number(e.target.value);
                                setStudioPlots(prev => {
                                  const updated = prev.map((p, idx) => idx === studioSelectedPlotIndex ? { ...p, area_sqyd: val } : p);
                                  syncStudioToJson(studioVenture, updated);
                                  return updated;
                                });
                              }}
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 2: ENTER LAYOUT CODE (JSON FORMAT) */}
                {studioTab === 'code' && (
                  <div className="space-y-4">
                    <div className="bg-amber-950/30 p-3.5 rounded-2xl border border-amber-800/40 text-xs text-amber-200 space-y-1">
                      <span className="font-extrabold flex items-center gap-1.5 text-amber-300 text-sm">
                        <FileCode className="w-4 h-4 text-amber-400" /> Enter Venture & Layout Code (JSON)
                      </span>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Paste your full venture JSON code with venture details and plots array. Click <strong>"Apply Code to 2D Layout"</strong> — the website automatically creates its own 3D conceptual view on its own!
                      </p>
                    </div>

                    {studioCodeError && (
                      <div className="p-3 bg-red-950/70 border border-red-800 text-red-200 rounded-xl text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                        <span>{studioCodeError}</span>
                      </div>
                    )}

                    {studioCodeSuccess && (
                      <div className="p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-200 rounded-xl text-xs flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                        <span>{studioCodeSuccess}</span>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={handleLoadExampleCode}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-lg border border-slate-700 transition flex items-center gap-1.5"
                      >
                        <Copy className="w-3.5 h-3.5 text-emerald-400" /> 📋 Load Example Layout Code
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(studioJsonCode);
                          alert('Layout code copied to clipboard!');
                        }}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-700 transition flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-400" /> Copy Code
                      </button>
                    </div>

                    <div>
                      <textarea
                        value={studioJsonCode}
                        onChange={(e) => setStudioJsonCode(e.target.value)}
                        rows={16}
                        placeholder="Paste your layout code JSON here..."
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-emerald-300 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500 leading-relaxed max-h-[360px]"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={handleApplyCodeToStudio}
                      className="w-full bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-extrabold py-3 px-4 rounded-xl shadow-lg shadow-amber-950/60 transition flex items-center justify-center gap-2 text-xs transform active:scale-98"
                    >
                      <Sparkles className="w-4 h-4 text-white" /> ⚡ Apply Code to 2D Layout (Website Auto-Creates 3D)
                    </button>
                  </div>
                )}

              </div>

              {/* RIGHT COLUMN: Live Interactive 2D or 360° 3D Preview Canvas (7 cols) */}
              <div className="lg:col-span-7 p-5 flex flex-col justify-between space-y-4 bg-slate-950/60">
                
                {/* Canvas Header & 2D / 3D Switcher */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      {studioPreviewMode === '2d' ? <Compass className="w-4 h-4" /> : <Rotate3d className="w-4 h-4" />}
                    </div>
                    <div>
                      <h4 className="font-display font-extrabold text-sm text-white">
                        {studioPreviewMode === '2d' ? 'Live 2D Master Blueprint Layout' : 'Website Auto-Generated 3D View'}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {studioPreviewMode === '2d' 
                          ? 'Click any plot rectangle to edit its details or owner name.' 
                          : 'Website engine auto-generates 360° conceptual 3D view directly from your 2D layout.'}
                      </p>
                    </div>
                  </div>

                  {/* 2D vs 3D vs Blueprint Switcher */}
                  <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    <button
                      type="button"
                      onClick={() => setStudioPreviewMode('2d')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                        studioPreviewMode === '2d' 
                          ? 'bg-emerald-600 text-white shadow' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Compass className="w-3.5 h-3.5" /> 2D Vector SVG
                    </button>
                    <button
                      type="button"
                      onClick={() => setStudioPreviewMode('3d')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                        studioPreviewMode === '3d' 
                          ? 'bg-emerald-600 text-white shadow' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Rotate3d className="w-3.5 h-3.5 text-amber-300" /> Website Auto-Created 3D
                    </button>
                    {studioVenture.layout_image_url && (
                      <button
                        type="button"
                        onClick={() => setStudioPreviewMode('blueprint')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                          studioPreviewMode === 'blueprint' 
                            ? 'bg-emerald-600 text-white shadow' 
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-blue-300" /> Uploaded Blueprint
                      </button>
                    )}
                  </div>
                </div>

                {/* 2D SVG Canvas (100% Pure Vector - Zero Background Photo Interference) */}
                {studioPreviewMode === '2d' && (
                  <div className="w-full bg-[#0c1322] rounded-2xl border-2 border-slate-800 overflow-hidden shadow-2xl relative">
                    <svg viewBox="0 0 1020 720" className="w-full h-auto max-h-[500px]">
                      <defs>
                        <pattern id="studioGridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
                          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.8" />
                        </pattern>
                      </defs>

                      {/* Canvas Background */}
                      <rect width="1020" height="720" fill="#0b1120" />
                      <rect width="1020" height="720" fill="url(#studioGridPattern)" />

                      {/* Perimeter Wall */}
                      <rect x="30" y="30" width="960" height="660" fill="none" stroke="#475569" strokeWidth="3" strokeDasharray="8,5" rx="16" />

                      {/* Roads */}
                      <rect x="40" y="260" width="670" height="45" fill="#1e293b" rx="4" />
                      <text x="375" y="287" fill="#f8fafc" fontSize="13" fontWeight="900" letterSpacing="3" textAnchor="middle">
                        ★ 40 FEET MAIN ROAD (40 అడుగుల తారు రోడ్డు) ★
                      </text>

                      <rect x="40" y="475" width="670" height="35" fill="#1e293b" rx="4" />
                      <text x="375" y="497" fill="#94a3b8" fontSize="11" fontWeight="bold" letterSpacing="2" textAnchor="middle">
                        33 FEET SECTOR ROAD
                      </text>

                      {/* Central Park Zone (Rendered only when not occupied by plots) */}
                      {!studioPlots.some(p => p.pos_x >= 730 && p.pos_y < 540) && (
                        <g transform="translate(740, 75)">
                          <rect width="210" height="230" fill="#064e3b" rx="16" stroke="#059669" strokeWidth="2.5" />
                          <text x="105" y="35" fill="#a7f3d0" fontSize="14" fontWeight="900" textAnchor="middle">
                            CENTRAL PARK
                          </text>
                          <text x="105" y="55" fill="#6ee7b7" fontSize="11" fontWeight="bold" textAnchor="middle">
                            ల్యాండ్‌స్కేప్డ్ పచ్చని పార్క్
                          </text>
                          <circle cx="50" cy="110" r="16" fill="#047857" />
                          <circle cx="160" cy="110" r="16" fill="#047857" />
                          <circle cx="105" cy="160" r="20" fill="#047857" />
                        </g>
                      )}

                      {/* Clubhouse Zone (Rendered only when not occupied by plots) */}
                      {!studioPlots.some(p => p.pos_x >= 730 && p.pos_y < 540) && (
                        <g transform="translate(740, 335)">
                          <rect width="210" height="210" fill="#0f172a" rx="16" stroke="#3b82f6" strokeWidth="2.5" />
                          <text x="105" y="35" fill="#93c5fd" fontSize="14" fontWeight="900" textAnchor="middle">
                            CLUBHOUSE & POOL
                          </text>
                          <rect x="35" y="65" width="140" height="60" fill="#0284c7" rx="8" />
                          <text x="105" y="100" fill="#ffffff" fontSize="11" fontWeight="900" textAnchor="middle">
                            SWIMMING POOL
                          </text>
                        </g>
                      )}

                      {/* Entrance Gate */}
                      {!studioPlots.some(p => p.pos_x >= 730 && p.pos_y < 540) && (
                        <g transform="translate(730, 580)">
                          <rect width="180" height="55" fill="#047857" rx="10" stroke="#10b981" strokeWidth="2" />
                          <text x="90" y="28" fill="#ffffff" fontSize="12" fontWeight="900" textAnchor="middle">
                            B.N SECURITY ARCH
                          </text>
                          <text x="90" y="44" fill="#d1fae5" fontSize="9" fontWeight="bold" textAnchor="middle">
                            24/7 CCTV & RFID గేటు
                          </text>
                        </g>
                      )}

                      {/* Plots */}
                      {studioPlots.map((plot, idx) => {
                        const isSelected = studioSelectedPlotIndex === idx;
                        let fill = '#10b981'; // Green: Available
                        if (plot.status === 'pending') fill = '#f59e0b'; // Yellow: Pending
                        else if (plot.status === 'booked' || plot.status === 'sold') fill = '#dc2626'; // Red: Booked
                        else if (plot.status === 'blocked') fill = '#111827'; // Black: Blocked

                        return (
                          <g
                            key={idx}
                            onClick={() => setStudioSelectedPlotIndex(idx)}
                            className="cursor-pointer transition-all duration-150"
                          >
                            <rect
                              x={plot.pos_x}
                              y={plot.pos_y}
                              width={plot.width}
                              height={plot.height}
                              fill={fill}
                              fillOpacity={0.92}
                              stroke={isSelected ? '#38bdf8' : '#047857'}
                              strokeWidth={isSelected ? 4 : 2}
                              rx="5"
                            />

                            {/* Plot Number */}
                            <text
                              x={plot.pos_x + plot.width / 2}
                              y={plot.pos_y + 24}
                              fill={plot.status === 'blocked' ? '#ffffff' : '#0f172a'}
                              fontSize="13"
                              fontWeight="900"
                              textAnchor="middle"
                              pointerEvents="none"
                            >
                              {plot.plot_number}
                            </text>

                            {/* Plot Area */}
                            <text
                              x={plot.pos_x + plot.width / 2}
                              y={plot.pos_y + 40}
                              fill={plot.status === 'blocked' ? '#e2e8f0' : '#1e293b'}
                              fontSize="10"
                              fontWeight="bold"
                              textAnchor="middle"
                              pointerEvents="none"
                            >
                              {plot.area_sqyd} yd² ({plot.facing ? plot.facing[0] : 'E'})
                            </text>

                            {/* Owner Name Label Banner (Requirement 10) */}
                            {plot.owner_name ? (
                              <g>
                                <rect
                                  x={plot.pos_x + 3}
                                  y={plot.pos_y + plot.height - 30}
                                  width={plot.width - 6}
                                  height="24"
                                  fill="#000000"
                                  fillOpacity="0.8"
                                  rx="3"
                                />
                                <text
                                  x={plot.pos_x + plot.width / 2}
                                  y={plot.pos_y + plot.height - 14}
                                  fill="#fef08a"
                                  fontSize="9"
                                  fontWeight="900"
                                  textAnchor="middle"
                                  pointerEvents="none"
                                >
                                  {plot.owner_name.length > 9 ? plot.owner_name.substring(0, 8) + '..' : plot.owner_name}
                                </text>
                              </g>
                            ) : (
                              <g>
                                <rect
                                  x={plot.pos_x + 3}
                                  y={plot.pos_y + plot.height - 20}
                                  width={plot.width - 6}
                                  height="15"
                                  fill="#000000"
                                  fillOpacity="0.45"
                                  rx="3"
                                />
                                <text
                                  x={plot.pos_x + plot.width / 2}
                                  y={plot.pos_y + plot.height - 9}
                                  fill="#ffffff"
                                  fontSize="8.5"
                                  fontWeight="bold"
                                  textAnchor="middle"
                                  pointerEvents="none"
                                >
                                  ₹{Math.round((plot.price_per_sqyd || 12000) / 1000)}k/yd
                                </text>
                              </g>
                            )}
                          </g>
                        );
                      })}
                    </svg>
                  </div>
                )}

                {/* 360° 3D Conceptual View Canvas */}
                {studioPreviewMode === '3d' && (
                  <div className="w-full h-[500px] rounded-2xl overflow-hidden border-2 border-slate-800 shadow-2xl relative bg-slate-950">
                    <ThreeDPlotView
                      plots={studioPlots.map((p, idx) => ({
                        id: p.id || (idx + 1),
                        venture_id: 1,
                        plot_number: p.plot_number,
                        area_sqyd: p.area_sqyd || 200,
                        dimension_length: p.dimension_length || 50,
                        dimension_width: p.dimension_width || 36,
                        facing: p.facing || 'East',
                        price_per_sqyd: p.price_per_sqyd || studioVenture.price_per_sqyd_min || 12500,
                        total_price: p.total_price || ((p.area_sqyd || 200) * (p.price_per_sqyd || 12500)),
                        is_corner: p.is_corner || 0,
                        road_width_ft: p.road_width_ft || 33,
                        status: p.status || 'available',
                        block_name: p.block_name || 'Sector A',
                        pos_x: p.pos_x || (60 + (idx % 12) * 60),
                        pos_y: p.pos_y || (75 + Math.floor(idx / 12) * 150),
                        width: p.width || 55,
                        height: p.height || 115,
                        owner_name: p.owner_name || ''
                      }))}
                      selectedPlot={studioSelectedPlotIndex !== null ? studioPlots[studioSelectedPlotIndex] : null}
                      onSelectPlot={(p) => {
                        const foundIdx = studioPlots.findIndex(x => x.plot_number === p.plot_number);
                        if (foundIdx !== -1) setStudioSelectedPlotIndex(foundIdx);
                      }}
                      ventureName={studioVenture.name}
                    />
                  </div>
                )}

                {/* Uploaded Blueprint Document Viewer */}
                {studioPreviewMode === 'blueprint' && (
                  <div className="w-full bg-[#0c1322] rounded-2xl border-2 border-slate-800 p-4 shadow-2xl space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-300">
                      <span className="font-bold text-white flex items-center gap-1.5">
                        <ImageIcon className="w-4 h-4 text-emerald-400" /> Uploaded Blueprint / Survey Map
                      </span>
                      {studioVenture.layout_image_url && (
                        <a
                          href={studioVenture.layout_image_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-emerald-400 hover:underline flex items-center gap-1 font-bold"
                        >
                          Open Full Image <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                    <div className="h-[500px] rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-2">
                      {studioVenture.layout_image_url ? (
                        <img
                          src={studioVenture.layout_image_url}
                          alt="Uploaded Blueprint"
                          className="max-w-full max-h-full object-contain rounded-lg shadow-xl"
                        />
                      ) : (
                        <div className="text-center text-slate-500 py-8">
                          <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-40 text-slate-600" />
                          <p className="text-sm">No layout image or PDF uploaded yet.</p>
                          <p className="text-xs text-slate-600 mt-1">Upload an image or PDF in the left panel to preview it here.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Footer Save & Publish Bar */}
                <div className="pt-2 flex flex-col sm:flex-row justify-between items-center gap-3 border-t border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Ready to publish {studioPlots.length} plots under {studioVenture.district} District ({studioVenture.pincode})</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsLayoutStudioOpen(false)}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs px-4 py-2.5 rounded-xl transition"
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      onClick={handleSaveStudioVenture}
                      disabled={studioSaving}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-950/60 transition flex items-center gap-2 disabled:opacity-50"
                    >
                      {studioSaving ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" /> Saving & Publishing...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4" /> Save & Publish Venture to Live Website
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
