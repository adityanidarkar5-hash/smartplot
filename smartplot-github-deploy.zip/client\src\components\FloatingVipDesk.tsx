import React, { useState } from 'react';
import { MessageCircle, Phone, Calendar, X, Sparkles, MapPin, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';

interface FloatingVipDeskProps {
  currentLang: Language;
  onOpenSiteVisit: () => void;
  selectedLocation: string;
}

export const FloatingVipDesk: React.FC<FloatingVipDeskProps> = ({
  currentLang,
  onOpenSiteVisit,
  selectedLocation,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const phone = '+919876543210';
  const whatsappUrl = `https://wa.me/919876543210?text=${encodeURIComponent(
    currentLang === 'te'
      ? 'నమస్కారం B.N వెంచర్స్, నేను నిర్మల్ జిల్లా (504106) / హైదరాబాద్ వెంచర్లలో ప్లాట్ల ధరలు, DTCP లేఅవుట్ మ్యాప్ మరియు సైట్ విజిట్ సమాచారం తెలుసుకోవాలనుకుంటున్నాను.'
      : 'Hello B.N Ventures, I am interested in DTCP & RERA approved plots in Nirmal District (504106) / Hyderabad. Please share layout details, price per sq.yd, and arrange a site visit.'
  )}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 select-none">
      
      {/* Expandable VIP Menu Popover */}
      {isOpen && (
        <div className="mb-3 w-80 bg-slate-900 border-2 border-emerald-500 rounded-3xl p-5 shadow-2xl text-white space-y-4 animate-in zoom-in-95 duration-200 backdrop-blur-xl">
          
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md">
                <Sparkles className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h4 className="font-display font-extrabold text-sm text-white">
                  {currentLang === 'te' ? 'B.N వీఐపీ హెల్ప్‌డెస్క్' : 'B.N VIP Priority Desk'}
                </h4>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>{currentLang === 'te' ? 'యజమాని ఆన్‌లైన్‌లో ఉన్నారు' : 'Owner Online Now'}</span>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-[11px] text-slate-300 leading-relaxed">
            {currentLang === 'te'
              ? 'నిర్మల్ జిల్లా (504106) మరియు ఇతర వెంచర్ల ప్లాట్ ప్లాన్‌లు, స్పష్టమైన టైటిల్ డాక్యుమెంట్లు మరియు ధరల కోసం నేరుగా సంప్రదించండి.'
              : 'Direct hotline for DTCP layouts, spot registration bookings, and site visits in Nirmal District (504106) & Hyderabad.'}
          </p>

          {/* Quick Action Buttons */}
          <div className="space-y-2">
            {/* WhatsApp */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noreferrer"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>{currentLang === 'te' ? 'వాట్సాప్‌లో మాట్లాడండి' : 'Chat on WhatsApp (Instant)'}</span>
            </a>

            {/* Direct Phone Call */}
            <a
              href={`tel:${phone}`}
              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs py-2.5 px-4 rounded-xl border border-slate-700 transition flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>{currentLang === 'te' ? 'డైరెక్ట్ కాల్ చేయండి (+91 98765 43210)' : 'Direct Call (+91 98765 43210)'}</span>
            </a>
          </div>

          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" /> DTCP & RERA
            </span>
            <span>10 Years Trust</span>
          </div>

        </div>
      )}

      {/* Floating Main Pill Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs sm:text-sm py-3 px-4 sm:px-5 rounded-full shadow-[0_10px_30px_rgba(5,150,105,0.4)] border-2 border-white/20 transition-all flex items-center gap-2.5 hover:scale-105 active:scale-95 group cursor-pointer"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-200 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
        </span>

        <MessageCircle className="w-5 h-5 fill-white group-hover:rotate-12 transition-transform" />
        
        <span className="hidden sm:inline font-display">
          {currentLang === 'te' ? 'ఇన్‌స్టంట్ వాట్సాప్ డెస్క్' : 'Instant WhatsApp VIP Desk'}
        </span>
        <span className="sm:hidden font-display">VIP Helpdesk</span>
      </button>

    </div>
  );
};
