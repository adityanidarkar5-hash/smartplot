import React, { useState } from 'react';
import { Search, Compass, Sparkles, Layers, Heart, RotateCcw, ArrowUpDown, UserCheck } from 'lucide-react';
import { Plot, Venture, Language } from '../types';
import { t } from '../i18n';

interface PlotDirectoryProps {
  plots: Plot[];
  ventures: Venture[];
  onSelectPlot: (plot: Plot) => void;
  onReservePlot: (plot: Plot) => void;
  onToggleFavourite: (plotId: number) => void;
  favouritePlotIds: number[];
  onAddToCompare: (plot: Plot) => void;
  comparedPlotIds: number[];
  lang?: Language;
}

export const PlotDirectory: React.FC<PlotDirectoryProps> = ({
  plots,
  ventures,
  onSelectPlot,
  onReservePlot,
  onToggleFavourite,
  favouritePlotIds,
  onAddToCompare,
  comparedPlotIds,
  lang = 'en',
}) => {
  const [selectedVentureId, setSelectedVentureId] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [facingFilter, setFacingFilter] = useState<string>('');
  const [cornerFilter, setCornerFilter] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<number>(8000000);
  const [sortBy, setSortBy] = useState<'plot_asc' | 'price_asc' | 'price_desc' | 'area_asc' | 'area_desc'>('plot_asc');

  const resetFilters = () => {
    setSelectedVentureId('');
    setStatusFilter('');
    setFacingFilter('');
    setCornerFilter('');
    setSearchQuery('');
    setMaxPrice(8000000);
    setSortBy('plot_asc');
  };

  // Filter plots
  const filteredPlots = plots.filter((p) => {
    const matchesVenture = !selectedVentureId || p.venture_id === Number(selectedVentureId);
    const matchesStatus = !statusFilter || p.status === statusFilter;
    const matchesFacing = !facingFilter || p.facing === facingFilter;
    const matchesCorner = !cornerFilter || p.is_corner === Number(cornerFilter);
    const matchesSearch = !searchQuery || 
      p.plot_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.block_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.owner_name && p.owner_name.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesPrice = p.total_price <= maxPrice;

    return matchesVenture && matchesStatus && matchesFacing && matchesCorner && matchesSearch && matchesPrice;
  });

  // Sort plots
  filteredPlots.sort((a, b) => {
    if (sortBy === 'price_asc') return a.total_price - b.total_price;
    if (sortBy === 'price_desc') return b.total_price - a.total_price;
    if (sortBy === 'area_asc') return a.area_sqyd - b.area_sqyd;
    if (sortBy === 'area_desc') return b.area_sqyd - a.area_sqyd;
    return a.id - b.id;
  });

  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-8">
        
        {/* Page Title */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100/70 px-3.5 py-1.5 rounded-full border border-emerald-300">
            <Compass className="w-4 h-4 text-emerald-700" /> B.N Ventures — {t(lang, 'explorePlots')}
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-navy-950">
            {lang === 'te' ? 'ప్లాట్లను శోధించండి & ఎంచుకోండి' : 'Explore & Filter Plots'}
          </h2>
          <p className="text-navy-600 text-sm sm:text-base max-w-2xl font-medium">
            {lang === 'te' 
              ? 'వెంచర్, ఫేసింగ్, గజాల విస్తీర్ణం, మరియు లభ్యత ఆధారంగా ప్లాట్లను సులభంగా శోధించండి. బుక్ అయిన ప్లాట్లపై యజమాని పేరు కూడా చూడవచ్చు.' 
              : 'Filter plots by venture location, facing, square yard area, corner attributes, and live availability status. Owner names appear on booked plots.'}
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-navy-100 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            
            {/* Search Plot # or Owner Name */}
            <div>
              <label className="block text-xs font-bold uppercase text-navy-700 mb-1">
                {lang === 'te' ? 'ప్లాట్ నెం / యజమాని' : 'Plot # or Owner'}
              </label>
              <div className="relative">
                <Search className="w-4 h-4 text-navy-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder={lang === 'te' ? "ఉదా: P-105 లేదా పేరు" : "e.g. P-105 or Name"}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-navy-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>
            </div>

            {/* Venture Selector */}
            <div>
              <label className="block text-xs font-bold uppercase text-navy-700 mb-1">
                {lang === 'te' ? 'వెంచర్' : 'Venture'}
              </label>
              <select
                value={selectedVentureId}
                onChange={(e) => setSelectedVentureId(e.target.value)}
                className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">{lang === 'te' ? 'అన్ని వెంచర్లు' : 'All Ventures'}</option>
                {ventures.map((v) => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div>
              <label className="block text-xs font-bold uppercase text-navy-700 mb-1">
                {lang === 'te' ? 'లభ్యత (రంగు)' : 'Availability'}
              </label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">{lang === 'te' ? 'అన్ని రంగులు' : 'All Statuses'}</option>
                <option value="available">🟢 {t(lang, 'available')} (Green)</option>
                <option value="pending">🟡 {t(lang, 'pending')} (Yellow)</option>
                <option value="booked">🔴 {t(lang, 'booked')} (Red)</option>
                <option value="sold">🔴 Sold (Red)</option>
                <option value="blocked">⚫ {t(lang, 'blocked')} (Black)</option>
              </select>
            </div>

            {/* Facing Filter */}
            <div>
              <label className="block text-xs font-bold uppercase text-navy-700 mb-1">
                {lang === 'te' ? 'దిశ (Facing)' : 'Facing'}
              </label>
              <select
                value={facingFilter}
                onChange={(e) => setFacingFilter(e.target.value)}
                className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">{lang === 'te' ? 'అన్ని దిశలు' : 'All Facings'}</option>
                <option value="East">East (తూర్పు)</option>
                <option value="West">West (పడమర)</option>
                <option value="North">North (ఉత్తరం)</option>
                <option value="South">South (దక్షిణం)</option>
                <option value="North-East">North-East (ఈశాన్యం)</option>
                <option value="South-East">South-East (ఆగ్నేయం)</option>
              </select>
            </div>

            {/* Corner Filter */}
            <div>
              <label className="block text-xs font-bold uppercase text-navy-700 mb-1">
                {lang === 'te' ? 'కార్నర్ ప్లాట్' : 'Corner Status'}
              </label>
              <select
                value={cornerFilter}
                onChange={(e) => setCornerFilter(e.target.value)}
                className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">{lang === 'te' ? 'అన్ని ప్లాట్లు' : 'All Plots'}</option>
                <option value="1">★ {lang === 'te' ? 'కార్నర్ మాత్రమే' : 'Corner Only'}</option>
                <option value="0">{lang === 'te' ? 'సాధారణ ప్లాట్' : 'Regular Only'}</option>
              </select>
            </div>

          </div>

          {/* Budget Range & Sort */}
          <div className="pt-3 border-t border-navy-100 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-navy-700">{lang === 'te' ? 'గరిష్ట బడ్జెట్:' : 'Max Budget:'}</span>
              <input
                type="range"
                min="3000000"
                max="8000000"
                step="250000"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer w-48"
              />
              <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-300">
                ₹{(maxPrice / 100000).toFixed(1)} {lang === 'te' ? 'లక్షల లోపు' : 'Lakhs'}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs text-navy-600 font-medium">
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>{lang === 'te' ? 'క్రమం:' : 'Sort By:'}</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-slate-50 border border-navy-200 rounded-lg px-2.5 py-1 text-xs text-navy-900 font-semibold"
                >
                  <option value="plot_asc">{lang === 'te' ? 'ప్లాట్ నెంబర్' : 'Plot Number'}</option>
                  <option value="price_asc">{lang === 'te' ? 'తక్కువ ధర మొదట' : 'Price: Low to High'}</option>
                  <option value="price_desc">{lang === 'te' ? 'ఎక్కువ ధర మొదట' : 'Price: High to Low'}</option>
                  <option value="area_asc">{lang === 'te' ? 'తక్కువ విస్తీర్ణం' : 'Area: Low to High'}</option>
                  <option value="area_desc">{lang === 'te' ? 'ఎక్కువ విస్తీర్ణం' : 'Area: High to Low'}</option>
                </select>
              </div>

              <button
                onClick={resetFilters}
                className="text-xs text-navy-600 hover:text-navy-950 flex items-center gap-1 hover:underline font-bold"
              >
                <RotateCcw className="w-3.5 h-3.5" /> {lang === 'te' ? 'రీసెట్' : 'Reset'}
              </button>
            </div>
          </div>
        </div>

        {/* Result Counter */}
        <div className="flex justify-between items-center text-xs text-navy-600 font-medium">
          <span>{lang === 'te' ? 'లభించిన ప్లాట్లు:' : 'Showing'} <strong className="text-navy-950 font-bold text-sm">{filteredPlots.length}</strong> {lang === 'te' ? 'ప్లాట్లు' : 'matching plots'}</span>
          <span>{lang === 'te' ? 'వివరాలకు ప్లాట్‌పై క్లిక్ చేయండి' : 'Click any plot to inspect or reserve'}</span>
        </div>

        {/* Plots Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPlots.map((plot) => {
            const isFav = favouritePlotIds.includes(plot.id);
            const isComp = comparedPlotIds.includes(plot.id);

            return (
              <div
                key={plot.id}
                onClick={() => onSelectPlot(plot)}
                className="group bg-white rounded-2xl border border-navy-100 hover:border-emerald-400 p-5 shadow-sm hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between space-y-4"
              >
                {/* Header info */}
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-display font-extrabold text-xl text-navy-950 group-hover:text-emerald-700 transition">
                          Plot {plot.plot_number}
                        </span>
                        {plot.is_corner === 1 && (
                          <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-1.5 py-0.5 rounded">
                            ★ Corner
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-navy-500 font-medium block">{plot.block_name}</span>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      plot.status === 'available' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                      plot.status === 'pending' ? 'bg-amber-100 text-amber-800 border border-amber-300 animate-pulse' :
                      plot.status === 'blocked' ? 'bg-slate-900 text-white' :
                      'bg-red-100 text-red-800 border border-red-300'
                    }`}>
                      {plot.status === 'available' ? (lang === 'te' ? 'లభ్యం' : 'Available') :
                       plot.status === 'pending' ? (lang === 'te' ? 'పెండింగ్' : 'Pending') :
                       plot.status === 'blocked' ? (lang === 'te' ? 'బ్లాక్ చేయబడింది' : 'Blocked') :
                       (lang === 'te' ? 'బుక్ చేయబడింది' : 'Booked')}
                    </span>
                  </div>

                  {/* Spec Row */}
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <span className="text-[10px] text-navy-500 font-semibold block">{t(lang, 'plotArea')}</span>
                      <strong className="text-navy-950 font-bold">{plot.area_sqyd} sq.yd</strong>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <span className="text-[10px] text-navy-500 font-semibold block">{t(lang, 'facing')}</span>
                      <strong className="text-emerald-700 font-bold">{plot.facing}</strong>
                    </div>
                  </div>

                  <div className="text-[11px] text-navy-600 font-medium flex justify-between pt-1">
                    <span>{t(lang, 'roadWidth')}: {plot.road_width_ft} ft</span>
                    <span>{plot.dimension_length}' × {plot.dimension_width}'</span>
                  </div>

                  {/* Requirement 10: Owner Name Display on Booked / Sold plots */}
                  {plot.owner_name && (plot.status === 'booked' || plot.status === 'sold' || plot.status === 'pending') && (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-2 flex items-center gap-1.5 text-xs text-red-900 font-bold">
                      <UserCheck className="w-4 h-4 text-red-600 shrink-0" />
                      <span className="truncate">{t(lang, 'owner')}: {plot.owner_name}</span>
                    </div>
                  )}
                </div>

                {/* Bottom Consideration & Quick Action */}
                <div className="pt-3 border-t border-navy-100 space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs text-navy-500 font-medium">{t(lang, 'totalPrice')}</span>
                    <strong className="font-display font-black text-lg text-emerald-700">
                      ₹{plot.total_price.toLocaleString('en-IN')}
                    </strong>
                  </div>

                  <div className="flex items-center gap-2 pt-1" onClick={(e) => e.stopPropagation()}>
                    {plot.status === 'available' ? (
                      <button
                        onClick={() => onReservePlot(plot)}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-sm flex items-center justify-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" /> {t(lang, 'reserveOnline')}
                      </button>
                    ) : (
                      <button
                        onClick={() => onSelectPlot(plot)}
                        className="flex-1 bg-slate-100 hover:bg-slate-200 text-navy-800 text-xs font-bold py-2.5 rounded-xl transition"
                      >
                        {lang === 'te' ? 'వివరాలు చూడండి' : 'View Details'}
                      </button>
                    )}

                    <button
                      onClick={() => onToggleFavourite(plot.id)}
                      className="p-2 border border-navy-200 rounded-xl hover:bg-slate-50 text-navy-600 transition"
                      title="Save Favourite"
                    >
                      <Heart className={`w-4 h-4 ${isFav ? 'fill-red-500 text-red-500' : ''}`} />
                    </button>

                    <button
                      onClick={() => onAddToCompare(plot)}
                      className={`p-2 border rounded-xl transition ${
                        isComp ? 'bg-blue-50 border-blue-300 text-blue-700' : 'border-navy-200 hover:bg-slate-50 text-navy-600'
                      }`}
                      title="Compare"
                    >
                      <Layers className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredPlots.length === 0 && (
          <div className="bg-white rounded-3xl p-12 text-center space-y-3 border border-navy-100">
            <Compass className="w-12 h-12 text-slate-300 mx-auto" />
            <h4 className="font-display font-bold text-lg text-navy-950">
              {lang === 'te' ? 'ప్లాట్లు కనుగొనబడలేదు' : 'No plots match your criteria'}
            </h4>
            <p className="text-xs text-navy-500 max-w-sm mx-auto">
              {lang === 'te' ? 'దయచేసి మీ ఫిల్టర్‌లను సవరించండి.' : 'Try adjusting your price filter, facing direction, or search query.'}
            </p>
            <button
              onClick={resetFilters}
              className="bg-emerald-600 text-white font-bold text-xs py-2.5 px-5 rounded-xl shadow"
            >
              {lang === 'te' ? 'అన్ని ఫిల్టర్లు రీసెట్ చేయండి' : 'Reset All Filters'}
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
