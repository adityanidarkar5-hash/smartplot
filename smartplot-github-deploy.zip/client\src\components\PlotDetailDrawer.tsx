import React from 'react';
import { 
  X, 
  MapPin, 
  Compass, 
  Ruler, 
  ShieldCheck, 
  Calendar, 
  PhoneCall, 
  Sparkles,
  UserCheck,
  Calculator
} from 'lucide-react';
import { Plot, PlotStatus, Language } from '../types';
import { translations } from '../i18n';

interface PlotDetailDrawerProps {
  plot: Plot | null;
  onClose: () => void;
  onReserve: (plot: Plot) => void;
  onBookSiteVisit: (plot: Plot) => void;
  onOpenCalculator?: (plot: Plot) => void;
  currentLang?: Language;
}

export const PlotDetailDrawer: React.FC<PlotDetailDrawerProps> = ({
  plot,
  onClose,
  onReserve,
  onBookSiteVisit,
  onOpenCalculator,
  currentLang = 'en',
}) => {
  if (!plot) return null;

  const t = translations[currentLang];

  const getStatusBadge = (status: PlotStatus) => {
    switch (status) {
      case 'available':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-900 border border-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
            {t.statusAvailable}
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-300">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            {t.statusPending}
          </span>
        );
      case 'booked':
      case 'sold':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-red-100 text-red-900 border border-red-300">
            <span className="w-2 h-2 rounded-full bg-red-600"></span>
            {t.statusBooked}
          </span>
        );
      case 'blocked':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-slate-900 text-slate-100 border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-slate-400"></span>
            {t.statusBlocked}
          </span>
        );
    }
  };

  const whatsappMessage = encodeURIComponent(
    `Hello B.N Ventures! I am interested in Plot *${plot.plot_number}* in ${plot.venture_name || 'B.N Golden County'}.\n` +
    `• Area: ${plot.area_sqyd} sq.yds\n` +
    `• Facing: ${plot.facing}\n` +
    `• Total Price: ₹${plot.total_price.toLocaleString('en-IN')}\n\n` +
    `Please share layout documents and arrange a site visit.`
  );

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white shadow-2xl border-l-2 border-navy-200 flex flex-col animate-in slide-in-from-right duration-300">
      
      {/* Header */}
      <div className="p-5 border-b border-navy-100 flex items-center justify-between bg-slate-50">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-black text-2xl text-navy-950">
              Plot {plot.plot_number}
            </span>
            {plot.is_corner === 1 && (
              <span className="bg-amber-100 text-amber-900 text-[11px] font-black px-2 py-0.5 rounded-full border border-amber-300">
                ★ {currentLang === 'te' ? 'కార్నర్ ప్లాట్' : 'Corner Plot'}
              </span>
            )}
          </div>
          <p className="text-xs text-navy-600 font-bold mt-0.5">
            {plot.block_name} • {plot.venture_name || 'B.N Golden County'}
          </p>
        </div>

        <button
          onClick={onClose}
          className="p-2 rounded-xl border border-navy-200 hover:bg-white text-navy-700 transition"
          title="Close Panel"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Body Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        {/* Status & Price Highlight Card */}
        <div className="bg-gradient-to-br from-slate-900 to-navy-950 text-white rounded-3xl p-5 shadow-lg border border-navy-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              {currentLang === 'te' ? 'ప్లాట్ స్థితి' : 'Current Status'}
            </span>
            {getStatusBadge(plot.status)}
          </div>

          {/* Requirement 10: Owner Name Display */}
          {plot.owner_name && (
            <div className="bg-amber-400/20 border-2 border-amber-400/50 p-3 rounded-2xl flex items-center gap-2.5">
              <UserCheck className="w-5 h-5 text-amber-300 shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-300 block">
                  {t.bookedByLabel}
                </span>
                <strong className="text-base text-white font-display font-black">
                  {plot.owner_name}
                </strong>
              </div>
            </div>
          )}

          <div className="pt-2 border-t border-slate-800">
            <span className="text-xs text-slate-400">
              {currentLang === 'te' ? 'మొత్తం ప్లాట్ ధర' : 'Total Plot Price'}
            </span>
            <div className="text-3xl font-display font-black text-emerald-400 flex items-baseline gap-1">
              ₹{plot.total_price.toLocaleString('en-IN')}
            </div>
            <div className="text-xs text-slate-300 mt-1 font-semibold">
              {currentLang === 'te' ? 'ధర / చ.గజం:' : 'Rate:'} <strong className="text-white">₹{plot.price_per_sqyd.toLocaleString('en-IN')}</strong> / sq.yd
            </div>
          </div>
        </div>

        {/* Specifications Matrix */}
        <div className="space-y-3">
          <h4 className="text-xs font-black uppercase tracking-wider text-navy-700 flex items-center gap-1.5">
            <Ruler className="w-4 h-4 text-emerald-600" />
            {currentLang === 'te' ? 'ప్లాట్ కొలతలు & వివరాలు' : 'Plot Dimensions & Specifications'}
          </h4>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-slate-50 border border-navy-100 rounded-2xl p-3">
              <span className="text-xs text-navy-500 font-bold block">{currentLang === 'te' ? 'విస్తీర్ణం' : 'Area'}</span>
              <strong className="font-extrabold text-navy-950 text-base">{plot.area_sqyd} sq.yards</strong>
              <span className="text-[11px] text-navy-500 block">({(plot.area_sqyd * 9).toLocaleString('en-IN')} sq.ft)</span>
            </div>

            <div className="bg-slate-50 border border-navy-100 rounded-2xl p-3">
              <span className="text-xs text-navy-500 font-bold block">{currentLang === 'te' ? 'ఫేసింగ్ (దిశ)' : 'Facing'}</span>
              <strong className="font-extrabold text-emerald-800 text-base flex items-center gap-1">
                <Compass className="w-4 h-4 text-emerald-600" />
                {plot.facing}
              </strong>
              <span className="text-[11px] text-emerald-700 block font-bold">100% Vaastu Compliant</span>
            </div>

            <div className="bg-slate-50 border border-navy-100 rounded-2xl p-3">
              <span className="text-xs text-navy-500 font-bold block">{currentLang === 'te' ? 'కొలతలు (L × W)' : 'Dimensions'}</span>
              <strong className="font-extrabold text-navy-950 text-base">
                {plot.dimension_length}' × {plot.dimension_width}'
              </strong>
              <span className="text-[11px] text-navy-500 block">Feet</span>
            </div>

            <div className="bg-slate-50 border border-navy-100 rounded-2xl p-3">
              <span className="text-xs text-navy-500 font-bold block">{currentLang === 'te' ? 'రోడ్డు వెడల్పు' : 'Road Width'}</span>
              <strong className="font-extrabold text-navy-950 text-base">
                {plot.road_width_ft} Feet Road
              </strong>
              <span className="text-[11px] text-navy-500 block">Blacktop Tar Road</span>
            </div>
          </div>
        </div>

        {/* Legal Title Clear Guarantee */}
        <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-4 text-xs space-y-2">
          <div className="flex items-center gap-2 font-black text-emerald-950">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{currentLang === 'te' ? 'B.N వెంచర్స్ 10 సంవత్సరాల నిజాయితీ భరోసా' : '10 Years of Proven Legal Due Diligence'}</span>
          </div>
          <p className="text-emerald-900 leading-relaxed font-medium">
            {currentLang === 'te'
              ? 'ఈ ప్లాట్‌కు పూర్తి 30 సంవత్సరాల లింక్ డాక్యుమెంట్లు పక్కాగా ఉన్నాయి. సబ్-రిజిస్ట్రార్ ఆఫీస్‌లో వెంటనే స్పాట్ రిజిస్ట్రేషన్ అందుబాటులో ఉంది.'
              : 'Complete 30-year certified title search documents. DTCP & RERA approved layout with immediate spot registration facility.'}
          </p>
        </div>

      </div>

      {/* Action Footer Buttons */}
      <div className="p-5 border-t border-navy-200 bg-white space-y-2">
        {onOpenCalculator && (
          <button
            onClick={() => onOpenCalculator(plot)}
            className="w-full bg-slate-100 hover:bg-slate-200 text-navy-900 font-extrabold py-2.5 px-3 rounded-xl transition text-xs flex items-center justify-center gap-2 border border-navy-200"
          >
            <Calculator className="w-4 h-4 text-emerald-600" />
            <span>{currentLang === 'te' ? 'బ్యాంక్ లోన్ & EMI క్యాలిక్యులేటర్' : 'Calculate Bank Loan & Monthly EMI'}</span>
          </button>
        )}

        {plot.status === 'available' ? (
          <button
            onClick={() => onReserve(plot)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-lg transition flex items-center justify-center gap-2 text-sm"
          >
            <Sparkles className="w-4 h-4 text-emerald-200" />
            <span>{t.reserveTitle} ({plot.plot_number})</span>
          </button>
        ) : (
          <div className="w-full bg-slate-100 text-navy-700 text-xs font-bold py-2.5 px-3 rounded-xl text-center border border-navy-200">
            Plot {plot.plot_number} {currentLang === 'te' ? 'ఇప్పటికే బుక్ అయింది' : `is currently ${plot.status.toUpperCase()}`}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => onBookSiteVisit(plot)}
            className="w-full bg-navy-900 hover:bg-navy-950 text-white font-bold py-3 px-3 rounded-xl transition text-xs flex items-center justify-center gap-1.5"
          >
            <Calendar className="w-4 h-4 text-emerald-400" />
            <span>{t.bookSiteVisit}</span>
          </button>

          <a
            href={`https://wa.me/919876543210?text=${whatsappMessage}`}
            target="_blank"
            rel="noreferrer"
            className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-extrabold py-3 px-3 rounded-xl transition text-xs flex items-center justify-center gap-1.5"
          >
            <PhoneCall className="w-4 h-4 text-emerald-600" />
            <span>{t.whatsappDesk}</span>
          </a>
        </div>
      </div>

    </div>
  );
};
