import React from 'react';
import { MapPin, ArrowRight, FileText, CheckCircle2, Compass, Layers, Video, Navigation, ExternalLink } from 'lucide-react';
import { Venture, Language } from '../types';
import { translations } from '../i18n';
import { openInGoogleMaps } from '../utils/googleMaps';

interface FeaturedVenturesProps {
  ventures: Venture[];
  selectedLocation: string;
  onSelectVenture: (venture: Venture) => void;
  onOpenBrochure: (venture: Venture) => void;
  currentLang: Language;
}

export const FeaturedVentures: React.FC<FeaturedVenturesProps> = ({
  ventures,
  selectedLocation,
  onSelectVenture,
  onOpenBrochure,
  currentLang,
}) => {
  const t = translations[currentLang];

  const filteredVentures = selectedLocation 
    ? ventures.filter(v => 
        (v.city && v.city.toLowerCase() === selectedLocation.toLowerCase()) ||
        (v.district && v.district.toLowerCase() === selectedLocation.toLowerCase()) ||
        (v.location && v.location.toLowerCase().includes(selectedLocation.toLowerCase())) ||
        (v.pincode && v.pincode === selectedLocation)
      )
    : ventures;

  return (
    <section className="py-16 sm:py-24 bg-white border-b border-navy-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-800 bg-emerald-100/70 px-3.5 py-1 rounded-full border border-emerald-300">
              <Layers className="w-3.5 h-3.5" /> {t.navVentures}
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-navy-950 tracking-tight">
              {currentLang === 'te' 
                ? `B.N వెంచర్స్ అభివృద్ధి చేసిన ${ventures.length} ప్రతిష్టాత్మక లేఅవుట్‌లు` 
                : `B.N Ventures — ${ventures.length} Landmark Plotted Developments`}
            </h2>
            <p className="text-navy-600 text-sm sm:text-base leading-relaxed">
              {currentLang === 'te'
                ? `గత 10 సంవత్సరాల అనుభవంలో అభివృద్ధి చేసిన ${ventures.length} ప్రముఖ వెంచర్లు. మీ నగరంలో ఉన్న వెంచర్‌ను క్లిక్ చేసి నేరుగా 2D మ్యాప్ మరియు 3D వ్యూ చూడండి.`
                : `10 years of trusted real estate excellence with ${ventures.length} approved gated plotted developments. Explore prime DTCP & RERA approved layouts in Nirmal District (504106) and Telangana with 2D blueprint and 360° 3D conceptual view.`}
            </p>
          </div>
        </div>

        {/* Venture Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredVentures.map((venture) => {
            const counts = venture.counts || {
              total: venture.total_plots || 36,
              available: 21,
              booked: 8,
              pending: 4,
              blocked: 3
            };

            const availablePercent = Math.round((counts.available / (counts.total || 1)) * 100);

            return (
              <div
                key={venture.id}
                className="group bg-white rounded-3xl border-2 border-navy-100 hover:border-emerald-500 shadow-md hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col justify-between"
              >
                {/* Image & Overlay */}
                <div>
                  <div className="relative h-60 overflow-hidden">
                    <img
                      src={venture.hero_image}
                      alt={venture.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent"></div>

                    {/* Top Badges */}
                    <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
                      <span className="bg-white/95 backdrop-blur-md text-navy-900 text-xs font-black px-3 py-1 rounded-full shadow">
                        {currentLang === 'te' ? (venture.status_te || venture.status) : venture.status}
                      </span>
                      <span className="bg-emerald-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow">
                        DTCP & RERA
                      </span>
                    </div>

                    {/* Bottom overlay text */}
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <h3 className="font-display font-black text-2xl text-white group-hover:text-emerald-300 transition-colors">
                        {venture.name}
                      </h3>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          openInGoogleMaps(venture);
                        }}
                        className="text-slate-200 hover:text-amber-300 text-xs flex items-center gap-1.5 mt-1 font-semibold transition-colors group/loc text-left"
                        title="Click to open this venture in Google Maps"
                      >
                        <MapPin className="w-3.5 h-3.5 text-emerald-400 group-hover/loc:text-amber-300 shrink-0" />
                        {venture.district ? (
                          <span className="underline decoration-dotted underline-offset-2">
                            {currentLang === 'te' ? (venture.district_te || venture.district) : venture.district} District ({venture.pincode || '504106'}), Telangana
                          </span>
                        ) : (
                          <span className="underline decoration-dotted underline-offset-2">
                            {currentLang === 'te' ? (venture.location_te || venture.location) : venture.location}, {venture.city}
                          </span>
                        )}
                        <ExternalLink className="w-3 h-3 text-amber-300 opacity-80" />
                      </button>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 space-y-5">
                    
                    {/* Price and Plot Count */}
                    <div className="flex justify-between items-baseline border-b border-navy-100 pb-3">
                      <div>
                        <span className="text-xs text-navy-500 font-bold block">
                          {currentLang === 'te' ? 'ధర / చ.గజం' : 'Price / Sq.Yd'}
                        </span>
                        <strong className="font-display text-xl text-emerald-700">
                          ₹{venture.price_per_sqyd_min.toLocaleString('en-IN')}
                          <span className="text-xs font-normal text-navy-500"> / sq.yd</span>
                        </strong>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-navy-500 font-bold block">
                          {currentLang === 'te' ? 'మొత్తం ప్లాట్లు' : 'Total Plots'}
                        </span>
                        <strong className="font-display text-lg text-navy-950">{counts.total} Plots</strong>
                      </div>
                    </div>

                    {/* Availability Status Bar */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs font-bold">
                        <span className="text-emerald-700">
                          {counts.available} {currentLang === 'te' ? 'అందుబాటులో ఉన్నాయి (ఆకుపచ్చ)' : 'Available (Green)'}
                        </span>
                        <span className="text-red-700">
                          {counts.booked} {currentLang === 'te' ? 'బుక్ అయ్యాయి (ఎరుపు)' : 'Booked'}
                        </span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden flex border border-slate-200">
                        <div style={{ width: `${availablePercent}%` }} className="bg-emerald-500" />
                        <div style={{ width: `${(counts.pending / (counts.total || 1)) * 100}%` }} className="bg-amber-500" />
                        <div style={{ width: `${(counts.booked / (counts.total || 1)) * 100}%` }} className="bg-red-500" />
                        <div style={{ width: `${(counts.blocked / (counts.total || 1)) * 100}%` }} className="bg-slate-700" />
                      </div>
                    </div>

                    {/* Amenities Snippet */}
                    <div className="space-y-1.5 pt-1">
                      {(venture.amenities || []).slice(0, 3).map((amenity, i) => (
                        <div key={i} className="flex items-center gap-1.5 text-xs text-navy-800 font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span className="truncate">{amenity}</span>
                        </div>
                      ))}
                    </div>

                  </div>
                </div>

                {/* Card Action Buttons (Explore Layout, Google Maps Location & Brochure) */}
                <div className="p-6 pt-0 border-t border-navy-100 flex items-center gap-2 mt-4">
                  <button
                    onClick={() => onSelectVenture(venture)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm py-3 px-3 rounded-xl transition flex items-center justify-center gap-1.5 shadow-md"
                    title={currentLang === 'te' ? 'లేఅవుట్ ప్లాన్ చూడండి' : 'Explore Master Layout'}
                  >
                    <Compass className="w-4 h-4" />
                    <span>{t.exploreVenturesBtn}</span>
                  </button>

                  {/* Google Maps Explore Button (User Requirement: Linked to Google Maps) */}
                  <button
                    type="button"
                    onClick={() => openInGoogleMaps(venture)}
                    className="bg-amber-400 hover:bg-amber-500 text-navy-950 font-black text-xs sm:text-sm py-3 px-3 rounded-xl transition flex items-center justify-center gap-1.5 shadow-md border border-amber-500"
                    title={currentLang === 'te' ? 'గూగుల్ మ్యాప్స్‌లో ఈ వెంచర్ లొకేషన్ చూడండి' : 'Explore this Venture Location on Google Maps'}
                  >
                    <Navigation className="w-4 h-4 text-navy-950 fill-navy-950" />
                    <span className="hidden sm:inline">{currentLang === 'te' ? 'మ్యాప్స్' : 'Maps'}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onOpenBrochure(venture)}
                    className="p-3 rounded-xl border border-navy-200 hover:bg-slate-50 text-navy-700 transition"
                    title="Digital Brochure"
                  >
                    <FileText className="w-4 h-4 text-emerald-700" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {filteredVentures.length === 0 && (
          <div className="text-center py-12 space-y-3 bg-slate-50 rounded-3xl p-8 border border-navy-100">
            <h4 className="font-bold text-lg text-navy-950">
              {currentLang === 'te' 
                ? `${selectedLocation} లో ప్రస్తుతం వెంచర్లు లోడ్ కాలేదు` 
                : `No ventures currently found in ${selectedLocation}`}
            </h4>
            <p className="text-xs text-navy-600">
              {currentLang === 'te' ? 'అన్ని ప్రాంతాల వెంచర్లు చూడటానికి క్రింది బటన్ నొక్కండి' : 'Click below to view all 5 landmark ventures'}
            </p>
          </div>
        )}

      </div>
    </section>
  );
};
