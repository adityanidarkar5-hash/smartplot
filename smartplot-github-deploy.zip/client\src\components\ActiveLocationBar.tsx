import React from 'react';
import { MapPin, Navigation, ExternalLink, RefreshCw, Sparkles, Check } from 'lucide-react';
import { Language } from '../types';
import { openInGoogleMaps } from '../utils/googleMaps';

interface ActiveLocationBarProps {
  selectedLocation: string;
  onOpenLocationPicker: () => void;
  currentLang: Language;
  venturesCount?: number;
}

export const ActiveLocationBar: React.FC<ActiveLocationBarProps> = ({
  selectedLocation,
  onOpenLocationPicker,
  currentLang,
  venturesCount,
}) => {
  const isNirmal = !selectedLocation || selectedLocation.toLowerCase() === 'nirmal';
  const displayLocation = isNirmal
    ? (currentLang === 'te' ? 'నిర్మల్ జిల్లా (504106), తెలంగాణ' : 'Nirmal District (504106), Telangana')
    : `${selectedLocation}, Telangana`;

  const handleOpenGoogleMaps = () => {
    openInGoogleMaps(selectedLocation || 'Nirmal, 504106');
  };

  return (
    <div className="bg-gradient-to-r from-slate-950 via-emerald-950 to-slate-950 text-white border-b-2 border-emerald-500/40 py-2.5 px-4 sm:px-8 shadow-inner sticky top-20 z-30 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Left: Active Location ON Indicator */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Glowing Beacon */}
          <div className="flex items-center gap-1.5 bg-emerald-500/20 border border-emerald-400/50 px-2.5 py-1 rounded-full text-emerald-300 font-extrabold tracking-wide">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="uppercase text-[10px]">
              {currentLang === 'te' ? 'లొకేషన్ ఆన్' : 'LOCATION ON'}
            </span>
          </div>

          {/* Active Pinned Location Text */}
          <div className="flex items-center gap-1.5 text-slate-200">
            <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-bold text-white text-xs sm:text-sm">
              {displayLocation}
            </span>
            {venturesCount !== undefined && venturesCount > 0 && (
              <span className="bg-emerald-600/60 text-emerald-200 px-2 py-0.5 rounded-full text-[11px] font-semibold hidden md:inline-block">
                {venturesCount} {currentLang === 'te' ? 'వెంచర్లు క్రియాశీలకంగా ఉన్నాయి' : 'Ventures Active'}
              </span>
            )}
          </div>
        </div>

        {/* Right: Google Maps Explore & Change Buttons */}
        <div className="flex items-center gap-2 ml-auto">
          {/* Explore on Google Maps Button */}
          <button
            onClick={handleOpenGoogleMaps}
            className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-[11px] sm:text-xs px-3.5 py-1.5 rounded-xl transition-all shadow-md flex items-center gap-1.5 border border-emerald-400/40"
            title="Open Nirmal / Active Location in Google Maps"
          >
            <Navigation className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
            <span>{currentLang === 'te' ? 'గూగుల్ మ్యాప్స్‌లో చూడండి' : 'Explore on Google Maps'}</span>
            <ExternalLink className="w-3 h-3 opacity-80" />
          </button>

          {/* Change Location Button */}
          <button
            onClick={onOpenLocationPicker}
            className="bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition flex items-center gap-1 border border-slate-700"
          >
            <RefreshCw className="w-3 h-3 text-slate-400" />
            <span className="hidden sm:inline">
              {currentLang === 'te' ? 'మార్చండి' : 'Change'}
            </span>
          </button>
        </div>

      </div>
    </div>
  );
};
