# SmartPlot — Premium Real Estate Venture & Interactive Plot Booking Platform

Welcome to **SmartPlot**, a production-grade full-stack real estate venture management and interactive plot-booking website. Built for real estate developers, plotting venture promoters, and property investors with real-time 2D SVG master layouts, 3D conceptual visualizers, double-booking prevention, site-visit appointment scheduling, and a protected administrator dashboard.

---

## 🌟 Key Features Implemented

### 1. Website Design & Branding
- **Color Theme**: Clean white background, dark navy text (`#0f172a`), and elegant emerald green accents (`#059669`, `#10b981`).
- **Typography & Aesthetics**: Custom typography (Plus Jakarta Sans & Outfit), modern card elevations, smooth transitions, and high-resolution demonstration imagery.
- **Responsive Layout**: Fluid experience tailored for desktop, tablet, and mobile devices with collapsible navigation and touch-friendly controls.

### 2. Homepage & Discovery
- **Hero Banner**: Compelling headline, key trust badges (100% Clear Title, DTCP & RERA Approved, Spot Registration), and direct call-to-actions.
- **Global Search & Filter**: Search by venture name, location/city, and budget limits.
- **Key Metrics Ribbon**: Total master-developed acreage, plots delivered, and legal compliance indicators.
- **Featured Ventures**: Visual cards with live availability progress bars, pricing, and master layout inspection shortcuts.
- **Amenities Showcase**: 40ft blacktop roads, underground power cables, landscaped parks, and 24/7 RFID security arch.
- **Testimonials, FAQ Accordion & WhatsApp**: Interactive FAQ answers and pre-filled WhatsApp enquiry links.

### 3. Interactive Master Layout (2D SVG & 3D Three.js Visualizer)
- **Interactive 2D SVG Map**:
  - Full Master Layout with 40-ft Main Boulevard, 33-ft Cross Sector Roads, Grand Entrance Arch, Central Park & Gazebo, and Clubhouse Zone with Swimming Pool.
  - Numbered clickable plots with hover tooltips and selection halos.
  - **Color Coding System**:
    - 🟩 **GREEN**: Available
    - 🟨 **YELLOW / ORANGE**: Booking Pending (subtle pulse effect)
    - 🟥 **RED**: Booked or Sold
    - ⬛ **BLACK / DARK NAVY**: Blocked or Temporarily Unavailable
  - Navigation controls: Zoom In (+), Zoom Out (-), Reset View, Fullscreen toggle, and mouse/touch panning.
- **Conceptual 3D Venture View (Three.js)**:
  - Isometric 3D layout rendering with 3D ground grid, avenue trees, 3D plots color-coded by live status, shadows, and interactive 3D click selection.
  - One-click switcher between 2D Master SVG and 3D View.

### 4. Plot Details & Online Reservation (Anti-Duplicate Protection)
- **Slide-in Inspector Drawer**:
  - Plot number, block name, area in sq.yards + sq.ft conversion, dimensions ($L \times W$), facing direction with Vaastu verification, road width ($40\text{ ft} / 33\text{ ft}$), rate per sq.yd, and total consideration.
  - **Double-Booking Prevention**: Backend atomic status check ensures two customers cannot reserve the same plot simultaneously. If a plot is locked, the backend returns a `409 Conflict` error and prompts the customer to choose another plot.
  - Generates unique reference code (`BK-2026-XXXX`) and triggers celebratory confetti animation upon successful booking.

### 5. Site-Visit Appointment System
- Customers select preferred venture, optional plot number, date (past dates disabled), and time slot (10:00 AM, 11:30 AM, 2:00 PM, 4:00 PM, 5:30 PM).
- Validates 10-digit phone number and inputs on frontend and backend.
- Saves appointment to persistent database and displays saved confirmation with booking reference (`VISIT-2026-XXXX`).

### 6. Protected Administrator Dashboard
- **Secure Authentication**:
  - First-time setup wizard: Creates the initial master administrator with `bcrypt` password hashing.
  - Protected admin routes verified with signed JWT tokens (`Bearer`).
- **Dashboard Overview**:
  - Live count cards: Total plots, available, pending, booked, sold, and blocked plots.
  - Inventory absorption progress bar and appointment counters.
- **Plots Manager**:
  - Add new plot records to ventures.
  - Edit plot pricing, area, dimensions, facing, road width, corner flag, and status.
  - Bulk status update (change multiple plots to Available, Blocked, Pending, or Sold in 1 click).
  - Delete plots.
  - Manage owner info with explicit privacy consent controls.
- **Site Visits Manager**:
  - View all customer appointment requests, update status (Confirmed, Completed, Cancelled), and record follow-up notes.
- **Bookings Manager**:
  - Approve or reject online plot reservations. Approving automatically transitions the plot to **Booked/Sold**; rejecting reverts the plot to **Available**.

### 7. Advanced Value-Added Tools
- **Plot Comparison Matrix**: Compare up to 3 shortlisted plots side-by-side with estimated bank loan EMIs.
- **Plot Cost & EMI Calculator**: Interactive sliders for area, price/sq.yd, down payment (%), tenure (years), interest rate (%), and statutory stamp duty & registration estimates.
- **Digital Venture Brochure**: Printable / downloadable digital brochure with master specifications and legal credentials (`window.print()`).
- **Saved Favourites**: Wishlist stored locally in browser and synchronized.

---

## 🛠️ Technology Architecture

- **Frontend**: React 18, TypeScript, Tailwind CSS, Lucide React, Three.js, Canvas-Confetti, Vite.
- **Backend**: Node.js, Express 5, CORS, Dotenv.
- **Database**: SQLite with `sql.js` (WebAssembly) persisting directly to disk (`smartplot.db`). Standard SQL schema ready for PostgreSQL / Supabase migration if desired.
- **Security**: Password hashing with `bcryptjs`, session authentication with `jsonwebtoken`.

---

## 🚀 How to Run Locally

### Prerequisites
Node.js (v18+) is already configured on this machine in `C:\Users\Dell\nodejs`.

### Running the Full Application

Open PowerShell and navigate to the project directory:

```powershell
cd C:\Users\Dell\.gemini\antigravity\scratch\smartplot
```

To run both backend API and frontend website:
```powershell
npm start
```

Then open your browser at:
👉 **`http://localhost:5000`**

### Accessing the Protected Admin Portal
1. Click **Admin Portal** in the top navigation bar or navigate to:
   `http://localhost:5000` and click the Admin Portal link.
2. Sign in with your administrator credentials:
   - **Username**: `admin`
   - **Password**: `AdminPassword2026!`
   *(You can change this password or create additional administrators anytime from the admin portal).*

---

## 🧪 Automated Test Suite Verification

SmartPlot includes an automated verification test suite in `server/test-suite.js` testing 18 critical workflows:
- Venture & plot database seeding
- Exact color coding verification (Green, Yellow, Red, Black)
- Public API data privacy sanitization
- Site-visit appointment validation & persistent saving
- Anti-duplicate plot reservation with 409 Conflict rejection
- Secure admin authentication & JWT token generation
- Admin plot editing & metrics calculation
- Admin booking approval and plot status state-machine transitions

To re-run the tests anytime:
```powershell
cd C:\Users\Dell\.gemini\antigravity\scratch\smartplot\server
node test-suite.js
```

**Result: 18/18 Tests Passed (100% Success).**

---

## 🌐 How to Publish Online (Free & Low-Cost Deployment)

SmartPlot is self-contained and can be deployed in minutes on any modern cloud platform:

### Option A: Render.com (Recommended — Free Tier Available)
1. Push this folder to a GitHub repository.
2. Go to [Render.com](https://render.com) and create a **Web Service**.
3. Select your repository.
4. Set Build Command:
   ```bash
   npm run setup
   ```
5. Set Start Command:
   ```bash
   npm start
   ```
6. Add Environment Variable:
   - `JWT_SECRET`: (Any secure random 32-character string)
7. Click **Deploy**. Render will build the React frontend and launch the Express server on a free `.onrender.com` public URL!

### Option B: Railway.app / Fly.io
1. Connect your GitHub repository on Railway or Fly.io.
2. The project will automatically detect `npm start` and publish your live URL.
3. Attach a persistent volume to `/server` if you want SQLite file storage persisted across dyno restarts, or point database queries to a free managed PostgreSQL / Supabase database.

---

## ⚖️ Legal & Demonstration Data Notice
All venture names, survey boundaries, plot counts, and demonstrative pricing showcased on this platform are sample demonstration data for initial system evaluation until real legal land survey records and government RERA certificates are uploaded by the venture developer.
