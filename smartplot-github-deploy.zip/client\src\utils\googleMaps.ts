import { Venture } from '../types';

/**
 * Builds a highly accurate Google Maps Search / Navigation URL for a venture or location
 */
export function getVentureGoogleMapsUrl(ventureOrLocation: Venture | string): string {
  if (typeof ventureOrLocation === 'string') {
    const loc = ventureOrLocation.trim();
    if (!loc || loc.toLowerCase() === 'all' || loc.toLowerCase() === 'nirmal') {
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent('Nirmal, 504106, Telangana India')}`;
    }
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(loc + ', Telangana India')}`;
  }

  const venture = ventureOrLocation;
  const parts: string[] = [venture.name];
  if (venture.location) parts.push(venture.location);
  if (venture.district) parts.push(venture.district);
  if (venture.pincode) parts.push(venture.pincode);
  else parts.push('504106');
  parts.push(venture.state || 'Telangana');
  parts.push('India');

  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(parts.join(', '))}`;
}

/**
 * Opens Google Maps in a new tab for a venture or location
 */
export function openInGoogleMaps(ventureOrLocation: Venture | string): void {
  const url = getVentureGoogleMapsUrl(ventureOrLocation);
  window.open(url, '_blank', 'noopener,noreferrer');
}

/**
 * Generates an embedded Google Maps iframe URL for a venture
 */
export function getGoogleMapsEmbedUrl(ventureOrLocation: Venture | string): string {
  if (typeof ventureOrLocation === 'string') {
    return `https://maps.google.com/maps?q=${encodeURIComponent(ventureOrLocation + ' 504106 Telangana India')}&t=m&z=14&ie=UTF8&iwloc=&output=embed`;
  }
  const venture = ventureOrLocation;
  if (venture.map_embed_url && venture.map_embed_url.includes('google.com/maps/embed')) {
    return venture.map_embed_url;
  }
  const query = `${venture.name} ${venture.location || ''} ${venture.district || 'Nirmal'} ${venture.pincode || '504106'} Telangana India`;
  return `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=m&z=15&ie=UTF8&iwloc=&output=embed`;
}
