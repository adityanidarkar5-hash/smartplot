import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { Plot, PlotStatus, Language } from '../types';
import { 
  Rotate3d, 
  ZoomIn, 
  ZoomOut, 
  Play, 
  Pause, 
  RotateCcw, 
  UserCheck, 
  Sun, 
  Sunset, 
  Moon, 
  Eye, 
  Compass, 
  Sparkles,
  Navigation,
  ExternalLink
} from 'lucide-react';
import { translations } from '../i18n';
import { openInGoogleMaps } from '../utils/googleMaps';

interface ThreeDPlotViewProps {
  plots: Plot[];
  selectedPlot: Plot | null;
  onSelectPlot: (plot: Plot) => void;
  ventureName?: string;
  currentLang?: Language;
  lang?: Language;
}

type LightingMode = 'day' | 'sunset' | 'night';
type CameraView = 'overview' | 'entrance' | 'boulevard' | 'park';

export const ThreeDPlotView: React.FC<ThreeDPlotViewProps> = ({
  plots,
  selectedPlot,
  onSelectPlot,
  ventureName = 'B.N Golden County',
  currentLang,
  lang,
}) => {
  const activeLang: Language = currentLang || lang || 'en';
  const t = translations[activeLang];

  const mountRef = useRef<HTMLDivElement>(null);
  const [hoveredPlotInfo, setHoveredPlotInfo] = useState<Plot | null>(null);
  const [isAutoRotating, setIsAutoRotating] = useState(true);
  const [lightingMode, setLightingMode] = useState<LightingMode>('day');
  const [activeCameraView, setActiveCameraView] = useState<CameraView>('overview');

  // Mutable refs to prevent scene re-creations (Fixes lagging/freezing)
  const isAutoRotatingRef = useRef(isAutoRotating);
  isAutoRotatingRef.current = isAutoRotating;

  const plotsRef = useRef(plots);
  plotsRef.current = plots;

  const selectedPlotRef = useRef(selectedPlot);
  selectedPlotRef.current = selectedPlot;

  const onSelectPlotRef = useRef(onSelectPlot);
  onSelectPlotRef.current = onSelectPlot;

  const plotMeshesRef = useRef<{ mesh: THREE.Mesh; plot: Plot; baseColor: number }[]>([]);

  // Action callback refs
  const zoomFnRef = useRef<{ zoomIn: () => void; zoomOut: () => void; reset: () => void } | null>(null);
  const setCameraViewRef = useRef<((view: CameraView) => void) | null>(null);
  const setLightingRef = useRef<((mode: LightingMode) => void) | null>(null);
  const orbitToDirRef = useRef<((dir: 'north' | 'south' | 'east' | 'west') => void) | null>(null);
  const compassNeedleRef = useRef<HTMLDivElement>(null);

  // -------------------------------------------------------------
  // PRIMARY THREE.JS INITIALIZATION (Runs ONCE on mount)
  // -------------------------------------------------------------
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight || 620;

    // 1. Scene & Atmosphere
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a1120);
    scene.fog = new THREE.FogExp2(0x0a1120, 0.0009);

    // 2. Camera Setup (Spherical Orbit Coordinates)
    let cameraDistance = 720;
    let targetDistance = 720;
    let cameraAngle = 0.45;
    let targetAngle = 0.45;
    let cameraPitch = 0.75;
    let targetPitch = 0.75;

    let targetX = 0;
    let targetY = 0;
    let targetZ = 0;
    let destX = 0;
    let destY = 0;
    let destZ = 0;

    const camera = new THREE.PerspectiveCamera(45, width / height, 2, 3500);

    const updateCameraPos = () => {
      camera.position.x = targetX + Math.sin(cameraAngle) * Math.cos(cameraPitch) * cameraDistance;
      camera.position.y = targetY + Math.sin(cameraPitch) * cameraDistance;
      camera.position.z = targetZ + Math.cos(cameraAngle) * Math.cos(cameraPitch) * cameraDistance;
      camera.lookAt(targetX, targetY, targetZ);
    };
    updateCameraPos();

    // 3. High Performance Renderer (Optimized pixel ratio to eliminate stutter)
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: false,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5)); // Capped for 60fps on mobile
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap; // Fast clean shadows
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.appendChild(renderer.domElement);

    // 4. Lighting System
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x065f46, 0.35);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffbeb, 1.4);
    sunLight.position.set(380, 550, 280);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024; // Optimized for silky framerate
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 50;
    sunLight.shadow.camera.far = 1600;
    sunLight.shadow.camera.left = -500;
    sunLight.shadow.camera.right = 500;
    sunLight.shadow.camera.top = 500;
    sunLight.shadow.camera.bottom = -500;
    sunLight.shadow.bias = -0.0006;
    scene.add(sunLight);

    // Lighting modes
    const applyLighting = (mode: LightingMode) => {
      if (mode === 'day') {
        scene.background = new THREE.Color(0x0a1120);
        scene.fog = new THREE.FogExp2(0x0a1120, 0.0009);
        ambientLight.color.setHex(0xffffff);
        ambientLight.intensity = 0.9;
        sunLight.color.setHex(0xfffbeb);
        sunLight.intensity = 1.4;
        sunLight.position.set(380, 550, 280);
      } else if (mode === 'sunset') {
        scene.background = new THREE.Color(0x1a0f1e);
        scene.fog = new THREE.FogExp2(0x1a0f1e, 0.0011);
        ambientLight.color.setHex(0xfbcfe8);
        ambientLight.intensity = 0.65;
        sunLight.color.setHex(0xf97316);
        sunLight.intensity = 1.8;
        sunLight.position.set(600, 200, 350);
      } else if (mode === 'night') {
        scene.background = new THREE.Color(0x030712);
        scene.fog = new THREE.FogExp2(0x030712, 0.0013);
        ambientLight.color.setHex(0x1e293b);
        ambientLight.intensity = 0.35;
        sunLight.color.setHex(0x38bdf8);
        sunLight.intensity = 0.35;
        sunLight.position.set(-200, 500, -200);
      }
    };
    setLightingRef.current = applyLighting;

    // 5. Master Ground & Perimeter
    const groundGeo = new THREE.PlaneGeometry(1200, 900);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.95 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // 6. Roads & Painted Markings
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 });
    const curbMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.7 });

    // 40ft Main Boulevard
    const centralRoadGeo = new THREE.BoxGeometry(940, 2, 58);
    const centralRoad = new THREE.Mesh(centralRoadGeo, roadMat);
    centralRoad.position.set(0, 1, 0);
    centralRoad.receiveShadow = true;
    scene.add(centralRoad);

    // White dashed center line
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
    for (let x = -430; x <= 430; x += 36) {
      const stripeGeo = new THREE.PlaneGeometry(16, 2.5);
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(x, 2.1, 0);
      scene.add(stripe);
    }

    // Curbs along main road
    const curbNorthGeo = new THREE.BoxGeometry(940, 3, 3);
    const curbNorth = new THREE.Mesh(curbNorthGeo, curbMat);
    curbNorth.position.set(0, 1.5, -30.5);
    scene.add(curbNorth);

    const curbSouthGeo = new THREE.BoxGeometry(940, 3, 3);
    const curbSouth = new THREE.Mesh(curbSouthGeo, curbMat);
    curbSouth.position.set(0, 1.5, 30.5);
    scene.add(curbSouth);

    // 33ft North Sector Road
    const northRoadGeo = new THREE.BoxGeometry(940, 2, 44);
    const northRoad = new THREE.Mesh(northRoadGeo, roadMat);
    northRoad.position.set(0, 1, -195);
    northRoad.receiveShadow = true;
    scene.add(northRoad);

    // 33ft South Sector Road
    const southRoadGeo = new THREE.BoxGeometry(680, 2, 44);
    const southRoad = new THREE.Mesh(southRoadGeo, roadMat);
    southRoad.position.set(-130, 1, 195);
    southRoad.receiveShadow = true;
    scene.add(southRoad);

    // Entrance Boulevard
    const entranceRoadGeo = new THREE.BoxGeometry(64, 2, 380);
    const entranceRoad = new THREE.Mesh(entranceRoadGeo, roadMat);
    entranceRoad.position.set(290, 1, 95);
    entranceRoad.receiveShadow = true;
    scene.add(entranceRoad);

    // 7. Park, Swimming Pool & Clubhouse
    const parkGeo = new THREE.BoxGeometry(195, 4, 225);
    const parkMat = new THREE.MeshStandardMaterial({ color: 0x059669, roughness: 0.65 });
    const park = new THREE.Mesh(parkGeo, parkMat);
    park.position.set(310, 2, -155);
    park.receiveShadow = true;
    scene.add(park);

    // Swimming Pool with Aqua Depth
    const poolGeo = new THREE.BoxGeometry(125, 4, 60);
    const poolMat = new THREE.MeshStandardMaterial({ 
      color: 0x0284c7, 
      roughness: 0.15, 
      metalness: 0.4,
      transparent: true,
      opacity: 0.9 
    });
    const pool = new THREE.Mesh(poolGeo, poolMat);
    pool.position.set(310, 3, 90);
    scene.add(pool);

    // 2-Story Clubhouse Pavilion
    const clubBaseGeo = new THREE.BoxGeometry(135, 22, 70);
    const clubBaseMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 });
    const clubBase = new THREE.Mesh(clubBaseGeo, clubBaseMat);
    clubBase.position.set(310, 13, 175);
    clubBase.castShadow = true;
    scene.add(clubBase);

    const clubGlassGeo = new THREE.BoxGeometry(132, 10, 68);
    const clubGlassMat = new THREE.MeshStandardMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.75 });
    const clubGlass = new THREE.Mesh(clubGlassGeo, clubGlassMat);
    clubGlass.position.set(310, 17, 175);
    scene.add(clubGlass);

    // Grand Entrance Arch
    const archGroup = new THREE.Group();
    archGroup.position.set(290, 0, 290);
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x064e3b });
    const leftPillar = new THREE.Mesh(new THREE.BoxGeometry(12, 36, 12), pillarMat);
    leftPillar.position.set(-35, 18, 0);
    leftPillar.castShadow = true;
    archGroup.add(leftPillar);

    const rightPillar = new THREE.Mesh(new THREE.BoxGeometry(12, 36, 12), pillarMat);
    rightPillar.position.set(35, 18, 0);
    rightPillar.castShadow = true;
    archGroup.add(rightPillar);

    const archBeam = new THREE.Mesh(new THREE.BoxGeometry(86, 10, 14), new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.7 }));
    archBeam.position.set(0, 36, 0);
    archBeam.castShadow = true;
    archGroup.add(archBeam);
    scene.add(archGroup);

    // -------------------------------------------------------------
    // CARDINAL DIRECTION BOUNDARY SIGNS & GROUND VASTU COMPASS
    // -------------------------------------------------------------
    const createDirectionSignTexture = (
      engTitle: string, 
      telTitle: string, 
      subText: string, 
      arrow: string, 
      bgColor: string, 
      borderColor: string, 
      accentColor: string
    ) => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 180;
      const ctx = canvas.getContext('2d')!;

      // Background
      ctx.fillStyle = bgColor;
      ctx.beginPath();
      ctx.roundRect(6, 6, 500, 168, 20);
      ctx.fill();

      // Bold Border
      ctx.strokeStyle = borderColor;
      ctx.lineWidth = 8;
      ctx.stroke();

      // Inner subtle line
      ctx.strokeStyle = accentColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(14, 14, 484, 152, 14);
      ctx.stroke();

      // Arrow
      ctx.fillStyle = accentColor;
      ctx.font = 'bold 48px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(arrow, 26, 85);

      // English Title
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 36px "Segoe UI", Roboto, sans-serif';
      ctx.fillText(engTitle, 80, 64);

      // Telugu Title
      ctx.fillStyle = accentColor;
      ctx.font = 'bold 28px "Segoe UI", "Gautami", sans-serif';
      ctx.fillText(telTitle, 80, 108);

      // Subtext
      ctx.fillStyle = '#cbd5e1';
      ctx.font = 'bold 19px "Segoe UI", sans-serif';
      ctx.fillText(subText, 80, 145);

      const texture = new THREE.CanvasTexture(canvas);
      texture.minFilter = THREE.LinearFilter;
      return texture;
    };

    const addDirectionSign = (
      x: number, 
      z: number, 
      rotY: number, 
      engTitle: string, 
      telTitle: string, 
      subText: string, 
      arrow: string, 
      bg: string, 
      border: string, 
      accent: string
    ) => {
      const group = new THREE.Group();
      group.position.set(x, 0, z);
      group.rotation.y = rotY;

      const postMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.3 });
      const leftPost = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 48, 8), postMat);
      leftPost.position.set(-42, 24, 0);
      leftPost.castShadow = true;
      group.add(leftPost);

      const rightPost = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 48, 8), postMat);
      rightPost.position.set(42, 24, 0);
      rightPost.castShadow = true;
      group.add(rightPost);

      const texture = createDirectionSignTexture(engTitle, telTitle, subText, arrow, bg, border, accent);
      const boardGeo = new THREE.BoxGeometry(96, 32, 2.5);
      const boardMat = new THREE.MeshStandardMaterial({ map: texture, roughness: 0.4, metalness: 0.1 });
      const board = new THREE.Mesh(boardGeo, boardMat);
      board.position.set(0, 32, 0);
      board.castShadow = true;
      group.add(board);

      scene.add(group);
    };

    // NORTH Sign (at -Z boundary, facing South +Z)
    addDirectionSign(0, -250, 0, 'NORTH', 'ఉత్తర దిశ', '33 Ft Sector Road', '▲', '#7f1d1d', '#ef4444', '#fca5a5');

    // SOUTH Sign (at +Z boundary, facing North -Z)
    addDirectionSign(-130, 260, Math.PI, 'SOUTH', 'దక్షిణ దిశ', '33 Ft Road & Main Entrance', '▼', '#0f172a', '#3b82f6', '#93c5fd');

    // EAST Sign (at +X boundary, facing West -X)
    addDirectionSign(450, 0, -Math.PI / 2, 'EAST (VASTU)', 'తూర్పు దిశ • వాస్తు శ్రేష్ఠం', 'Central Park & 60 Ft Boulevard', '▶', '#78350f', '#f59e0b', '#fef08a');

    // WEST Sign (at -X boundary, facing East +X)
    addDirectionSign(-475, 0, Math.PI / 2, 'WEST', 'పడమర దిశ', 'Inner Residential Plots Boundary', '◀', '#1e293b', '#64748b', '#cbd5e1');

    // Large 3D Ground Compass Rose Decal
    const createCompassDecal = () => {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 512;
      const ctx = c.getContext('2d')!;
      const cx = 256;
      const cy = 256;

      ctx.fillStyle = '#090d16';
      ctx.beginPath();
      ctx.arc(cx, cy, 240, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.arc(cx, cy, 230, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 8]);
      ctx.beginPath();
      ctx.arc(cx, cy, 190, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // North Needle (Red)
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(cx, cy - 180);
      ctx.lineTo(cx + 28, cy - 30);
      ctx.lineTo(cx, cy - 40);
      ctx.fill();
      ctx.fillStyle = '#b91c1c';
      ctx.beginPath();
      ctx.moveTo(cx, cy - 180);
      ctx.lineTo(cx - 28, cy - 30);
      ctx.lineTo(cx, cy - 40);
      ctx.fill();

      // South Needle (White)
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.moveTo(cx, cy + 180);
      ctx.lineTo(cx + 28, cy + 30);
      ctx.lineTo(cx, cy + 40);
      ctx.fill();
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.moveTo(cx, cy + 180);
      ctx.lineTo(cx - 28, cy + 30);
      ctx.lineTo(cx, cy + 40);
      ctx.fill();

      // East Needle (Gold)
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(cx + 180, cy);
      ctx.lineTo(cx + 30, cy + 28);
      ctx.lineTo(cx + 40, cy);
      ctx.fill();
      ctx.fillStyle = '#d97706';
      ctx.beginPath();
      ctx.moveTo(cx + 180, cy);
      ctx.lineTo(cx + 30, cy - 28);
      ctx.lineTo(cx + 40, cy);
      ctx.fill();

      // West Needle (Slate)
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.moveTo(cx - 180, cy);
      ctx.lineTo(cx - 30, cy + 28);
      ctx.lineTo(cx - 40, cy);
      ctx.fill();
      ctx.fillStyle = '#64748b';
      ctx.beginPath();
      ctx.moveTo(cx - 180, cy);
      ctx.lineTo(cx - 30, cy - 28);
      ctx.lineTo(cx - 40, cy);
      ctx.fill();

      // Center Hub
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(cx, cy, 45, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 4;
      ctx.stroke();

      ctx.fillStyle = '#f59e0b';
      ctx.font = '900 18px "Segoe UI", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('VASTU', cx, cy - 8);
      ctx.font = 'bold 16px "Segoe UI", "Gautami", sans-serif';
      ctx.fillText('వాస్తు', cx, cy + 12);

      // Labels on outer edges
      ctx.fillStyle = '#ef4444';
      ctx.font = '900 24px "Segoe UI", sans-serif';
      ctx.fillText('NORTH / ఉత్తరం', cx, 40);

      ctx.fillStyle = '#f8fafc';
      ctx.fillText('SOUTH / దక్షిణం', cx, 495);

      ctx.fillStyle = '#f59e0b';
      ctx.save();
      ctx.translate(470, cy);
      ctx.rotate(Math.PI / 2);
      ctx.fillText('EAST / తూర్పు', 0, 0);
      ctx.restore();

      ctx.fillStyle = '#cbd5e1';
      ctx.save();
      ctx.translate(45, cy);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText('WEST / పడమర', 0, 0);
      ctx.restore();

      const tex = new THREE.CanvasTexture(c);
      tex.minFilter = THREE.LinearFilter;
      return tex;
    };

    const groundCompassGeo = new THREE.PlaneGeometry(160, 160);
    const groundCompassMat = new THREE.MeshBasicMaterial({ 
      map: createCompassDecal(), 
      transparent: true, 
      opacity: 0.95 
    });
    const groundCompass = new THREE.Mesh(groundCompassGeo, groundCompassMat);
    groundCompass.rotation.x = -Math.PI / 2;
    groundCompass.position.set(-390, 1.2, 240);
    scene.add(groundCompass);

    // 8. 3D Trees
    const addTree = (x: number, z: number, scale = 1, isCypress = false) => {
      const tree = new THREE.Group();
      tree.position.set(x, 0, z);

      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(1.5 * scale, 2.5 * scale, 12 * scale, 6),
        new THREE.MeshStandardMaterial({ color: 0x5c3817 })
      );
      trunk.position.y = 6 * scale;
      trunk.castShadow = true;
      tree.add(trunk);

      const foliageMat = new THREE.MeshStandardMaterial({ color: isCypress ? 0x064e3b : 0x10b981, roughness: 0.6 });
      const foliage = isCypress
        ? new THREE.Mesh(new THREE.ConeGeometry(5 * scale, 22 * scale, 7), foliageMat)
        : new THREE.Mesh(new THREE.DodecahedronGeometry(8 * scale), foliageMat);
      foliage.position.y = (12 + (isCypress ? 10 : 7)) * scale;
      foliage.castShadow = true;
      tree.add(foliage);
      scene.add(tree);
    };

    // Avenue trees along 40ft road
    for (let x = -410; x <= 210; x += 75) {
      addTree(x, -38, 0.8, false);
      addTree(x, 38, 0.8, false);
    }
    addTree(250, -120, 1.1, false);
    addTree(370, -120, 1.1, true);
    addTree(260, -210, 1.2, false);
    addTree(360, -210, 1.3, true);

    // 9. Modern 3D Villa Creator
    const create3DVilla = (w: number, d: number) => {
      const v = new THREE.Group();
      // Ground floor
      const gH = 12;
      const g = new THREE.Mesh(new THREE.BoxGeometry(w * 0.72, gH, d * 0.68), new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 }));
      g.position.y = gH / 2;
      g.castShadow = true;
      v.add(g);
      // Upper floor
      const uH = 10;
      const u = new THREE.Mesh(new THREE.BoxGeometry(w * 0.64, uH, d * 0.60), new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4 }));
      u.position.set(0, gH + uH / 2, d * 0.04);
      u.castShadow = true;
      v.add(u);
      // Glass balcony
      const b = new THREE.Mesh(new THREE.BoxGeometry(w * 0.52, 3, 2), new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.8 }));
      b.position.set(0, gH + 2, d * 0.35);
      v.add(b);
      // Roof pergola
      const r = new THREE.Mesh(new THREE.BoxGeometry(w * 0.74, 1.6, d * 0.70), new THREE.MeshStandardMaterial({ color: 0x1e293b }));
      r.position.y = gH + uH + 1;
      v.add(r);
      return v;
    };

    // 10. Interactive 3D Plot Meshes
    plotMeshesRef.current = [];
    const plotMeshes = plotMeshesRef.current;

    plotsRef.current.forEach((p) => {
      const x3d = (p.pos_x - 380) * 0.95;
      const z3d = (p.pos_y - 280) * 0.95;
      const plotW = (p.width || 65) * 0.88;
      const plotD = (p.height || 95) * 0.88;
      const isSelected = selectedPlotRef.current?.id === p.id;
      const isBookedOrSold = p.status === 'booked' || p.status === 'sold';
      const plotH = isSelected ? 12 : 5;

      let plotColor = 0x10b981; // Green
      if (p.status === 'pending') plotColor = 0xf59e0b;
      else if (isBookedOrSold) plotColor = 0xdc2626;
      else if (p.status === 'blocked') plotColor = 0x111827;

      const plotMat = new THREE.MeshStandardMaterial({
        color: isSelected ? 0x3b82f6 : plotColor,
        roughness: 0.4,
        metalness: isSelected ? 0.3 : 0.1,
      });

      const mesh = new THREE.Mesh(new THREE.BoxGeometry(plotW, plotH, plotD), plotMat);
      mesh.position.set(x3d, plotH / 2 + 1, z3d);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData = { plot: p };
      scene.add(mesh);
      plotMeshes.push({ mesh, plot: p, baseColor: plotColor });

      // Concrete curb perimeter
      const curbEdge = new THREE.Mesh(
        new THREE.BoxGeometry(plotW + 2, 2.5, plotD + 2),
        new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.8 })
      );
      curbEdge.position.set(x3d, 1.5, z3d);
      scene.add(curbEdge);

      // Render 3D Villa on booked/sold plots
      if (isBookedOrSold) {
        const villa = create3DVilla(plotW, plotD);
        villa.position.set(x3d, plotH + 1, z3d);
        scene.add(villa);
      }
    });

    // 11. Camera View Presets
    const setCameraView = (view: CameraView) => {
      setActiveCameraView(view);
      setIsAutoRotating(false);

      if (view === 'overview') {
        targetDistance = 720;
        targetAngle = 0.45;
        targetPitch = 0.75;
        destX = 0; destY = 0; destZ = 0;
      } else if (view === 'entrance') {
        targetDistance = 410;
        targetAngle = 0.05;
        targetPitch = 0.35;
        destX = 290; destY = 20; destZ = 200;
      } else if (view === 'boulevard') {
        targetDistance = 380;
        targetAngle = Math.PI / 2;
        targetPitch = 0.28;
        destX = -80; destY = 15; destZ = 0;
      } else if (view === 'park') {
        targetDistance = 390;
        targetAngle = -0.6;
        targetPitch = 0.55;
        destX = 310; destY = 20; destZ = -100;
      }
    };
    setCameraViewRef.current = setCameraView;

    // Zoom Functions
    zoomFnRef.current = {
      zoomIn: () => {
        targetDistance = Math.max(targetDistance - 90, 260);
      },
      zoomOut: () => {
        targetDistance = Math.min(targetDistance + 90, 1300);
      },
      reset: () => {
        setCameraView('overview');
      }
    };

    // Cardinal Direction Orbit Callback
    const orbitToDirection = (dir: 'north' | 'south' | 'east' | 'west') => {
      setIsAutoRotating(false);
      targetPitch = 0.55;
      targetDistance = 640;
      destX = 0; destY = 0; destZ = 0;
      if (dir === 'north') {
        targetAngle = 0; // Look North (towards -Z)
      } else if (dir === 'south') {
        targetAngle = Math.PI; // Look South (towards +Z)
      } else if (dir === 'east') {
        targetAngle = -Math.PI / 2; // Look East (towards +X)
      } else if (dir === 'west') {
        targetAngle = Math.PI / 2; // Look West (towards -X)
      }
    };
    orbitToDirRef.current = orbitToDirection;

    // 12. Ultra-Smooth Touch & Mouse Controls with Damping
    let isDragging = false;
    let prevMousePos = { x: 0, y: 0 };
    let initialPinch = 0;

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let frameCount = 0;

    const onPointerDown = (e: MouseEvent) => {
      isDragging = true;
      prevMousePos = { x: e.clientX, y: e.clientY };
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      targetDistance = Math.max(260, Math.min(1300, targetDistance + e.deltaY * 0.45));
    };

    const onPointerMove = (e: MouseEvent) => {
      if (isDragging) {
        const deltaX = e.clientX - prevMousePos.x;
        const deltaY = e.clientY - prevMousePos.y;
        targetAngle -= deltaX * 0.005;
        targetPitch = Math.max(0.12, Math.min(Math.PI / 2.1, targetPitch + deltaY * 0.005));
        prevMousePos = { x: e.clientX, y: e.clientY };
      } else {
        // Throttle raycaster to every 3rd frame for silky 60fps
        frameCount++;
        if (frameCount % 3 === 0) {
          const rect = renderer.domElement.getBoundingClientRect();
          mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
          mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
          raycaster.setFromCamera(mouse, camera);
          const intersects = raycaster.intersectObjects(plotMeshesRef.current.map(pm => pm.mesh));
          if (intersects.length > 0) {
            setHoveredPlotInfo(intersects[0].object.userData.plot as Plot);
            renderer.domElement.style.cursor = 'pointer';
          } else {
            setHoveredPlotInfo(null);
            renderer.domElement.style.cursor = 'grab';
          }
        }
      }
    };

    const onPointerUp = (e: MouseEvent) => {
      if (Math.abs(e.clientX - prevMousePos.x) < 5 && Math.abs(e.clientY - prevMousePos.y) < 5) {
        const rect = renderer.domElement.getBoundingClientRect();
        mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObjects(plotMeshesRef.current.map(pm => pm.mesh));
        if (intersects.length > 0) {
          const clickedPlot = intersects[0].object.userData.plot as Plot;
          onSelectPlotRef.current(clickedPlot);
        }
      }
      isDragging = false;
    };

    // Mobile Touch Listeners with passive: false to prevent page-scroll jank
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        initialPinch = Math.hypot(dx, dy);
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      // Critical fix: Prevent page scroll while interacting with 3D model
      if (e.cancelable) e.preventDefault();

      if (e.touches.length === 1 && isDragging) {
        const deltaX = e.touches[0].clientX - prevMousePos.x;
        const deltaY = e.touches[0].clientY - prevMousePos.y;
        targetAngle -= deltaX * 0.006;
        targetPitch = Math.max(0.12, Math.min(Math.PI / 2.1, targetPitch + deltaY * 0.006));
        prevMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const dist = Math.hypot(dx, dy);
        const delta = initialPinch - dist;
        targetDistance = Math.max(260, Math.min(1300, targetDistance + delta * 1.5));
        initialPinch = dist;
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (e.touches.length === 0) {
        isDragging = false;
      }
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', onPointerDown);
    domEl.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);

    domEl.addEventListener('touchstart', onTouchStart, { passive: true });
    domEl.addEventListener('touchmove', onTouchMove, { passive: false });
    domEl.addEventListener('touchend', onTouchEnd);

    // 13. High FPS Animation Render Loop with Inertia Damping
    let reqId: number;
    const animate = () => {
      reqId = requestAnimationFrame(animate);

      // Continuous 360 Auto-Rotation
      if (isAutoRotatingRef.current && !isDragging) {
        targetAngle += 0.0016;
      }

      // Smooth camera interpolation (Inertia damping for buttery feel)
      cameraAngle += (targetAngle - cameraAngle) * 0.09;
      cameraPitch += (targetPitch - cameraPitch) * 0.09;
      cameraDistance += (targetDistance - cameraDistance) * 0.09;

      targetX += (destX - targetX) * 0.08;
      targetY += (destY - targetY) * 0.08;
      targetZ += (destZ - targetZ) * 0.08;

      updateCameraPos();

      // Real-time Dynamic Compass Synchronization (60 FPS)
      if (compassNeedleRef.current) {
        const compassDeg = (-cameraAngle * 180 / Math.PI) % 360;
        compassNeedleRef.current.style.transform = `rotate(${compassDeg}deg)`;
      }

      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight || 620;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(reqId);
      domEl.removeEventListener('mousedown', onPointerDown);
      domEl.removeEventListener('wheel', onWheel);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      domEl.removeEventListener('touchstart', onTouchStart);
      domEl.removeEventListener('touchmove', onTouchMove);
      domEl.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (domEl.parentNode) domEl.parentNode.removeChild(domEl);
    };
  }, []); // Run ONLY once on mount! (Fixes all lag and sticking)

  // -------------------------------------------------------------
  // SELECTION UPDATE (Smoothly highlights without reloading scene)
  // -------------------------------------------------------------
  useEffect(() => {
    plotMeshesRef.current.forEach(({ mesh, plot, baseColor }) => {
      const isSelected = selectedPlot?.id === plot.id;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (isSelected) {
        mat.color.setHex(0x3b82f6);
        mat.metalness = 0.4;
        mesh.scale.set(1.05, 1.4, 1.05);
      } else {
        mat.color.setHex(baseColor);
        mat.metalness = 0.1;
        mesh.scale.set(1, 1, 1);
      }
    });
  }, [selectedPlot]);

  const handleLightingChange = (mode: LightingMode) => {
    setLightingMode(mode);
    setLightingRef.current?.(mode);
  };

  const handleCameraChange = (view: CameraView) => {
    setCameraViewRef.current?.(view);
  };

  return (
    <div 
      className="relative w-full h-[580px] sm:h-[680px] bg-slate-950 rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl select-none"
      style={{ touchAction: 'none' }} // Prevents browser scroll fighting 3D rotation
    >
      
      {/* 3D WebGL Canvas */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Left Title Banner */}
      <div className="absolute top-4 left-4 z-20 flex flex-col gap-2 max-w-[280px] sm:max-w-md pointer-events-none">
        <div className="bg-slate-900/90 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-slate-700/80 text-white flex items-center gap-3 shadow-xl pointer-events-auto">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shrink-0">
            <Rotate3d className="w-5 h-5 animate-pulse text-amber-300" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-extrabold tracking-wide truncate flex items-center gap-2">
              <span>{ventureName} — {t.map3DTab}</span>
              <span className="text-[9px] bg-red-600 text-white font-black px-1.5 py-0.5 rounded uppercase">
                3D Vastu
              </span>
            </h4>
            <p className="text-[11px] text-slate-300">
              {activeLang === 'te' 
                ? '360° తిప్పడానికి లాగండి • దిశలు (తూర్పు, పడమర, ఉత్తరం, దక్షిణం)' 
                : 'Drag to rotate 360° • East, West, North, South Cardinal Indicators'}
            </p>
          </div>
        </div>

        {/* Cardinal Directions HUD Strip */}
        <div className="bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-slate-700/80 text-[11px] text-white flex flex-wrap items-center gap-1.5 shadow-xl pointer-events-auto">
          <span className="text-amber-400 font-extrabold flex items-center gap-1 uppercase tracking-wider text-[10px] mr-1">
            <Compass className="w-3.5 h-3.5" />
            {activeLang === 'te' ? 'దిశల గైడ్' : 'Directions'}:
          </span>
          <button
            onClick={() => orbitToDirRef.current?.('north')}
            className="px-2 py-0.5 rounded-lg bg-red-950/80 hover:bg-red-900 border border-red-700/80 text-red-200 font-bold flex items-center gap-1 transition cursor-pointer text-xs"
            title="Orbit view to face North (33ft Road)"
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            ⬆ N (ఉత్తరం)
          </button>
          <button
            onClick={() => orbitToDirRef.current?.('east')}
            className="px-2 py-0.5 rounded-lg bg-amber-950/80 hover:bg-amber-900 border border-amber-600/80 text-amber-200 font-bold flex items-center gap-1 transition cursor-pointer text-xs"
            title="Orbit view to face East (Central Park & Gate - Vastu Auspicious)"
          >
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            ➡ E (తూర్పు - వాస్తు)
          </button>
          <button
            onClick={() => orbitToDirRef.current?.('south')}
            className="px-2 py-0.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 border border-slate-600/80 text-slate-200 font-bold flex items-center gap-1 transition cursor-pointer text-xs"
            title="Orbit view to face South (Main Entrance)"
          >
            ⬇ S (దక్షిణం)
          </button>
          <button
            onClick={() => orbitToDirRef.current?.('west')}
            className="px-2 py-0.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 border border-slate-600/80 text-slate-200 font-bold flex items-center gap-1 transition cursor-pointer text-xs"
            title="Orbit view to face West (Residential Plots)"
          >
            ⬅ W (పడమర)
          </button>
        </div>
      </div>

      {/* Top Right: Zoom & 360 Rotation Controls */}
      <div className="absolute top-4 right-4 z-20 flex flex-wrap items-center justify-end gap-1.5 sm:gap-2">
        <div className="bg-slate-900/90 backdrop-blur-md p-1 rounded-2xl border border-slate-700/80 shadow-xl flex items-center gap-1">
          <button
            onClick={() => zoomFnRef.current?.zoomIn()}
            className="p-2 sm:p-2.5 bg-slate-800 hover:bg-emerald-600 text-white rounded-xl transition flex items-center gap-1 font-bold text-xs cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
            <span className="hidden sm:inline">{t.zoomInBtn}</span>
          </button>

          <button
            onClick={() => zoomFnRef.current?.zoomOut()}
            className="p-2 sm:p-2.5 bg-slate-800 hover:bg-emerald-600 text-white rounded-xl transition flex items-center gap-1 font-bold text-xs cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
            <span className="hidden sm:inline">{t.zoomOutBtn}</span>
          </button>

          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`p-2 sm:p-2.5 rounded-xl transition flex items-center gap-1 font-bold text-xs cursor-pointer ${
              isAutoRotating ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
            title="Toggle 360 Auto-Rotation"
          >
            {isAutoRotating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span className="hidden sm:inline">{isAutoRotating ? 'Pause' : '360°'}</span>
          </button>

          <button
            onClick={() => zoomFnRef.current?.reset()}
            className="p-2 sm:p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition text-xs font-semibold cursor-pointer"
            title="Reset to Birds-Eye View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Google Maps Location Button */}
          <button
            onClick={() => openInGoogleMaps(ventureName)}
            className="p-2 sm:p-2.5 bg-amber-400 hover:bg-amber-500 text-navy-950 rounded-xl transition flex items-center gap-1 font-black text-xs shadow-md border border-amber-300 cursor-pointer"
            title="Open venture location in Google Maps"
          >
            <Navigation className="w-3.5 h-3.5 fill-navy-950" />
            <span className="hidden sm:inline">Google Maps</span>
            <ExternalLink className="w-3 h-3 opacity-70" />
          </button>
        </div>
      </div>

      {/* Lighting & Camera Presets (Top Right Column) */}
      <div className="absolute top-20 right-4 z-20 flex flex-col items-end gap-1.5">
        
        {/* Lighting Selector (Day / Sunset / Night) */}
        <div className="bg-slate-900/90 backdrop-blur-md p-1 rounded-2xl border border-slate-700/80 shadow-xl flex items-center gap-1">
          <button
            onClick={() => handleLightingChange('day')}
            className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              lightingMode === 'day' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
            }`}
            title="Daylight Sun"
          >
            <Sun className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Day</span>
          </button>

          <button
            onClick={() => handleLightingChange('sunset')}
            className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              lightingMode === 'sunset' ? 'bg-orange-500 text-white font-black' : 'text-slate-400 hover:text-white'
            }`}
            title="Golden Hour Sunset"
          >
            <Sunset className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Sunset</span>
          </button>

          <button
            onClick={() => handleLightingChange('night')}
            className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              lightingMode === 'night' ? 'bg-indigo-600 text-white font-black' : 'text-slate-400 hover:text-white'
            }`}
            title="Night Lights"
          >
            <Moon className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Night</span>
          </button>
        </div>

        {/* Cinematic Angle Shortcuts */}
        <div className="bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-700/80 shadow-xl flex flex-col gap-1 text-[11px] font-bold">
          <button
            onClick={() => handleCameraChange('overview')}
            className={`px-3 py-1.5 rounded-xl transition text-left cursor-pointer flex items-center gap-1.5 ${
              activeCameraView === 'overview' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-emerald-300" />
            <span>🦅 Birds-Eye View</span>
          </button>

          <button
            onClick={() => handleCameraChange('entrance')}
            className={`px-3 py-1.5 rounded-xl transition text-left cursor-pointer flex items-center gap-1.5 ${
              activeCameraView === 'entrance' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-amber-300" />
            <span>🏛️ Grand Entrance Arch</span>
          </button>

          <button
            onClick={() => handleCameraChange('boulevard')}
            className={`px-3 py-1.5 rounded-xl transition text-left cursor-pointer flex items-center gap-1.5 ${
              activeCameraView === 'boulevard' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-300" />
            <span>🏡 Villa Boulevard</span>
          </button>

          <button
            onClick={() => handleCameraChange('park')}
            className={`px-3 py-1.5 rounded-xl transition text-left cursor-pointer flex items-center gap-1.5 ${
              activeCameraView === 'park' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-300" />
            <span>🌳 Park & Swimming Pool</span>
          </button>
        </div>

      </div>

      {/* Floating Legend Pill (Bottom Left) */}
      <div className="absolute bottom-4 left-4 z-20 bg-slate-900/90 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-slate-700/80 text-white flex flex-wrap items-center gap-3 text-[11px] shadow-xl">
        <span className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm" /> Available
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm" /> Pending
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm" /> 🏡 Booked (3D Villa)
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-950 border border-slate-600" /> Blocked
        </span>
      </div>

      {/* Interactive 3D Vastu Dynamic Compass Rose Widget (Bottom Right) */}
      <div className="absolute bottom-4 right-4 z-20 bg-slate-900/95 backdrop-blur-md p-2.5 rounded-3xl border border-slate-700/80 shadow-2xl flex items-center gap-3">
        {/* Real-time Rotating Compass Dial */}
        <div className="relative w-14 h-14 flex items-center justify-center shrink-0">
          <div 
            ref={compassNeedleRef}
            className="w-14 h-14 rounded-full border-2 border-slate-600 bg-slate-950 flex items-center justify-center relative shadow-inner"
            style={{ willChange: 'transform' }}
          >
            {/* Cardinal Markers on Dial */}
            <span className="absolute top-0.5 text-[8px] font-black text-red-500">N</span>
            <span className="absolute right-1 text-[8px] font-black text-amber-400">E</span>
            <span className="absolute bottom-0.5 text-[8px] font-black text-slate-300">S</span>
            <span className="absolute left-1 text-[8px] font-black text-slate-300">W</span>
            
            {/* Compass Needle */}
            <div className="w-1.5 h-10 relative flex flex-col items-center">
              <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[20px] border-b-red-500" />
              <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-t-[20px] border-t-slate-400" />
            </div>
            {/* Pivot dot */}
            <div className="absolute w-2.5 h-2.5 rounded-full bg-amber-400 border border-amber-600" />
          </div>
        </div>

        {/* Direction Quick Click Buttons */}
        <div className="flex flex-col gap-1 text-[10px]">
          <span className="text-slate-400 font-extrabold text-[9px] uppercase tracking-wider">
            {activeLang === 'te' ? 'దిశకు తిప్పండి' : 'Orient View'}:
          </span>
          <div className="grid grid-cols-2 gap-1">
            <button 
              onClick={() => orbitToDirRef.current?.('north')}
              className="px-2 py-0.5 bg-red-950/70 hover:bg-red-800 text-red-200 border border-red-700/60 rounded font-black text-center transition cursor-pointer"
              title="Look North"
            >
              ⬆ N (ఉ)
            </button>
            <button 
              onClick={() => orbitToDirRef.current?.('east')}
              className="px-2 py-0.5 bg-amber-950/70 hover:bg-amber-800 text-amber-200 border border-amber-600/60 rounded font-black text-center transition cursor-pointer"
              title="Look East (Vastu)"
            >
              ➡ E (తూ)
            </button>
            <button 
              onClick={() => orbitToDirRef.current?.('south')}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 rounded font-black text-center transition cursor-pointer"
              title="Look South"
            >
              ⬇ S (ద)
            </button>
            <button 
              onClick={() => orbitToDirRef.current?.('west')}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 rounded font-black text-center transition cursor-pointer"
              title="Look West"
            >
              ⬅ W (ప)
            </button>
          </div>
        </div>
      </div>

      {/* Hover Info Tooltip with Owner Name (Requirement 10) */}
      {hoveredPlotInfo && (
        <div className="absolute bottom-16 sm:bottom-6 left-4 sm:left-6 z-30 bg-slate-950/98 backdrop-blur-xl border-2 border-emerald-500 p-4 rounded-3xl text-white shadow-2xl text-xs space-y-2 max-w-xs animate-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between gap-4 font-black border-b border-slate-800 pb-2">
            <span className="text-emerald-400 font-display text-base">Plot {hoveredPlotInfo.plot_number}</span>
            <span className="uppercase text-[10px] px-2.5 py-0.5 rounded-full font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {hoveredPlotInfo.status}
            </span>
          </div>

          {hoveredPlotInfo.owner_name && (
            <div className="bg-amber-500/20 border border-amber-400/50 p-2.5 rounded-2xl text-amber-200 font-bold flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-amber-300 shrink-0" />
              <div>
                <span className="text-[10px] uppercase text-amber-400 block font-black">
                  {t.bookedByLabel}
                </span>
                <span className="text-white text-xs font-bold">{hoveredPlotInfo.owner_name}</span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 text-slate-300 text-[11px] bg-slate-900/60 p-2 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-500 uppercase text-[9px] block">Area</span>
              <strong className="text-white">{hoveredPlotInfo.area_sqyd} sq.yd</strong>
            </div>
            <div>
              <span className="text-slate-500 uppercase text-[9px] block">Facing</span>
              <strong className="text-white text-[10px]">
                {hoveredPlotInfo.facing === 'East' ? '🌅 EAST / తూర్పు (వాస్తు)'
                  : hoveredPlotInfo.facing === 'North' ? '🧭 NORTH / ఉత్తరం'
                  : hoveredPlotInfo.facing === 'West' ? '🏡 WEST / పడమర'
                  : '🏛️ SOUTH / దక్షిణం'}
              </strong>
            </div>
          </div>

          <div className="flex justify-between items-center pt-1">
            <span className="text-emerald-400 font-black text-sm">
              ₹{hoveredPlotInfo.total_price.toLocaleString('en-IN')}
            </span>
            <span className="text-[10px] text-amber-300 font-bold underline">Click to inspect</span>
          </div>
        </div>
      )}

    </div>
  );
};
