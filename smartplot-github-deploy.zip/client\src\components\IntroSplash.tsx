import React, { useState, useEffect, useRef } from 'react';
import { Award, MapPin, Sparkles, ArrowRight, ShieldCheck, CheckCircle2, Compass } from 'lucide-react';

interface IntroSplashProps {
  onFinish: () => void;
}

export const IntroSplash: React.FC<IntroSplashProps> = ({ onFinish }) => {
  const [isFading, setIsFading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('INITIALIZING MASTER LAYOUTS...');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // 1. Particle Ember Canvas (Floating Gold & Emerald Stardust)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Create 65 luxury gold and emerald ember particles
    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedY: number;
      speedX: number;
      opacity: number;
      color: string;
      pulse: number;
    }> = [];

    const colors = [
      'rgba(212, 175, 55, ',   // Champagne Gold
      'rgba(16, 185, 129, ',   // Emerald
      'rgba(52, 211, 153, ',   // Mint Light
      'rgba(245, 158, 11, ',   // Warm Amber
    ];

    for (let i = 0; i < 65; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 2.8 + 0.8,
        speedY: -(Math.random() * 0.9 + 0.3),
        speedX: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.7 + 0.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        pulse: Math.random() * Math.PI * 2,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        p.y += p.speedY;
        p.x += p.speedX;
        p.pulse += 0.03;

        // Reset if off-screen
        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }

        const currentOpacity = p.opacity * (0.6 + 0.4 * Math.sin(p.pulse));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color + currentOpacity + ')';
        ctx.shadowBlur = p.size * 3;
        ctx.shadowColor = p.color + '0.8)';
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  // 2. High-Precision Charging Progress & Staggered Reveal Timing (Fast 2.0s)
  useEffect(() => {
    const startTime = performance.now();
    const duration = 2000; // 2.0s charge time

    let timer: number;
    const updateProgress = (now: number) => {
      const elapsed = now - startTime;
      const pct = Math.min((elapsed / duration) * 100, 100);
      setProgress(pct);

      if (pct < 30) {
        setStatusText('ARCHITECTURAL CAD BLUEPRINT CALIBRATION...');
      } else if (pct < 65) {
        setStatusText('TG-RERA & DTCP 100% CLEAR TITLES VERIFIED...');
      } else if (pct < 95) {
        setStatusText('FEATURING NIRMAL DISTRICT (504106) & HYDERABAD...');
      } else {
        setStatusText('WELCOME TO B.N VENTURES');
      }

      if (pct < 100) {
        timer = requestAnimationFrame(updateProgress);
      }
    };
    timer = requestAnimationFrame(updateProgress);

    // Start optical cinematic fade at 2.1s
    const fadeTimer = setTimeout(() => {
      setIsFading(true);
    }, 2100);

    // Unmount at 2.35s and launch Language Preference step
    const finishTimer = setTimeout(() => {
      onFinish();
    }, 2350);

    return () => {
      cancelAnimationFrame(timer);
      clearTimeout(fadeTimer);
      clearTimeout(finishTimer);
    };
  }, [onFinish]);

  const handleSkip = () => {
    setIsFading(true);
    setTimeout(() => {
      onFinish();
    }, 220);
  };

  return (
    <div
      className={`fixed inset-0 z-[999999] flex flex-col items-center justify-center bg-[#030712] text-white overflow-hidden transition-all duration-700 ease-in-out select-none ${
        isFading 
          ? 'opacity-0 scale-110 filter blur-xl pointer-events-none' 
          : 'opacity-100 scale-100 filter blur-0'
      }`}
    >
      {/* ------------------------------------------------------------- */}
      {/* 1. DYNAMIC CANVAS PARTICLE ENGINE (Floating Embers) */}
      {/* ------------------------------------------------------------- */}
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0" />

      {/* ------------------------------------------------------------- */}
      {/* 2. ARCHITECTURAL CAD GRID & LASER MATRIX */}
      {/* ------------------------------------------------------------- */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Deep Radiant Light Cones */}
        <div className="absolute -top-40 -left-40 w-[650px] h-[650px] bg-emerald-600/20 rounded-full blur-[140px] animate-pulse" />
        <div className="absolute -bottom-40 -right-40 w-[650px] h-[650px] bg-amber-500/18 rounded-full blur-[140px] animate-pulse [animation-delay:1.2s]" />
        
        {/* Blueprint Precision Grid Lines */}
        <div 
          className="absolute inset-0 opacity-[0.06]" 
          style={{
            backgroundImage: `
              linear-gradient(to right, #10b981 1px, transparent 1px),
              linear-gradient(to bottom, #10b981 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px'
          }}
        />

        {/* GPS Live Telemetry Stamp */}
        <div className="absolute top-6 left-6 text-[10px] font-mono tracking-widest text-emerald-400/60 hidden sm:block">
          <div>LAT: 19.0946° N • LONG: 78.3142° E</div>
          <div className="text-amber-400/70">DISTRICT: NIRMAL [504106, TELANGANA]</div>
          <div className="text-slate-500">DTCP APPROVED • TG-RERA VERIFIED</div>
        </div>

        {/* Expanding Energy Shockwaves */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full border border-emerald-500/15 animate-ping [animation-duration:3s]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full border border-amber-400/10 animate-ping [animation-duration:4s]" />
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 3. TOP SKIP INTRO BUTTON */}
      {/* ------------------------------------------------------------- */}
      <div className="absolute top-6 right-6 z-30">
        <button
          onClick={handleSkip}
          className="text-slate-300 hover:text-white text-xs font-bold px-4 py-2 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 transition-all flex items-center gap-1.5 backdrop-blur-md shadow-2xl group cursor-pointer"
        >
          <span>Skip Intro</span>
          <ArrowRight className="w-3.5 h-3.5 text-amber-400 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 4. MAIN CINEMATIC HERO CARD (3D Monogram, Brand & Hologram) */}
      {/* ------------------------------------------------------------- */}
      <div className="relative z-10 text-center px-4 max-w-2xl mx-auto space-y-6 animate-in zoom-in-95 fade-in duration-700">
        
        {/* 3D LUXURY GOLD & EMERALD SHIELD CREST */}
        <div className="relative mx-auto w-32 h-32 sm:w-36 sm:h-36 flex items-center justify-center animate-float-gentle">
          {/* Outer Pulsing Corona */}
          <div className="absolute inset-0 rounded-[32px] bg-gradient-to-tr from-emerald-500 via-amber-400 to-teal-400 opacity-30 blur-2xl animate-pulse" />
          
          {/* Revolving Architectural Compass Ring */}
          <div className="absolute -inset-4 rounded-[40px] border border-dashed border-emerald-400/40 animate-spin [animation-duration:16s]">
            <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-[9px] font-black text-amber-400 bg-slate-950 px-1 rounded">N</span>
            <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-[9px] font-black text-slate-500 bg-slate-950 px-1 rounded">S</span>
            <span className="absolute top-1/2 -right-2 -translate-y-1/2 text-[9px] font-black text-slate-500 bg-slate-950 px-1 rounded">E</span>
            <span className="absolute top-1/2 -left-2 -translate-y-1/2 text-[9px] font-black text-slate-500 bg-slate-950 px-1 rounded">W</span>
          </div>
          
          {/* Heavy Chamfered 3D Emblem Box */}
          <div className="w-full h-full rounded-[28px] bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border-2 border-emerald-400/80 shadow-[0_0_60px_rgba(16,185,129,0.4)] flex flex-col items-center justify-center relative overflow-hidden group">
            {/* Real Specular Moving Beam */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -skew-x-12 animate-shimmer-beam" />
            
            {/* Embossed Metallic Letters */}
            <span className="font-display font-black text-5xl sm:text-6xl tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-amber-200 to-amber-400 drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]">
              BN
            </span>
            <span className="text-[10px] tracking-[0.35em] uppercase text-emerald-400 font-black -mt-1 drop-shadow">
              VENTURES
            </span>
          </div>
        </div>

        {/* 10 YEARS OF PROVEN TRUST • 5 DELIVERED VENTURES */}
        <div className="flex flex-col items-center justify-center space-y-1.5">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-amber-500/20 border border-amber-400/50 text-amber-300 text-xs sm:text-sm font-black tracking-wide shadow-xl backdrop-blur-md">
            <Award className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
            <span>10 Years of Proven Trust • 5 Landmark Ventures</span>
          </div>

          {/* Telugu Heritage Translation */}
          <p className="text-xs sm:text-sm text-emerald-300 font-semibold tracking-wide">
            10 సంవత్సరాల నిజాయితీ గల అనుభవం • 5 ప్రతిష్టాత్మక వెంచర్లు
          </p>
        </div>

        {/* GRAND BRAND HEADLINE WITH DUAL GRADIENTS */}
        <div className="space-y-1.5">
          <h1 className="font-display font-black text-4xl sm:text-6xl text-white tracking-tight drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
            B.N <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-200 to-amber-300">VENTURES</span>
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm font-medium tracking-wide">
            DTCP & TG-RERA Approved Gated Villa Layouts & High-Appreciation Plots
          </p>
        </div>

        {/* NIRMAL DISTRICT 504106 SPOTLIGHT BADGE */}
        <div className="pt-1 flex flex-wrap items-center justify-center gap-2">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border-2 border-emerald-400/80 text-emerald-200 text-xs sm:text-sm font-black shadow-xl shadow-emerald-950/80">
            <MapPin className="w-4 h-4 text-emerald-400 animate-pulse shrink-0" />
            <span>★ Featuring Nirmal District, 504106 (తెలంగాణ)</span>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-300">
            <span className="bg-slate-900/90 px-3 py-1 rounded-xl border border-slate-800 flex items-center gap-1 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 100% Vaastu
            </span>
            <span className="bg-slate-900/90 px-3 py-1 rounded-xl border border-slate-800 flex items-center gap-1 font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Clear Title
            </span>
            <span className="bg-slate-900/90 px-3 py-1 rounded-xl border border-slate-800 flex items-center gap-1 font-bold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> Spot Registration
            </span>
          </div>
        </div>

        {/* HIGH-PRECISION CHARGING LASER PROGRESS GAUGE */}
        <div className="pt-4 max-w-md mx-auto space-y-2">
          <div className="w-full bg-slate-900/95 h-2.5 rounded-full overflow-hidden border border-slate-800 p-0.5 shadow-[inset_0_2px_8px_rgba(0,0,0,0.8)]">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-300 to-amber-400 rounded-full transition-all duration-75 ease-out shadow-[0_0_16px_rgba(16,185,129,0.9)] relative"
              style={{ width: `${Math.min(progress, 100)}%` }}
            >
              {/* Laser Tip Sparkle Head */}
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-[0_0_10px_#ffffff] animate-ping" />
            </div>
          </div>

          <div className="flex justify-between items-center text-[10px] sm:text-xs text-slate-400 uppercase tracking-widest font-mono">
            <span className="flex items-center gap-1.5 text-emerald-400 font-bold truncate max-w-[280px]">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0" />
              {statusText}
            </span>
            <span className="text-white font-black text-xs font-mono">{Math.round(progress)}%</span>
          </div>
        </div>

      </div>

      {/* ------------------------------------------------------------- */}
      {/* 5. BOTTOM VIP NOTICE WATERMARK */}
      {/* ------------------------------------------------------------- */}
      <div className="absolute bottom-6 left-0 right-0 text-center pointer-events-none px-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-slate-500 font-semibold">
          Developed for Government Officers, Teachers, NRI Investors & Elders
        </span>
      </div>

    </div>
  );
};
