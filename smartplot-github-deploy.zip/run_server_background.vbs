Set WshShell = CreateObject("WScript.Shell")
Set oEnv = WshShell.Environment("PROCESS")
oEnv("PATH") = "C:\Users\Dell\nodejs;" & oEnv("PATH")

' Check if node server is running
On Error Resume Next
Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
http.open "GET", "http://localhost:5000/api/ventures", False
http.send ""

If http.status <> 200 Then
    WshShell.CurrentDirectory = "C:\Users\Dell\.gemini\antigravity\scratch\smartplot\server"
    WshShell.Run "cmd /c ""C:\Users\Dell\nodejs\node.exe server.js""", 0, False
End If
