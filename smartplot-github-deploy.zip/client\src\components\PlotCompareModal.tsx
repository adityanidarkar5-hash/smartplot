import React from 'react';
import { X, Layers, Check, Trash2, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { Plot } from '../types';

interface PlotCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  comparedPlots: Plot[];
  onRemovePlot: (plotId: number) => void;
  onSelectForReserve: (plot: Plot) => void;
}

export const PlotCompareModal: React.FC<PlotCompareModalProps> = ({
  isOpen,
  onClose,
  comparedPlots,
  onRemovePlot,
  onSelectForReserve,
}) => {
  if (!isOpen) return null;

  // EMI Calculator Helper: 80% Loan, 8.5% interest, 15 years
  const calculateEstimateEmi = (totalPrice: number) => {
    const loanAmount = totalPrice * 0.8;
    const monthlyRate = 8.5 / 12 / 100;
    const months = 15 * 12;
    const emi = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    return Math.round(emi);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-navy-100 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 flex justify-between items-center border-b border-navy-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-extrabold text-2xl text-white">
                Plot Comparison Matrix
              </h3>
              <p className="text-slate-400 text-xs">
                Side-by-side analysis of up to 3 shortlisted plots
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-white/70 hover:text-white p-1 rounded-full hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-x-auto">
          {comparedPlots.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <Layers className="w-12 h-12 text-slate-300 mx-auto" />
              <h4 className="text-lg font-bold text-navy-900">No Plots Selected for Comparison</h4>
              <p className="text-xs text-navy-500 max-w-sm mx-auto">
                Click "Compare Plot" on any plot from the master layout or plot directory to compare up to 3 plots side-by-side.
              </p>
              <button
                onClick={onClose}
                className="mt-2 bg-emerald-600 text-white font-bold text-xs py-2 px-4 rounded-xl"
              >
                Explore Master Plots
              </button>
            </div>
          ) : (
            <div className="min-w-[600px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-navy-200">
                    <th className="py-3 px-4 font-bold text-navy-500 uppercase tracking-wider w-1/4">
                      Attributes
                    </th>
                    {comparedPlots.map((plot) => (
                      <th key={plot.id} className="py-3 px-4 font-extrabold text-navy-950 text-base">
                        <div className="flex items-center justify-between">
                          <span className="font-display">Plot {plot.plot_number}</span>
                          <button
                            onClick={() => onRemovePlot(plot.id)}
                            className="text-red-500 hover:text-red-700 p-1"
                            title="Remove from comparison"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <span className="text-xs font-normal text-navy-500 block">{plot.block_name}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-navy-100">
                  {/* Status */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Booking Status</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4">
                        <span className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-bold uppercase ${
                          plot.status === 'available' ? 'bg-emerald-100 text-emerald-800' :
                          plot.status === 'pending' ? 'bg-amber-100 text-amber-800' :
                          plot.status === 'blocked' ? 'bg-slate-900 text-white' : 'bg-red-100 text-red-800'
                        }`}>
                          {plot.status}
                        </span>
                      </td>
                    ))}
                  </tr>

                  {/* Area */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Plot Area</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4 font-bold text-navy-900">
                        {plot.area_sqyd} sq.yards
                        <span className="text-[11px] font-normal text-navy-500 block">
                          ({(plot.area_sqyd * 9).toLocaleString('en-IN')} sq.ft)
                        </span>
                      </td>
                    ))}
                  </tr>

                  {/* Dimensions */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Dimensions (L × W)</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4 text-navy-900 font-medium">
                        {plot.dimension_length}' × {plot.dimension_width}' Feet
                      </td>
                    ))}
                  </tr>

                  {/* Facing */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Facing Direction</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4 font-bold text-emerald-700">
                        {plot.facing} Facing
                      </td>
                    ))}
                  </tr>

                  {/* Corner Status */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Corner Plot</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4">
                        {plot.is_corner === 1 ? (
                          <span className="font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            ★ Yes (Corner Plot)
                          </span>
                        ) : (
                          <span className="text-navy-500">Regular Plot</span>
                        )}
                      </td>
                    ))}
                  </tr>

                  {/* Road Width */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Road Width</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4 font-medium text-navy-900">
                        {plot.road_width_ft} Feet Tar Road
                      </td>
                    ))}
                  </tr>

                  {/* Price per sq.yd */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Rate / Sq.Yard</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4 font-bold text-navy-900">
                        ₹{plot.price_per_sqyd.toLocaleString('en-IN')}
                      </td>
                    ))}
                  </tr>

                  {/* Total Cost */}
                  <tr className="bg-emerald-50/50">
                    <td className="py-3.5 px-4 font-bold text-navy-950">Total Consideration</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3.5 px-4 font-black font-display text-base text-emerald-800">
                        ₹{plot.total_price.toLocaleString('en-IN')}
                      </td>
                    ))}
                  </tr>

                  {/* Estimated EMI */}
                  <tr>
                    <td className="py-3 px-4 font-semibold text-navy-700">Est. Bank Loan EMI (15 Yrs)</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-3 px-4 font-bold text-navy-900">
                        ₹{calculateEstimateEmi(plot.total_price).toLocaleString('en-IN')} / month
                        <span className="text-[10px] text-navy-400 block font-normal">80% Loan @ 8.5%</span>
                      </td>
                    ))}
                  </tr>

                  {/* Action */}
                  <tr>
                    <td className="py-4 px-4 font-semibold text-navy-700">Online Action</td>
                    {comparedPlots.map(plot => (
                      <td key={plot.id} className="py-4 px-4">
                        {plot.status === 'available' ? (
                          <button
                            onClick={() => {
                              onClose();
                              onSelectForReserve(plot);
                            }}
                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-3 rounded-lg text-xs shadow transition flex items-center justify-center gap-1"
                          >
                            <Sparkles className="w-3.5 h-3.5" /> Reserve Now
                          </button>
                        ) : (
                          <span className="text-navy-400 text-xs italic block text-center">
                            Not Available
                          </span>
                        )}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
