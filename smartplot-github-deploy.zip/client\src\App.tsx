import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  MapPin, 
  Compass, 
  Layers, 
  Heart, 
  Calendar, 
  PhoneCall, 
  ShieldCheck, 
  RotateCcw, 
  Sparkles, 
  TreePine, 
  CheckCircle2,
  Award,
  MessageCircle,
  Phone
} from 'lucide-react';
import { Venture, Plot, Language } from './types';
import { api } from './api';

// Components
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { FeaturedVentures } from './components/FeaturedVentures';
import { InteractivePlotMap } from './components/InteractivePlotMap';
import { ThreeDPlotView } from './components/ThreeDPlotView';
import { PlotDetailDrawer } from './components/PlotDetailDrawer';
import { PlotDirectory } from './components/PlotDirectory';
import { VentureDetailView } from './components/VentureDetailView';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { SiteVisitModal } from './components/SiteVisitModal';
import { ReservePlotModal } from './components/ReservePlotModal';
import { PlotCompareModal } from './components/PlotCompareModal';
import { DigitalBrochureModal } from './components/DigitalBrochureModal';
import { PlotCalculatorModal } from './components/PlotCalculatorModal';
import { AdminDashboard } from './components/AdminDashboard';
import { LanguageLocationModal } from './components/LanguageLocationModal';
import { InvestInFeature } from './components/InvestInFeature';
import { IntroSplash } from './components/IntroSplash';
import { FloatingVipDesk } from './components/FloatingVipDesk';
import { ActiveLocationBar } from './components/ActiveLocationBar';
import { SecurityTermsModal } from './components/SecurityTermsModal';
import { translations, t } from './i18n';

export function App() {
  const [activePage, setActivePage] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const url = window.location.href.toLowerCase();
      if (
        url.includes('portal=owner') || 
        url.includes('owner') || 
        url.includes('admin') || 
        window.location.hash === '#owner' || 
        window.location.hash === '#admin'
      ) {
        return 'admin';
      }
    }
    return 'home';
  });

  // Owner Secret Gateway Listener
  useEffect(() => {
    const handleHash = () => {
      const h = window.location.hash.toLowerCase();
      if (h === '#owner' || h === '#admin' || h === '#vault') {
        setActivePage('admin');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    window.addEventListener('hashchange', handleHash);

    // Discreet shortcut for owner: Ctrl + Shift + O (Owner Vault)
    const handleKey = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && (e.key === 'O' || e.key === 'o')) {
        e.preventDefault();
        setActivePage('admin');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    window.addEventListener('keydown', handleKey);

    return () => {
      window.removeEventListener('hashchange', handleHash);
      window.removeEventListener('keydown', handleKey);
    };
  }, []);
  const [ventures, setVentures] = useState<Venture[]>([]);
  const [plots, setPlots] = useState<Plot[]>([]);
  const [selectedVenture, setSelectedVenture] = useState<Venture | null>(null);
  const [selectedPlot, setSelectedPlot] = useState<Plot | null>(null);

  // User Requirement: 2 to 3-second Attractive Opening Animation
  const [showIntro, setShowIntro] = useState<boolean>(true);

  // Requirement 1: Language & Location Onboarding Gate (opens only AFTER intro finishes)
  const [currentLang, setCurrentLang] = useState<Language>(() => {
    return (localStorage.getItem('bn_lang') as Language) || 'te';
  });
  const [selectedLocation, setSelectedLocation] = useState<string>(() => {
    return localStorage.getItem('bn_location') || 'Nirmal';
  });
  const [isLangModalOpen, setIsLangModalOpen] = useState<boolean>(false);

  // Step-by-step onboarding pipeline requested by user:
  // 1. First, opening animation displays (2-3 seconds)
  // 2. Next, language preference modal displays
  // 3. Upon picking language, location option displays
  // 4. Upon selecting location, the dashboard displays for exploration
  const handleIntroFinish = () => {
    setShowIntro(false);
    setIsLangModalOpen(true);
  };

  // Layout View mode on homepage (2D SVG vs Conceptual 3D)
  const [homeViewMode, setHomeViewMode] = useState<'2d' | '3d'>('2d');

  // Modals state
  const [isSiteVisitOpen, setIsSiteVisitOpen] = useState(false);
  const [siteVisitVentureId, setSiteVisitVentureId] = useState<number | undefined>();
  const [siteVisitPlot, setSiteVisitPlot] = useState<Plot | null>(null);

  const [isReserveModalOpen, setIsReserveModalOpen] = useState(false);
  const [reserveTargetPlot, setReserveTargetPlot] = useState<Plot | null>(null);

  const [isBrochureModalOpen, setIsBrochureModalOpen] = useState(false);
  const [brochureTargetVenture, setBrochureTargetVenture] = useState<Venture | null>(null);

  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);
  const [calculatorTargetPlot, setCalculatorTargetPlot] = useState<Plot | null>(null);

  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState<boolean>(false);

  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [comparedPlots, setComparedPlots] = useState<Plot[]>([]);

  // Favourites in localStorage
  const [favouritePlotIds, setFavouritePlotIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('bn_favourites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('bn_favourites', JSON.stringify(favouritePlotIds));
    } catch (e) {}
  }, [favouritePlotIds]);

  // Load initial data
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      const v = await api.getVentures();
      setVentures(v);
      if (v.length > 0) {
        // If selectedLocation is Nirmal, prefer the Nirmal venture; otherwise first venture
        const nirmalVenture = v.find(item => 
          (item.district && item.district.toLowerCase().includes('nirmal')) || 
          (item.city && item.city.toLowerCase().includes('nirmal')) || 
          item.pincode === '504106'
        );
        const targetVenture = (selectedLocation.toLowerCase() === 'nirmal' && nirmalVenture) ? nirmalVenture : v[0];
        const detailed = await api.getVentureBySlug(targetVenture.slug);
        setPlots(detailed.plots || []);
        setSelectedVenture(detailed);
      }
    } catch (err) {
      console.error('Failed to load initial venture data:', err);
    }
  };

  // Reload plots after status updates
  const refreshPlots = async () => {
    if (selectedVenture) {
      try {
        const detailed = await api.getVentureBySlug(selectedVenture.slug);
        setPlots(detailed.plots || []);
        const v = await api.getVentures();
        setVentures(v);
      } catch (err) {
        console.error('Failed to refresh plots:', err);
      }
    }
  };

  // Language & Location update handler
  const handleSelectLanguage = (lang: Language) => {
    setCurrentLang(lang);
    localStorage.setItem('bn_lang', lang);
    localStorage.setItem('bn_lang_setup', 'true');
  };

  const handleSelectLocation = (loc: string) => {
    setSelectedLocation(loc);
    localStorage.setItem('bn_location', loc);
    localStorage.setItem('bn_lang_setup', 'true');
  };

  // Favourites handler
  const handleToggleFavourite = (plotId: number) => {
    setFavouritePlotIds(prev => 
      prev.includes(plotId) ? prev.filter(id => id !== plotId) : [...prev, plotId]
    );
  };

  // Comparison handler
  const handleAddToCompare = (plot: Plot) => {
    setComparedPlots(prev => {
      if (prev.some(p => p.id === plot.id)) {
        return prev.filter(p => p.id !== plot.id);
      }
      if (prev.length >= 3) {
        alert(currentLang === 'te' ? 'గరిష్టంగా 3 ప్లాట్లను మాత్రమే పోల్చవచ్చు.' : 'You can compare a maximum of 3 plots at once.');
        return prev;
      }
      return [...prev, plot];
    });
  };

  const handleRemoveComparedPlot = (plotId: number) => {
    setComparedPlots(prev => prev.filter(p => p.id !== plotId));
  };

  // Select venture
  const handleSelectVenture = async (v: Venture) => {
    try {
      const detailed = await api.getVentureBySlug(v.slug);
      setSelectedVenture(detailed);
      setPlots(detailed.plots || []);
      setActivePage('venture-detail');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error('Failed to load venture detail:', err);
    }
  };

  // Open site visit modal with context
  const handleOpenSiteVisit = (plot?: Plot | null) => {
    setSiteVisitPlot(plot || null);
    setSiteVisitVentureId(selectedVenture?.id || ventures[0]?.id || 1);
    setIsSiteVisitOpen(true);
  };

  // Open reservation modal
  const handleOpenReserve = (plot: Plot) => {
    setReserveTargetPlot(plot);
    setIsReserveModalOpen(true);
  };

  // Open brochure modal
  const handleOpenBrochure = (v: Venture) => {
    setBrochureTargetVenture(v);
    setIsBrochureModalOpen(true);
  };

  // Compute cities list dynamically showing ONLY B.N Ventures authentic locations
  // Nirmal District (504106) is our primary featured location
  const nirmalCount = ventures.filter(v => 
    (v.district && v.district.toLowerCase().includes('nirmal')) || 
    (v.city && v.city.toLowerCase().includes('nirmal')) || 
    v.pincode === '504106'
  ).length || 1;

  // Build genuine cities map from active ventures
  const citiesMap = new Map<string, { en: string; te: string; district: string; pincode: string; isFeatured: boolean; count: number }>();
  
  // Featured primary district
  citiesMap.set('nirmal', { 
    en: 'Nirmal', 
    te: 'నిర్మల్', 
    district: 'Nirmal District', 
    pincode: '504106', 
    isFeatured: true, 
    count: nirmalCount 
  });

  ventures.forEach(v => {
    const locKey = (v.city || v.district || '').toLowerCase();
    if (locKey && locKey !== 'nirmal') {
      if (!citiesMap.has(locKey)) {
        citiesMap.set(locKey, {
          en: v.city || v.district || 'Telangana',
          te: v.city_te || v.district_te || v.city || 'తెలంగాణ',
          district: v.district || v.city || 'Telangana',
          pincode: v.pincode || '',
          isFeatured: false,
          count: 1
        });
      } else {
        citiesMap.get(locKey)!.count += 1;
      }
    }
  });

  const cities = Array.from(citiesMap.values());

  // If activePage is 'admin', render the separate Admin Dashboard
  if (activePage === 'admin') {
    return (
      <AdminDashboard 
        onBackToSite={() => {
          setActivePage('home');
          window.scrollTo(0, 0);
          refreshPlots();
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-white text-navy-950 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* User Requirement: 2 to 3-second Attractive Opening Animation */}
      {showIntro && (
        <IntroSplash onFinish={handleIntroFinish} />
      )}

      {/* Requirement 1: Language & Location Selection Modal (Opens on first visit or via Navbar) */}
      <LanguageLocationModal
        isOpen={isLangModalOpen}
        onClose={() => setIsLangModalOpen(false)}
        currentLang={currentLang}
        onSelectLang={handleSelectLanguage}
        selectedLocation={selectedLocation}
        onSelectLocation={handleSelectLocation}
        cities={cities}
      />

      {/* Global Navbar */}
      <Navbar
        activePage={activePage}
        setActivePage={(page) => {
          setActivePage(page);
          window.scrollTo(0, 0);
        }}
        onOpenSiteVisit={() => handleOpenSiteVisit()}
        currentLang={currentLang}
        onSelectLang={handleSelectLanguage}
        selectedLocation={selectedLocation}
        onOpenLangModal={() => setIsLangModalOpen(true)}
        onOpenSecurityTerms={() => setIsSecurityModalOpen(true)}
      />

      {/* Persistent Active Location Bar (User Requirement: Location ON during entire website visit & Google Maps linking) */}
      {activePage !== 'admin' && (
        <ActiveLocationBar
          selectedLocation={selectedLocation}
          onOpenLocationPicker={() => setIsLangModalOpen(true)}
          currentLang={currentLang}
          venturesCount={
            selectedLocation
              ? ventures.filter(v =>
                  (v.city && v.city.toLowerCase() === selectedLocation.toLowerCase()) ||
                  (v.district && v.district.toLowerCase() === selectedLocation.toLowerCase()) ||
                  (v.location && v.location.toLowerCase().includes(selectedLocation.toLowerCase())) ||
                  (v.pincode && v.pincode === selectedLocation)
                ).length
              : ventures.length
          }
        />
      )}

      {/* Main Page Routing */}
      <main className="flex-1">
        
        {/* ======================================================== */}
        {/* 1. HOMEPAGE */}
        {/* ======================================================== */}
        {activePage === 'home' && (
          <div className="space-y-0">
            {/* Hero Section */}
            <Hero
              ventures={ventures}
              selectedLocation={selectedLocation}
              onSelectLocation={handleSelectLocation}
              onExploreVentures={() => {
                setActivePage('ventures');
                window.scrollTo(0, 0);
              }}
              onViewPlots={() => {
                const el = document.getElementById('featured-layout-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              onBookSiteVisit={() => handleOpenSiteVisit()}
              currentLang={currentLang}
            />

            {/* Quick Stats Ribbon (Requirement 2: 10 Years Experience & 5 Ventures) */}
            <section className="bg-navy-950 text-white py-12 border-y border-navy-800">
              <div className="max-w-7xl mx-auto px-4 sm:px-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div className="space-y-1">
                  <div className="text-3xl sm:text-4xl font-display font-extrabold text-emerald-400">10 Years</div>
                  <div className="text-xs sm:text-sm text-slate-300 font-bold">
                    {currentLang === 'te' ? 'విశ్వసనీయ రియల్ ఎస్టేట్ అనుభవం' : 'Real Estate Experience'}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl sm:text-4xl font-display font-extrabold text-emerald-400">
                    {ventures.length > 0 ? ventures.length : 5} Ventures
                  </div>
                  <div className="text-xs sm:text-sm text-slate-300 font-bold">
                    {currentLang === 'te' ? 'పూర్తిగా అభివృద్ధి చేసిన ప్రాజెక్ట్‌లు' : 'Successfully Developed Ventures'}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl sm:text-4xl font-display font-extrabold text-emerald-400">100%</div>
                  <div className="text-xs sm:text-sm text-slate-300 font-bold">
                    {currentLang === 'te' ? 'క్లియర్ టైటిల్ & DTCP / HMDA' : 'Clear Title & RERA Compliant'}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl sm:text-4xl font-display font-extrabold text-emerald-400">1,500+</div>
                  <div className="text-xs sm:text-sm text-slate-300 font-bold">
                    {currentLang === 'te' ? 'సంతృప్తి చెందిన ప్లాట్ యజమానులు' : 'Delighted Plot Owners'}
                  </div>
                </div>
              </div>
            </section>

            {/* Interactive Master Layout Showcase (Requirements 5, 7, 9 & 10) */}
            <section id="featured-layout-section" className="py-16 sm:py-24 bg-slate-900 text-white border-b border-navy-800">
              <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-8">
                
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                  <div className="space-y-3 max-w-2xl">
                    <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800">
                      <Sparkles className="w-3.5 h-3.5" /> B.N Ventures — {t(currentLang, 'interactiveLayout')}
                    </div>
                    <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                      {selectedVenture?.name || 'B.N Golden County'} {t(currentLang, 'masterLayoutPlan')}
                    </h2>
                    <p className="text-slate-300 text-sm leading-relaxed font-medium">
                      {currentLang === 'te'
                        ? 'పెద్ద అక్షరాలతో స్పష్టమైన ప్లాట్ వివరాలు. బుక్ అయిన ప్లాట్లపై యజమాని పేరు కనిపిస్తుంది. జూమ్ ఇన్ మరియు జూమ్ అవుట్ బటన్లను ఉపయోగించండి.'
                        : 'Large legible fonts designed for elders. Click any plot to see area, facing, road width, and owner details for booked plots.'}
                    </p>
                  </div>

                  {/* 2D vs 3D Switcher */}
                  <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 shrink-0">
                    <button
                      onClick={() => setHomeViewMode('2d')}
                      className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
                        homeViewMode === '2d' 
                          ? 'bg-emerald-600 text-white shadow-lg' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Compass className="w-4 h-4" /> 2D Master SVG
                    </button>

                    <button
                      onClick={() => setHomeViewMode('3d')}
                      className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
                        homeViewMode === '3d' 
                          ? 'bg-emerald-600 text-white shadow-lg' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <TreePine className="w-4 h-4 text-emerald-300" /> {t(currentLang, 'conceptual3DView')}
                    </button>
                  </div>
                </div>

                {/* Live Venture Quick Switcher Pill Bar (Auto-updates with newly uploaded ventures) */}
                {ventures.length > 1 && (
                  <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-thin">
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 shrink-0 flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5 text-emerald-400" />
                      {currentLang === 'te' ? 'ప్రాజెక్ట్‌లు:' : 'Ventures:'}
                    </span>
                    <div className="flex items-center gap-2 flex-wrap">
                      {ventures.map((v) => {
                        const isSelected = selectedVenture?.id === v.id;
                        return (
                          <button
                            key={v.id}
                            onClick={async () => {
                              try {
                                const detailed = await api.getVentureBySlug(v.slug);
                                setSelectedVenture(detailed);
                                setPlots(detailed.plots || []);
                                setSelectedPlot(null);
                              } catch (err) {
                                console.error('Failed to switch venture:', err);
                              }
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                              isSelected
                                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-400 shadow-md shadow-emerald-500/20'
                                : 'bg-slate-950/80 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-800'
                            }`}
                          >
                            <MapPin className="w-3 h-3 text-emerald-400" />
                            <span>{v.name}</span>
                            {v.district && (
                              <span className="text-[10px] opacity-75 font-normal">
                                ({v.district})
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* The Map Component */}
                {homeViewMode === '2d' ? (
                  <InteractivePlotMap
                    plots={plots}
                    selectedPlot={selectedPlot}
                    onSelectPlot={(p) => setSelectedPlot(p)}
                    ventureName={selectedVenture?.name || "B.N Nirmal Greenfield County"}
                    lang={currentLang}
                    layoutImageUrl={selectedVenture?.layout_image_url}
                  />
                ) : (
                  <ThreeDPlotView
                    plots={plots}
                    selectedPlot={selectedPlot}
                    onSelectPlot={(p) => setSelectedPlot(p)}
                    ventureName={selectedVenture?.name || "B.N Golden County"}
                    lang={currentLang}
                  />
                )}

              </div>
            </section>

            {/* Featured Ventures Section (Requirement 1 & 2: 5 Ventures filtered by location) */}
            <FeaturedVentures
              ventures={ventures}
              selectedLocation={selectedLocation}
              onSelectVenture={handleSelectVenture}
              onOpenBrochure={handleOpenBrochure}
              currentLang={currentLang}
            />

            {/* Project Amenities & Infrastructure Highlights */}
            <section className="py-16 sm:py-20 bg-slate-50 border-b border-navy-100">
              <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
                <div className="text-center max-w-2xl mx-auto space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100/70 px-3.5 py-1 rounded-full border border-emerald-300">
                    {currentLang === 'te' ? 'అత్యుత్తమ అభివృద్ధి ప్రమాణాలు' : 'World-Class Infrastructure'}
                  </span>
                  <h3 className="font-display text-3xl font-extrabold text-navy-950">
                    {currentLang === 'te' ? 'గౌరవప్రదమైన జీవన శైలి కోసం నాణ్యమైన నిర్మాణం' : 'Engineered for Elevated Living'}
                  </h3>
                  <p className="text-xs sm:text-sm text-navy-600 font-medium">
                    {currentLang === 'te' 
                      ? 'DTCP / HMDA మరియు RERA నిబంధనల ప్రకారం నిర్మించబడిన మౌలిక వసతులు.' 
                      : 'Built to official master-plan standards with high-grade road development and underground infrastructure.'}
                  </p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="bg-white p-6 rounded-3xl border border-navy-100 shadow-sm text-center space-y-3">
                    <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h5 className="font-display font-bold text-navy-950 text-sm">40ft BT Roads</h5>
                    <p className="text-xs text-navy-600">
                      {currentLang === 'te' ? 'విశాలమైన తారు రోడ్లు మరియు పచ్చని చెట్లు' : 'Wide avenues with storm drains & avenue trees'}
                    </p>
                  </div>

                  <div className="bg-white p-6 rounded-3xl border border-navy-100 shadow-sm text-center space-y-3">
                    <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <h5 className="font-display font-bold text-navy-950 text-sm">Underground Power</h5>
                    <p className="text-xs text-navy-600">
                      {currentLang === 'te' ? 'భూగర్భ విద్యుత్ వ్యవస్థ & సోలార్ వీధి దీపాలు' : 'Concealed cabling & LED solar street lighting'}
                    </p>
                  </div>

                  <div className="bg-white p-6 rounded-3xl border border-navy-100 shadow-sm text-center space-y-3">
                    <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto">
                      <TreePine className="w-6 h-6" />
                    </div>
                    <h5 className="font-display font-bold text-navy-950 text-sm">Landscaped Parks</h5>
                    <p className="text-xs text-navy-600">
                      {currentLang === 'te' ? 'పిల్లల ఆట స్థలాలు మరియు వాకింగ్ ట్రాక్స్' : 'Designer gazebos, jogging tracks & play areas'}
                    </p>
                  </div>

                  <div className="bg-white p-6 rounded-3xl border border-navy-100 shadow-sm text-center space-y-3">
                    <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h5 className="font-display font-bold text-navy-950 text-sm">24/7 Security Arch</h5>
                    <p className="text-xs text-navy-600">
                      {currentLang === 'te' ? 'సెక్యూరిటీ గేట్ మరియు సీసీటీవీ నిఘా' : 'Grand arch with security cabin & CCTV surveillance'}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* About Section (Requirement 2: 10 Years Experience Story) */}
            <AboutSection currentLang={currentLang} />

            {/* Requirement 5: Dedicated "Invest in Feature" section at the bottom */}
            <InvestInFeature 
              currentLang={currentLang} 
              onBookSiteVisit={() => handleOpenSiteVisit()} 
            />

            {/* Contact Section (Requirement 6: Regional HQ with Phone & Instant WhatsApp Desk. FAQ removed!) */}
            <ContactSection currentLang={currentLang} />
          </div>
        )}

        {/* ======================================================== */}
        {/* 2. VENTURES LIST PAGE */}
        {/* ======================================================== */}
        {activePage === 'ventures' && (
          <FeaturedVentures
            ventures={ventures}
            selectedLocation={selectedLocation}
            onSelectVenture={handleSelectVenture}
            onOpenBrochure={handleOpenBrochure}
            currentLang={currentLang}
          />
        )}

        {/* ======================================================== */}
        {/* 3. VENTURE DETAILS PAGE */}
        {/* ======================================================== */}
        {activePage === 'venture-detail' && selectedVenture && (
          <VentureDetailView
            venture={selectedVenture}
            plots={plots}
            onBack={() => {
              setActivePage('ventures');
              window.scrollTo(0, 0);
            }}
            selectedPlot={selectedPlot}
            onSelectPlot={(p) => setSelectedPlot(p)}
            onBookSiteVisit={() => handleOpenSiteVisit()}
            onOpenBrochure={handleOpenBrochure}
            lang={currentLang}
          />
        )}

        {/* ======================================================== */}
        {/* 4. EXPLORE PLOTS DIRECTORY PAGE */}
        {/* ======================================================== */}
        {activePage === 'explore-plots' && (
          <PlotDirectory
            plots={plots}
            ventures={ventures}
            onSelectPlot={(p) => setSelectedPlot(p)}
            onReservePlot={handleOpenReserve}
            onToggleFavourite={handleToggleFavourite}
            favouritePlotIds={favouritePlotIds}
            onAddToCompare={handleAddToCompare}
            comparedPlotIds={comparedPlots.map(p => p.id)}
            lang={currentLang}
          />
        )}

        {/* ======================================================== */}
        {/* 5. ABOUT US PAGE */}
        {/* ======================================================== */}
        {activePage === 'about' && <AboutSection currentLang={currentLang} />}

        {/* ======================================================== */}
        {/* 6. CONTACT PAGE */}
        {/* ======================================================== */}
        {activePage === 'contact' && <ContactSection currentLang={currentLang} />}

      </main>

      {/* Global Footer (Visible admin links completely removed) */}
      <Footer
        currentLang={currentLang}
        onOpenSiteVisit={() => handleOpenSiteVisit()}
        onOpenOwnerVault={() => {
          setActivePage('admin');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenSecurityTerms={() => setIsSecurityModalOpen(true)}
      />

      {/* ======================================================== */}
      {/* FLOATING ACTION PILLS */}
      {/* ======================================================== */}



      {/* Floating Comparison Drawer Indicator (When >= 1 plot selected) */}
      {comparedPlots.length > 0 && (
        <div className="fixed bottom-6 left-6 z-40 bg-navy-950 text-white p-3 rounded-2xl shadow-2xl border border-navy-800 flex items-center gap-3 animate-in slide-in-from-bottom duration-300">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></span>
            <span className="text-xs font-bold">{comparedPlots.length}/3 Plots in Comparison</span>
          </div>
          <button
            onClick={() => setIsCompareOpen(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition"
          >
            Compare Now
          </button>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODALS & DRAWERS */}
      {/* ======================================================== */}

      {/* Selected Plot Detail Inspector Drawer (Requirement 5 & 10) */}
      <PlotDetailDrawer
        plot={selectedPlot}
        onClose={() => setSelectedPlot(null)}
        onReserve={handleOpenReserve}
        onBookSiteVisit={(plot) => handleOpenSiteVisit(plot)}
        onOpenCalculator={(plot) => {
          setCalculatorTargetPlot(plot);
          setIsCalculatorOpen(true);
        }}
        currentLang={currentLang}
      />

      {/* Site Visit Appointment Modal (Requirement 7: simplified form) */}
      <SiteVisitModal
        isOpen={isSiteVisitOpen}
        onClose={() => setIsSiteVisitOpen(false)}
        ventures={ventures}
        initialVentureId={siteVisitVentureId}
        initialPlot={siteVisitPlot}
        currentLang={currentLang}
      />

      {/* Plot Reservation Modal (Requirement 10: sets owner name directly on plot) */}
      <ReservePlotModal
        plot={reserveTargetPlot}
        isOpen={isReserveModalOpen}
        onClose={() => setIsReserveModalOpen(false)}
        onSuccess={(updatedPlotId, ownerName) => {
          // Update plot state with booked status and owner name immediately
          setPlots(prev => prev.map(p => {
            if (p.id === updatedPlotId) {
              return { ...p, status: 'booked', owner_name: ownerName };
            }
            return p;
          }));
          if (selectedPlot && selectedPlot.id === updatedPlotId) {
            setSelectedPlot({ ...selectedPlot, status: 'booked', owner_name: ownerName });
          }
          refreshPlots();
        }}
        currentLang={currentLang}
      />

      {/* Plot Comparison Modal */}
      <PlotCompareModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        comparedPlots={comparedPlots}
        onRemovePlot={handleRemoveComparedPlot}
        onSelectForReserve={handleOpenReserve}
      />

      {/* Security Terms & OWASP Top 10 Standards Modal */}
      <SecurityTermsModal
        isOpen={isSecurityModalOpen}
        onClose={() => setIsSecurityModalOpen(false)}
        currentLang={currentLang}
      />

      {/* Digital Venture Brochure Modal */}
      <DigitalBrochureModal
        isOpen={isBrochureModalOpen}
        onClose={() => setIsBrochureModalOpen(false)}
        venture={brochureTargetVenture}
        lang={currentLang}
      />

      {/* 10-Year Durability: Plot Loan & EMI Calculator Modal */}
      <PlotCalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        initialPlot={calculatorTargetPlot}
        currentLang={currentLang}
      />

      {/* Floating Instant WhatsApp VIP Priority Desk (Requirement 6) */}
      <FloatingVipDesk
        currentLang={currentLang}
        onOpenSiteVisit={() => handleOpenSiteVisit()}
        selectedLocation={selectedLocation}
      />

    </div>
  );
}

export default App;
