import React from 'react';
import { Building2, ShieldCheck, Phone, PhoneCall, ExternalLink, Award } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface FooterProps {
  currentLang?: Language;
  onOpenSiteVisit: () => void;
  onOpenOwnerVault?: () => void;
  onOpenSecurityTerms?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ currentLang = 'en', onOpenSiteVisit, onOpenOwnerVault, onOpenSecurityTerms }) => {
  const t = translations[currentLang];

  const [footerClicks, setFooterClicks] = React.useState(0);
  const handleFooterTap = () => {
    if (!onOpenOwnerVault) return;
    setFooterClicks(prev => {
      const next = prev + 1;
      if (next >= 3) {
        onOpenOwnerVault();
        return 0;
      }
      return next;
    });
    setTimeout(() => setFooterClicks(0), 1200);
  };

  return (
    <footer className="bg-navy-950 text-slate-300 border-t border-navy-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-14 space-y-10">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 items-start">
          
          {/* Brand Info (B.N Ventures) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-md">
                <Building2 className="w-6 h-6" />
              </div>
              <span className="font-display font-black text-2xl tracking-tight text-white">
                B.N <span className="text-emerald-400">Ventures</span>
              </span>
            </div>

            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-lg font-medium">
              {currentLang === 'te'
                ? '10 సంవత్సరాల నిజాయితీ గల అనుభవంతో రియల్ ఎస్టేట్ రంగంలో నమ్మకమైన పేరు. చిన్నగా ప్రారంభించి 5 విజయవంతమైన గేటెడ్ లేఅవుట్‌లను అభివృద్ధి చేసి ప్రభుత్వ ఉద్యోగులు, అధికారులకు స్పష్టమైన టైటిల్ డాక్యుమెంట్లతో ప్లాట్లను అందించాం.'
                : 'Backed by 10 years of trusted real estate expertise, B.N Ventures has delivered 5 landmark plotted communities with 100% legal clearance and immediate spot registration.'}
            </p>

            <div className="flex items-center gap-2 text-xs font-bold text-emerald-300 bg-emerald-950/80 border border-emerald-800/80 p-2.5 rounded-xl w-fit">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>100% DTCP & RERA Approved Layouts</span>
            </div>
          </div>

          {/* Direct Calling & Instant WhatsApp Options (Requirement 6) */}
          <div className="lg:col-span-6 space-y-4">
            <h4 className="text-white font-display font-extrabold text-base tracking-wide">
              {t.hqTitle}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              
              {/* Call Owner */}
              <a
                href="tel:+919876543210"
                className="p-4 bg-slate-900 border border-slate-800 rounded-2xl hover:border-emerald-500 transition flex items-center gap-3"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 text-[11px] block">{t.callOwner}</span>
                  <strong className="text-white text-sm">+91 98765 43210</strong>
                </div>
              </a>

              {/* Instant WhatsApp Desk */}
              <a
                href="https://wa.me/919876543210?text=Hello%20B.N%20Ventures,%20I%20want%20to%20know%20more%20about%20plots"
                target="_blank"
                rel="noreferrer"
                className="p-4 bg-emerald-950/60 border border-emerald-800/80 rounded-2xl hover:border-emerald-400 transition flex items-center gap-3"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 font-bold">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-emerald-300 text-[11px] block">{t.whatsappDesk}</span>
                  <strong className="text-white text-xs">Chat Online Now</strong>
                </div>
              </a>

            </div>

            <button
              onClick={onOpenSiteVisit}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm py-3 px-4 rounded-xl transition shadow-md"
            >
              {t.bookSiteVisit}
            </button>
          </div>

        </div>

        {/* Legal Disclaimer */}
        <div className="pt-8 border-t border-navy-800 text-xs text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p onClick={handleFooterTap} className="cursor-default select-none transition">
            © {new Date().getFullYear()} B.N Ventures. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 text-[11px] text-slate-400">
            <span>DTCP Approved</span>
            <span>•</span>
            <span>RERA Registered</span>
            <span>•</span>
            <span>Spot Registration</span>
            <span>•</span>
            {onOpenSecurityTerms && (
              <button
                onClick={onOpenSecurityTerms}
                className="text-emerald-400 hover:text-white font-bold flex items-center gap-1 transition cursor-pointer underline"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{currentLang === 'te' ? 'భద్రతా నిబంధనలు (OWASP)' : 'Security Terms (OWASP)'}</span>
              </button>
            )}
          </div>
        </div>

      </div>
    </footer>
  );
};
