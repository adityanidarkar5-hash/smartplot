import React, { useState } from 'react';
import { X, Calculator, DollarSign, Percent, Calendar, PieChart, ShieldCheck } from 'lucide-react';
import { Plot, Language } from '../types';

interface PlotCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlot?: Plot | null;
  currentLang?: Language;
}

export const PlotCalculatorModal: React.FC<PlotCalculatorModalProps> = ({
  isOpen,
  onClose,
  initialPlot,
  currentLang = 'en',
}) => {
  if (!isOpen) return null;

  const [area, setArea] = useState<number>(initialPlot?.area_sqyd || 200);
  const [ratePerSqYd, setRatePerSqYd] = useState<number>(initialPlot?.price_per_sqyd || 19500);
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(20);
  const [interestRate, setInterestRate] = useState<number>(8.5);
  const [tenureYears, setTenureYears] = useState<number>(15);

  const totalPlotCost = area * ratePerSqYd;
  const downPaymentAmount = Math.round((totalPlotCost * downPaymentPercent) / 100);
  const loanAmount = totalPlotCost - downPaymentAmount;

  // Monthly EMI Calculation
  const monthlyInterestRate = interestRate / 12 / 100;
  const totalMonths = tenureYears * 12;
  const monthlyEmi = Math.round(
    (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths)) /
    (Math.pow(1 + monthlyInterestRate, totalMonths) - 1)
  );

  const totalRepayment = monthlyEmi * totalMonths;
  const totalInterestPayable = totalRepayment - loanAmount;

  // Government & Statutory Estimates
  const stampDutyEstimate = Math.round(totalPlotCost * 0.06); // 6%
  const registrationEstimate = Math.round(totalPlotCost * 0.01); // 1%
  const docMutationEstimate = 25000;
  const totalGovtCharges = stampDutyEstimate + registrationEstimate + docMutationEstimate;
  const totalInitialOutlay = downPaymentAmount + totalGovtCharges;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-navy-100 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-navy-900 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-white/70 hover:text-white p-1 rounded-full hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Calculator className="w-4 h-4" /> Financial Planning Tool
          </div>
          <h3 className="font-display font-extrabold text-2xl text-white">
            Plot Cost & Bank Loan Calculator
          </h3>
          <p className="text-slate-300 text-xs mt-1">
            Estimate monthly EMIs, down payments, and government registration expenses.
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          
          {/* Sliders and Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-navy-700 mb-1">
                Plot Area (Square Yards)
              </label>
              <input
                type="number"
                min="100"
                max="1000"
                step="10"
                value={area}
                onChange={(e) => setArea(Number(e.target.value) || 0)}
                className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2 text-sm font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-navy-700 mb-1">
                Rate per Sq.Yard (₹)
              </label>
              <input
                type="number"
                min="5000"
                max="100000"
                step="500"
                value={ratePerSqYd}
                onChange={(e) => setRatePerSqYd(Number(e.target.value) || 0)}
                className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3 py-2 text-sm font-semibold text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Interactive Sliders */}
          <div className="space-y-4 pt-2 border-t border-navy-100">
            {/* Down Payment */}
            <div>
              <div className="flex justify-between items-center text-xs font-bold text-navy-800 mb-1">
                <span>Down Payment ({downPaymentPercent}%)</span>
                <span className="text-emerald-700">₹{downPaymentAmount.toLocaleString('en-IN')}</span>
              </div>
              <input
                type="range"
                min="10"
                max="60"
                step="5"
                value={downPaymentPercent}
                onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-navy-400 mt-0.5">
                <span>Min 10%</span>
                <span>Max 60%</span>
              </div>
            </div>

            {/* Loan Tenure */}
            <div>
              <div className="flex justify-between items-center text-xs font-bold text-navy-800 mb-1">
                <span>Loan Tenure: {tenureYears} Years</span>
                <span className="text-navy-600">{totalMonths} Monthly Installments</span>
              </div>
              <input
                type="range"
                min="5"
                max="25"
                step="1"
                value={tenureYears}
                onChange={(e) => setTenureYears(Number(e.target.value))}
                className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
            </div>

            {/* Interest Rate */}
            <div>
              <div className="flex justify-between items-center text-xs font-bold text-navy-800 mb-1">
                <span>Annual Interest Rate: {interestRate}%</span>
                <span className="text-navy-500 text-[11px]">Leading Banks (SBI, HDFC, ICICI)</span>
              </div>
              <input
                type="range"
                min="7.0"
                max="12.0"
                step="0.1"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* Result Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Monthly EMI Card */}
            <div className="bg-gradient-to-br from-emerald-600 to-teal-800 text-white p-5 rounded-2xl shadow-lg space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-200">
                Monthly Loan EMI
              </span>
              <div className="text-3xl font-display font-extrabold">
                ₹{monthlyEmi.toLocaleString('en-IN')}
                <span className="text-xs font-normal text-emerald-100"> / month</span>
              </div>
              <div className="pt-2 border-t border-emerald-500/40 text-xs text-emerald-100 space-y-1">
                <div className="flex justify-between">
                  <span>Loan Principal:</span>
                  <strong className="text-white">₹{loanAmount.toLocaleString('en-IN')}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Total Interest:</span>
                  <strong className="text-white">₹{totalInterestPayable.toLocaleString('en-IN')}</strong>
                </div>
              </div>
            </div>

            {/* Upfront Initial Cash Requirement */}
            <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-lg space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Total Upfront Initial Outlay
              </span>
              <div className="text-3xl font-display font-extrabold text-amber-400">
                ₹{totalInitialOutlay.toLocaleString('en-IN')}
              </div>
              <div className="pt-2 border-t border-slate-800 text-xs text-slate-300 space-y-1">
                <div className="flex justify-between">
                  <span>Down Payment ({downPaymentPercent}%):</span>
                  <strong className="text-white">₹{downPaymentAmount.toLocaleString('en-IN')}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Stamp Duty (6%):</span>
                  <strong className="text-white">₹{stampDutyEstimate.toLocaleString('en-IN')}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Registration & Legal:</span>
                  <strong className="text-white">₹{(registrationEstimate + docMutationEstimate).toLocaleString('en-IN')}</strong>
                </div>
              </div>
            </div>

          </div>

          <p className="text-[11px] text-navy-400 text-center italic">
            * Note: EMI and registration figures are approximate simulations for planning purposes. Actual bank sanctions and state registration duties will apply at the time of deed execution.
          </p>

        </div>

      </div>
    </div>
  );
};
