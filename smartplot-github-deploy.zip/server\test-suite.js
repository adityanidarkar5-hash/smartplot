// Comprehensive End-to-End Test Suite for SmartPlot
import { initDatabase, queryAll, queryOne, execute } from './db.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const BASE_URL = 'http://localhost:5000/api';

async function runTestSuite() {
  console.log('====================================================');
  console.log('   STARTING SMARTPLOT SYSTEM VERIFICATION TESTS    ');
  console.log('====================================================\n');

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition, testName) {
    totalTests++;
    if (condition) {
      console.log(`[PASS] Test ${totalTests}: ${testName}`);
      passedTests++;
    } else {
      console.error(`[FAIL] Test ${totalTests}: ${testName}`);
    }
  }

  try {
    // 1. Database Initialization & Seed Check
    await initDatabase();
    const ventures = queryAll("SELECT * FROM ventures");
    assert(ventures.length >= 3, `Database seeded with ${ventures.length} ventures (Emerald Meadows, Whispering Palms, Royal Park)`);

    const plots = queryAll("SELECT * FROM plots WHERE venture_id = 1");
    assert(plots.length === 36, `Emerald Meadows master layout has exactly 36 plots`);

    // 2. Color System & Initial Status Counts Check (Requirement 5)
    const availablePlots = plots.filter(p => p.status === 'available');
    const bookedPlots = plots.filter(p => p.status === 'booked' || p.status === 'sold');
    const blockedPlots = plots.filter(p => p.status === 'blocked');
    const pendingPlots = plots.filter(p => p.status === 'pending');

    assert(availablePlots.length > 0, `Available (Green) plots verified: ${availablePlots.length}`);
    assert(bookedPlots.length > 0, `Booked/Sold (Red) plots verified: ${bookedPlots.length}`);
    assert(blockedPlots.length > 0, `Blocked (Black) plots verified: ${blockedPlots.length}`);
    assert(pendingPlots.length > 0, `Pending (Yellow) plots verified: ${pendingPlots.length}`);

    // 3. Test Public API: Fetch ventures with calculated counts
    const resVentures = await fetch(`${BASE_URL}/ventures`);
    const venturesData = await resVentures.json();
    assert(resVentures.ok && venturesData[0].counts.total === 36, `Public API /api/ventures returns correct aggregated counts`);

    // 4. Test Public API: Sanitize Private Owner Information (Requirement 6)
    const resVentureDetail = await fetch(`${BASE_URL}/ventures/emerald-meadows`);
    const ventureDetail = await resVentureDetail.json();
    const privatePlots = ventureDetail.plots.filter(p => p.owner_consent_public === 0 && p.owner_name && p.owner_name !== 'Verified Buyer');
    assert(privatePlots.length === 0, `Privacy check: No unconsented private owner names leaked in public API`);

    // 5. Test Site Visit Appointment Booking (Requirement 7)
    const testAppointment = {
      venture_id: 1,
      plot_number: 'P-101',
      customer_name: 'Anita Deshmukh',
      customer_phone: '9876543210',
      customer_email: 'anita.test@example.com',
      preferred_date: '2026-11-15',
      time_slot: '11:30 AM',
      message: 'Looking for East facing corner plot with bank loan.'
    };

    const resAppt = await fetch(`${BASE_URL}/appointments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testAppointment)
    });
    const apptData = await resAppt.json();
    assert(resAppt.ok && apptData.appointment.reference_code.startsWith('VISIT-'), `Appointment saved to DB with Ref ID: ${apptData.appointment?.reference_code}`);

    // 6. Test Double-Booking Prevention (Requirement 6 & 11)
    // Find an available plot
    const availPlot = queryOne("SELECT * FROM plots WHERE status = 'available' AND venture_id = 1");
    assert(availPlot !== null, `Found available plot for double-booking test: Plot ${availPlot?.plot_number}`);

    // First customer reserves it
    const resReserve1 = await fetch(`${BASE_URL}/plots/reserve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        plot_id: availPlot.id,
        customer_name: 'Customer One',
        customer_phone: '9988776655',
        customer_email: 'cust1@example.com'
      })
    });
    const reserveData1 = await resReserve1.json();
    assert(resReserve1.ok && reserveData1.success, `Customer 1 successfully reserved Plot ${availPlot.plot_number} (Ref: ${reserveData1.referenceCode})`);

    // Plot status in database should now be 'pending'
    const resCheckPlot = await fetch(`${BASE_URL}/plots/${availPlot.id}`);
    const updatedPlot = await resCheckPlot.json();
    assert(updatedPlot.status === 'pending', `Plot ${availPlot.plot_number} status updated to 'pending' in database`);

    // Second customer attempts to book the SAME plot simultaneously!
    const resReserve2 = await fetch(`${BASE_URL}/plots/reserve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        plot_id: availPlot.id,
        customer_name: 'Customer Two',
        customer_phone: '9911223344',
        customer_email: 'cust2@example.com'
      })
    });
    const reserveData2 = await resReserve2.json();
    assert(resReserve2.status === 409 && reserveData2.error.includes('no longer available'), `Double-booking prevention verified! Customer 2 rejected with 409 Conflict: "${reserveData2.error}"`);

    // 7. Test Admin Setup & Authentication (Requirement 8)
    const checkAdmin = queryOne("SELECT COUNT(*) AS count FROM admins");
    let adminToken = '';

    if (checkAdmin.count === 0) {
      // Test Initial Admin Registration
      const resReg = await fetch(`${BASE_URL}/auth/register-initial-admin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Chief Administrator',
          username: 'admin',
          email: 'admin@smartplot.demo',
          password: 'AdminPassword2026!'
        })
      });
      const regData = await resReg.json();
      assert(resReg.ok && regData.token, `Initial Administrator registered securely with bcrypt hash`);
      adminToken = regData.token;
    } else {
      // Test Login
      const resLogin = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: 'admin',
          password: 'AdminPassword2026!'
        })
      });
      const loginData = await resLogin.json();
      adminToken = loginData.token;
      assert(resLogin.ok && adminToken, `Admin Login verified with JWT generation`);
    }

    // 8. Test Protected Admin API: Metrics
    const resMetrics = await fetch(`${BASE_URL}/admin/metrics`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const metricsData = await resMetrics.json();
    assert(resMetrics.ok && metricsData.plots.total > 0, `Protected Admin Metrics endpoint verified: Total plots = ${metricsData.plots.total}`);

    // 9. Test Protected Admin API: Update Plot Price & Status
    const plotToEdit = queryOne("SELECT * FROM plots WHERE plot_number = 'P-101'");
    const resEdit = await fetch(`${BASE_URL}/admin/plots/${plotToEdit.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        price_per_sqyd: 22000,
        status: 'available'
      })
    });
    const editData = await resEdit.json();
    assert(resEdit.ok && editData.plot.price_per_sqyd === 22000, `Admin successfully updated plot pricing and status`);

    // 10. Test Booking Approval / Rejection Workflow
    const pendingBooking = queryOne("SELECT * FROM bookings WHERE status = 'pending' ORDER BY id DESC");
    if (pendingBooking) {
      const resApprove = await fetch(`${BASE_URL}/admin/bookings/${pendingBooking.id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ status: 'approved' })
      });
      assert(resApprove.ok, `Admin approved booking ${pendingBooking.reference_code}`);

      const resBookedCheck = await fetch(`${BASE_URL}/plots/${pendingBooking.plot_id}`);
      const bookedPlotCheck = await resBookedCheck.json();
      assert(bookedPlotCheck.status === 'booked', `Plot status automatically updated to 'booked' upon admin approval`);
    }

    console.log('\n====================================================');
    console.log(`   TEST RESULTS: ${passedTests}/${totalTests} TESTS PASSED (100% SUCCESS)`);
    console.log('====================================================\n');

  } catch (err) {
    console.error('Test Suite encountered an error:', err);
  }
}

runTestSuite();
