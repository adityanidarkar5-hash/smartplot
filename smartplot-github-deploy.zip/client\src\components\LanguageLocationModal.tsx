import React, { useState, useEffect } from 'react';
import { Globe, MapPin, Check, ArrowRight, Sparkles, Building2, Navigation, ExternalLink, LayoutDashboard } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';
import { openInGoogleMaps } from '../utils/googleMaps';

interface LanguageLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLang: Language;
  onSelectLang: (lang: Language) => void;
  selectedLocation: string;
  onSelectLocation: (loc: string) => void;
  cities: {
    en: string;
    te: string;
    count: number;
    district?: string;
    pincode?: string;
    isFeatured?: boolean;
  }[];
}

export const LanguageLocationModal: React.FC<LanguageLocationModalProps> = ({
  isOpen,
  onClose,
  currentLang,
  onSelectLang,
  selectedLocation,
  onSelectLocation,
  cities,
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<1 | 2>(1);
  const [tempLang, setTempLang] = useState<Language>(currentLang);
  const [tempLoc, setTempLoc] = useState<string>(selectedLocation);

  // Always reset to step 1 (Language Preference) when opened
  useEffect(() => {
    if (isOpen) {
      setStep(1);
      setTempLang(currentLang);
      setTempLoc(selectedLocation);
    }
  }, [isOpen]);

  const t = translations[tempLang];

  const handleLanguagePick = (lang: Language) => {
    setTempLang(lang);
    onSelectLang(lang);
    setStep(2); // Step 2: Automatically advance to location selection
  };

  const handleLocationPick = (loc: string) => {
    setTempLoc(loc);
    onSelectLocation(loc);
    // User picked location -> complete onboarding immediately into Dashboard!
    setTimeout(() => {
      onSelectLang(tempLang);
      onSelectLocation(loc);
      onClose();
    }, 220);
  };

  const handleComplete = () => {
    onSelectLang(tempLang);
    onSelectLocation(tempLoc);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border-2 border-emerald-500 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-900 to-navy-950 text-white p-6 sm:p-8 text-center relative">
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mx-auto mb-3 shadow-lg">
            <Building2 className="w-8 h-8 text-emerald-400" />
          </div>

          <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
            {tempLang === 'te' ? 'B.N వెంచర్స్' : 'B.N Ventures'}
          </h2>
          <p className="text-emerald-200 text-xs sm:text-sm font-semibold mt-1">
            {t.brandTagline}
          </p>

          {/* 3-Step Guided Progress Indicator (User Requirement) */}
          <div className="flex items-center justify-center gap-2 sm:gap-3 mt-6 flex-wrap">
            <button
              onClick={() => setStep(1)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition ${
                step === 1 ? 'bg-white text-emerald-900 shadow-md ring-2 ring-emerald-400' : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              <span>1</span> {tempLang === 'te' ? 'భాష' : 'Language'}
            </button>
            <span className="text-white/40">→</span>
            <button
              onClick={() => setStep(2)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition ${
                step === 2 ? 'bg-white text-emerald-900 shadow-md ring-2 ring-emerald-400' : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              <span>2</span> {tempLang === 'te' ? 'లొకేషన్' : 'Location'}
            </button>
            <span className="text-white/40">→</span>
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white/5 text-white/60">
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>3</span> {tempLang === 'te' ? 'డాష్‌బోర్డ్' : 'Dashboard'}
            </span>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* STEP 1: LANGUAGE SELECTION */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-navy-950">
                  {t.step1Language}
                </h3>
                <p className="text-xs sm:text-sm text-navy-600">
                  Select Telugu for simple conversational language, or English for executive presentation.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                {/* Telugu Card */}
                <button
                  type="button"
                  onClick={() => handleLanguagePick('te')}
                  className={`p-5 rounded-2xl border-2 text-left transition-all duration-200 flex flex-col justify-between h-36 ${
                    tempLang === 'te' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-lg scale-102 ring-2 ring-emerald-500/20' 
                      : 'border-navy-200 hover:border-emerald-400 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                      ప్రధాన భాష
                    </span>
                    {tempLang === 'te' && <Check className="w-5 h-5 text-emerald-600" />}
                  </div>
                  <div>
                    <h4 className="font-display font-black text-2xl text-navy-950">తెలుగు</h4>
                    <p className="text-xs text-navy-600 mt-0.5">సులభమైన, స్పష్టమైన భాష</p>
                  </div>
                </button>

                {/* English Card */}
                <button
                  type="button"
                  onClick={() => handleLanguagePick('en')}
                  className={`p-5 rounded-2xl border-2 text-left transition-all duration-200 flex flex-col justify-between h-36 ${
                    tempLang === 'en' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-lg scale-102 ring-2 ring-emerald-500/20' 
                      : 'border-navy-200 hover:border-emerald-400 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-xs font-bold text-navy-700 bg-slate-100 px-2.5 py-0.5 rounded-full">
                      English
                    </span>
                    {tempLang === 'en' && <Check className="w-5 h-5 text-emerald-600" />}
                  </div>
                  <div>
                    <h4 className="font-display font-black text-2xl text-navy-950">English</h4>
                    <p className="text-xs text-navy-600 mt-0.5">Premium & Professional</p>
                  </div>
                </button>

                {/* Hindi Card */}
                <button
                  type="button"
                  onClick={() => handleLanguagePick('hi')}
                  className={`p-5 rounded-2xl border-2 text-left transition-all duration-200 flex flex-col justify-between h-36 ${
                    tempLang === 'hi' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-lg scale-102 ring-2 ring-emerald-500/20' 
                      : 'border-navy-200 hover:border-emerald-400 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-xs font-bold text-navy-700 bg-slate-100 px-2.5 py-0.5 rounded-full">
                      हिन्दी
                    </span>
                    {tempLang === 'hi' && <Check className="w-5 h-5 text-emerald-600" />}
                  </div>
                  <div>
                    <h4 className="font-display font-black text-2xl text-navy-950">हिन्दी</h4>
                    <p className="text-xs text-navy-600 mt-0.5">सरल और स्पष्ट</p>
                  </div>
                </button>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setStep(2)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-xl text-sm flex items-center gap-2 shadow-md transition"
                >
                  <span>{tempLang === 'te' ? 'లొకేషన్ ఎంచుకోండి' : 'Next: Select Location'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: LOCATION SELECTION */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-navy-950">
                  {t.step2Location}
                </h3>
                <p className="text-xs sm:text-sm text-navy-600">
                  {tempLang === 'te' 
                    ? 'మీకు కావలసిన నగరంపై క్లిక్ చేయండి, ఆ నగరంలోని వెంచర్లు కనిపిస్తాయి.' 
                    : 'Select a city to display all available plotted ventures in that region.'}
                </p>
              </div>

              {/* Location Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                
                {cities.map((city) => {
                  const isSelected = tempLoc.toLowerCase() === city.en.toLowerCase();
                  const isNirmal = city.en.toLowerCase() === 'nirmal';

                  return (
                    <button
                      key={city.en}
                      type="button"
                      onClick={() => handleLocationPick(city.en)}
                      className={`p-4 rounded-2xl border-2 text-left transition relative flex flex-col justify-between ${
                        isNirmal ? 'sm:col-span-2 bg-gradient-to-br from-emerald-50/90 to-amber-50/60 min-h-32' : 'min-h-28'
                      } ${
                        isSelected 
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-md ring-2 ring-emerald-500/20' 
                          : 'border-navy-200 hover:border-emerald-400 bg-white text-navy-800'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-1.5">
                          <MapPin className={`w-4 h-4 ${isNirmal ? 'text-emerald-700' : 'text-emerald-600'}`} />
                          {isNirmal && (
                            <span className="text-[10px] font-black uppercase tracking-wider bg-amber-400/30 text-amber-900 border border-amber-500/40 px-2 py-0.5 rounded-full">
                              ★ Featured District • 504106
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] bg-slate-100 text-navy-700 font-bold px-2 py-0.5 rounded-full">
                            {city.count} {tempLang === 'te' ? 'వెంచర్లు' : 'Ventures'}
                          </span>
                          {isSelected && <Check className="w-4 h-4 text-emerald-600" />}
                        </div>
                      </div>

                      <div className="mt-2">
                        <div className="flex items-baseline gap-1.5">
                          <strong className="text-base font-display font-extrabold text-navy-950 block">
                            {tempLang === 'te' ? city.te : city.en}
                          </strong>
                          {city.pincode && (
                            <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                              PIN: {city.pincode}
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-navy-600 font-medium block mt-0.5">
                          {isNirmal 
                            ? (tempLang === 'te' ? 'నిర్మల్ జిల్లా, 504106, తెలంగాణ, ఇండియా' : 'Nirmal District, 504106, Telangana India')
                            : (tempLang === 'te' ? `${city.en}, తెలంగాణ / ఆంధ్రప్రదేశ్` : `${city.te}, Telangana / AP`)}
                        </span>
                      </div>

                      {/* Google Maps Explore Action */}
                      <div className="pt-2 mt-2 border-t border-navy-100 flex items-center justify-between">
                        <span className="text-[10px] font-bold text-emerald-800 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                          {tempLang === 'te' ? 'లొకేషన్ ఆన్' : 'Location ON'}
                        </span>
                        <span
                          role="button"
                          tabIndex={0}
                          onClick={(e) => {
                            e.stopPropagation();
                            openInGoogleMaps(city.en + (city.pincode ? `, ${city.pincode}` : ''));
                          }}
                          className="inline-flex items-center gap-1 text-[11px] font-extrabold text-amber-900 bg-amber-400 hover:bg-amber-500 px-2.5 py-1 rounded-lg transition shadow-sm"
                          title="Open this location in Google Maps"
                        >
                          <Navigation className="w-3 h-3 fill-amber-900" />
                          <span>Google Maps</span>
                          <ExternalLink className="w-2.5 h-2.5 opacity-80" />
                        </span>
                      </div>
                    </button>
                  );
                })}

                {/* All Locations option */}
                <button
                  type="button"
                  onClick={() => handleLocationPick('')}
                  className={`p-4 rounded-2xl border-2 text-left transition flex flex-col justify-between min-h-28 ${
                    tempLoc === '' 
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-md font-bold' 
                      : 'border-navy-200 hover:border-emerald-400 bg-white text-navy-800'
                  }`}
                >
                  <div className="flex justify-between">
                    <Globe className="w-4 h-4 text-emerald-600" />
                    {tempLoc === '' && <Check className="w-4 h-4 text-emerald-600" />}
                  </div>
                  <div>
                    <strong className="text-sm font-display block text-navy-950">
                      {t.allLocations}
                    </strong>
                    <span className="text-[11px] text-navy-500 block">
                      {tempLang === 'te' ? 'అన్ని ప్రాంతాల వెంచర్లు చూడండి' : 'Show ventures from all districts'}
                    </span>
                  </div>
                </button>
              </div>

              {/* Action button */}
              <div className="pt-6 border-t border-navy-100 flex flex-col sm:flex-row justify-between items-center gap-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs text-navy-500 hover:text-navy-900 underline font-medium"
                >
                  ← {tempLang === 'te' ? 'భాష మార్చుకోండి' : 'Change Language'}
                </button>

                <button
                  type="button"
                  onClick={handleComplete}
                  className="w-full sm:w-auto bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black py-3.5 px-8 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg transition"
                >
                  <LayoutDashboard className="w-4 h-4 text-emerald-200" />
                  <span>{tempLang === 'te' ? 'డాష్‌బోర్డ్ తెరవండి' : 'Open Dashboard & Explore'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
