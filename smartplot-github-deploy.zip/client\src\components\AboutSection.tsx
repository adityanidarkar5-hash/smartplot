import React from 'react';
import { ShieldCheck, Award, Users, CheckCircle, TrendingUp, Building2, UserCheck, Star } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface AboutSectionProps {
  currentLang?: Language;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ currentLang = 'en' }) => {
  const t = translations[currentLang];

  return (
    <section className="py-16 sm:py-24 bg-white border-b border-navy-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-16">
        
        {/* Founder Story Card (Requirement 2) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3.5 py-1 rounded-full border border-emerald-300">
              <Award className="w-4 h-4 text-emerald-700" /> {t.stat1}
            </div>

            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-navy-950 tracking-tight leading-tight">
              {t.ownerExpTitle}
            </h2>

            <p className="text-navy-700 text-sm sm:text-base leading-relaxed font-medium">
              {t.ownerExpDesc}
            </p>

            <div className="bg-slate-50 border-2 border-navy-100 rounded-3xl p-6 space-y-4">
              <h4 className="font-display font-extrabold text-base text-navy-950 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                {currentLang === 'te' ? 'యజమాని ప్రమాణం & నిజాయితీ' : 'Our Developer Commitment'}
              </h4>
              <p className="text-xs sm:text-sm text-navy-600 leading-relaxed">
                {currentLang === 'te'
                  ? 'ప్రతి ప్లాట్‌కు 30 సంవత్సరాల లింక్ డాక్యుమెంట్లు పక్కాగా ఉంటాయి. రిటైర్డ్ అధికారులు, ఉద్యోగులు కష్టపడి దాచుకున్న సొమ్ముకు ఎటువంటి రిస్క్ లేకుండా వెంటనే సబ్-రిజిస్ట్రార్ కార్యాలయంలో మీ పేరు మీద సేల్ డీడ్ రిజిస్ట్రేషన్ చేయిస్తాం.'
                  : 'Every single plot comes with a complete 30-year certified title search. Zero legal disputes, clear boundaries, and direct sub-registrar deed registration guaranteed for every family.'}
              </p>
            </div>

            {/* 4 Stat Boxes */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 text-center">
                <span className="font-display font-black text-2xl text-emerald-800">10 Yrs</span>
                <p className="text-xs text-navy-600 font-bold mt-0.5">{t.stat1}</p>
              </div>

              <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 text-center">
                <span className="font-display font-black text-2xl text-emerald-800">5</span>
                <p className="text-xs text-navy-600 font-bold mt-0.5">{t.stat2}</p>
              </div>

              <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 text-center">
                <span className="font-display font-black text-2xl text-emerald-800">100%</span>
                <p className="text-xs text-navy-600 font-bold mt-0.5">{t.stat3}</p>
              </div>

              <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 text-center">
                <span className="font-display font-black text-2xl text-emerald-800">Spot</span>
                <p className="text-xs text-navy-600 font-bold mt-0.5">{t.stat4}</p>
              </div>
            </div>

          </div>

          {/* Right Image */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-2 border-navy-100">
              <img
                src="https://images.unsplash.com/photo-1542314831-c6a4d27299a9?auto=format&fit=crop&w=1200&q=80"
                alt="B.N Ventures Master Construction Quality"
                className="w-full h-[460px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-1">
                <span className="text-xs text-emerald-400 font-black uppercase tracking-wider">
                  {currentLang === 'te' ? 'నిజాయితీ గల నాణ్యత' : 'PROVEN TRACK RECORD'}
                </span>
                <h4 className="font-display text-xl font-bold">B.N Ventures</h4>
                <p className="text-xs text-slate-300">
                  {currentLang === 'te' 
                    ? 'చిన్నగా ప్రారంభమై 5 వెంచర్లతో వందలాది కుటుంబాల నమ్మకాన్ని గెలుచుకున్న సంస్థ.' 
                    : 'Started small with dedication, now 5 successful ventures across South India.'}
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
