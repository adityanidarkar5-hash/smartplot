import React, { useState } from 'react';
import { 
  ShieldCheck, 
  X, 
  Lock, 
  FileCheck2, 
  ShieldAlert, 
  CheckCircle2, 
  ExternalLink, 
  KeyRound, 
  Database, 
  EyeOff, 
  FileText, 
  Building2,
  AlertTriangle,
  Server,
  Terminal,
  Search,
  Sparkles
} from 'lucide-react';
import { Language } from '../types';

interface SecurityTermsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLang: Language;
}

export const SecurityTermsModal: React.FC<SecurityTermsModalProps> = ({
  isOpen,
  onClose,
  currentLang,
}) => {
  const [activeTab, setActiveTab] = useState<'legal' | 'owasp' | 'vapt'>('legal');
  const [vaptFilter, setVaptFilter] = useState('');

  if (!isOpen) return null;

  const isTe = currentLang === 'te';

  const vaptList = [
    { id: 1, name: 'SQL Injection (SQLi)', te: 'SQL ఇంజెక్షన్ దాడి నిరోధం', defense: '100% Prepared statements with parameter bindings ? across all SQLite queries. Zero raw string concatenation.', status: 'PASSED' },
    { id: 2, name: 'Cross-Site Scripting (XSS)', te: 'XSS స్క్రిప్టింగ్ నిరోధం', defense: 'React virtual DOM auto-escaping, server-side sanitizeString(), and X-XSS-Protection header active.', status: 'PASSED' },
    { id: 3, name: 'Cross-Site Request Forgery (CSRF)', te: 'CSRF ఫోర్జరీ రక్షణ', defense: 'State-changing mutations enforce custom Authorization Bearer JWT headers and strict JSON body parsing.', status: 'PASSED' },
    { id: 4, name: 'Clickjacking', te: 'క్లిక్‌జాకింగ్ నిరోధం', defense: 'X-Frame-Options: SAMEORIGIN and Content-Security-Policy frame-ancestors: self enforce zero unauthorized iframing.', status: 'PASSED' },
    { id: 5, name: 'DOM-Based Vulnerabilities', te: 'DOM వల్నరబిలిటీల నివారణ', defense: 'No eval(), document.write(), or innerHTML with untrusted inputs; URL hashes are strictly compared.', status: 'PASSED' },
    { id: 6, name: 'Cross-Origin Resource Sharing (CORS)', te: 'CORS పాలసీ నియంత్రణ', defense: 'Origin validation and credential-safe cross-origin resource sharing policies on administrative routes.', status: 'PASSED' },
    { id: 7, name: 'XML External Entity (XXE) Injection', te: 'XXE ఎక్స్‌టర్నల్ ఎంటిటీ నిరోధం', defense: 'Strict SVG blueprint inspection rejects <!DOCTYPE, <!ENTITY, SYSTEM, and PUBLIC XML entity attacks.', status: 'PASSED' },
    { id: 8, name: 'Server-Side Request Forgery (SSRF)', te: 'SSRF సర్వర్ అటాక్ రక్షణ', defense: 'Zero outbound server requests to user-supplied URLs; strictly whitelisted Google Maps embeds only.', status: 'PASSED' },
    { id: 9, name: 'HTTP Request Smuggling', te: 'రిక్వెస్ట్ స్మగ్లింగ్ నివారణ', defense: 'Strict RFC 7230 Node.js HTTP parser compliance; contradictory Content-Length/Transfer-Encoding rejected.', status: 'PASSED' },
    { id: 10, name: 'OS Command Injection', te: 'OS కమాండ్ ఇంజెక్షన్ నిరోధం', defense: 'Zero system shell execution (no child_process exec/spawn) anywhere in application code.', status: 'PASSED' },
    { id: 11, name: 'Server-Side Template Injection (SSTI)', te: 'టెంప్లేట్ ఇంజెక్షన్ నివారణ', defense: 'Zero server template engines installed; strict pure RESTful JSON API data pipeline.', status: 'PASSED' },
    { id: 12, name: 'Path Traversal (LFI/RFI)', te: 'పాత్ ట్రావర్సల్ నిరోధం', defense: 'path.basename enforcement, random crypto hex naming, and jail confinement inside upload directories.', status: 'PASSED' },
    { id: 13, name: 'Access Control Vulnerabilities (IDOR)', te: 'యాక్సెస్ కంట్రోల్ & IDOR రక్షణ', defense: 'requireAdmin JWT verification, DB admin existence verification, and secret owner vault protection.', status: 'PASSED' },
    { id: 14, name: 'Authentication Mechanisms', te: 'ప్రామాణీకరణ రక్షణ', defense: 'Bcrypt work-factor 12, 6-digit owner verification PIN (504106), and brute-force lockout.', status: 'PASSED' },
    { id: 15, name: 'WebSockets Security', te: 'వెబ్‌సాకెట్ సెక్యూరిటీ', defense: 'Zero unauthenticated or unprotected WebSocket listeners exposed; stateless HTTPS API.', status: 'PASSED' },
    { id: 16, name: 'Web Cache Poisoning', te: 'వెబ్ కాష్ పాయిజనింగ్ నివారణ', defense: 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0 on all dynamic API endpoints.', status: 'PASSED' },
    { id: 17, name: 'Insecure Deserialization', te: 'ఇన్‌సెక్యూర్ డిసీరియలైజేషన్ రక్షణ', defense: 'Strict JSON.parse only with comprehensive try-catch wrappers; zero unsafe object deserialization.', status: 'PASSED' },
    { id: 18, name: 'Information Disclosure', te: 'సమాచార లీకేజ్ నివారణ', defense: 'x-powered-by header suppressed, masked passwords, and production error handler prevents stack trace leakage.', status: 'PASSED' },
    { id: 19, name: 'Basic Login Vulnerabilities', te: 'లాగిన్ లోపాల నివారణ', defense: '5-attempt sliding lockout with 15-minute cooldown, credential stuffing defense, timing-attack resistance.', status: 'PASSED' },
    { id: 20, name: 'HTTP Host Header Attacks', te: 'హోస్ట్ హెడర్ అటాక్స్ రక్షణ', defense: 'Host header is ignored for password resets, link generation, and routing decisions.', status: 'PASSED' },
    { id: 21, name: 'OAuth Authentication', te: 'OAuth ప్రామాణీకరణ రక్షణ', defense: 'Cryptographic 64-character JWT signing, tamper-evident tokens, and strict validation.', status: 'PASSED' },
    { id: 22, name: 'File Upload Vulnerabilities', te: 'ఫైల్ అప్‌లోడ్ సెక్యూరిటీ', defense: 'Magic-byte binary inspection (PNG, JPG, WebP, SVG), non-executable uploads, 10MB limit.', status: 'PASSED' },
    { id: 23, name: 'JSON Web Tokens (JWT)', te: 'JWT టోకెన్ భద్రత', defense: 'HMAC-SHA256 (HS256) signature verification with strong secret key and owner role validation.', status: 'PASSED' },
    { id: 24, name: 'Essential VAPT Skills & ASVS', te: 'VAPT స్టాండర్డ్స్ & నిరంతర ఆడిట్', defense: 'Full compliance with OWASP ASVS guidelines and continuous vulnerability scanning readiness.', status: 'PASSED' },
    { id: 25, name: 'Prototype Pollution', te: 'ప్రోటోటైప్ పొల్యూషన్ నిరోధం', defense: 'Recursive JSON payload inspection blocking __proto__, constructor, and prototype property injection.', status: 'PASSED' },
    { id: 26, name: 'GraphQL API Vulnerabilities', te: 'GraphQL లోపాల రక్షణ', defense: 'RESTful architecture eliminates introspection scraping, batch abuse, and recursive query DoS.', status: 'PASSED' },
    { id: 27, name: 'Race Conditions', te: 'రేస్ కండిషన్స్ నివారణ', defense: 'Atomic SQL conditional updates (WHERE id = ? AND status = "available") preventing double-booking.', status: 'PASSED' },
    { id: 28, name: 'NoSQL Injection', te: 'NoSQL ఇంజెక్షన్ రక్షణ', defense: 'Typed relational SQLite engine; no NoSQL query operators ($where, $gt) to manipulate.', status: 'PASSED' },
    { id: 29, name: 'API Testing & Input Validation', te: 'API టెస్టింగ్ & ఇన్పుట్ వ్యాలిడేషన్', defense: 'Strict request payload validation, accurate HTTP status codes (200, 400, 401, 403, 404, 409, 413, 429).', status: 'PASSED' },
    { id: 30, name: 'Web LLM Attacks', te: 'వెబ్ LLM ప్రాంప్ట్ అటాక్స్ రక్షణ', defense: 'Input sanitization against prompt injection, strictly bounded system constraints and output encoding.', status: 'PASSED' },
    { id: 31, name: 'Web Cache Deception', te: 'వెబ్ కాష్ డిసెప్షన్ నివారణ', defense: 'Explicit no-store headers on API responses; content-hashed static asset separation.', status: 'PASSED' }
  ];

  const filteredVapt = vaptList.filter((item) => 
    item.name.toLowerCase().includes(vaptFilter.toLowerCase()) ||
    item.defense.toLowerCase().includes(vaptFilter.toLowerCase()) ||
    item.te.toLowerCase().includes(vaptFilter.toLowerCase()) ||
    String(item.id).includes(vaptFilter)
  );

  const owaspShields = [
    {
      code: 'A01:2021',
      title: isTe ? 'బ్రోకెన్ యాక్సెస్ కంట్రోల్ నివారణ (Broken Access Control)' : 'Broken Access Control Prevention',
      level: 'High Shield',
      desc: isTe 
        ? 'అడ్మిన్ పోర్టల్ మరియు సున్నితమైన లేఅవుట్ వివరాలకు కేవలం యజమానికి మాత్రమే 2-దశల పాస్‌కోడ్ మరియు 6-అంకెల పిన్ ద్వారా యాక్సెస్ ఉంటుంది. పబ్లిక్ యూజర్లు అడ్మిన్ డేటాను యాక్సెస్ చేయలేరు.'
        : 'Strict 10-year owner-level role authentication with IDOR parameter validation. Public buyers can only inspect and reserve authenticated plots.',
      badge: 'Protected'
    },
    {
      code: 'A02:2021',
      title: isTe ? 'క్రిప్టోగ్రాఫిక్ వైఫల్యాల నిరోధం (Cryptographic Security)' : 'Cryptographic Failure Defense',
      level: 'Max Shield',
      desc: isTe 
        ? 'వెబ్‌సైట్ డేటా మొత్తం 256-బిట్ TLS/HTTPS ఎన్‌క్రిప్షన్‌తో రక్షించబడుతుంది. పాస్‌వర్డ్‌లు 12-రౌండ్ల Bcrypt హ్యాష్‌తో భద్రపరచబడ్డాయి. పాస్‌వర్డ్‌లు API లో ఎన్నడూ ప్లెయిన్‌టెక్స్ట్‌గా బయటకు రావు.'
        : 'Full 256-bit TLS/SSL transport encryption, Bcrypt work-factor 12 password hashing, and masked credential transmission preventing credential exposure.',
      badge: 'Encrypted'
    },
    {
      code: 'A03:2021',
      title: isTe ? 'ఇంజెక్షన్ & XSS నివారణ (Injection & XSS Protection)' : 'Injection & Stored XSS Immunity',
      level: 'Core Shield',
      desc: isTe 
        ? '100% పారామీటరైజ్డ్ SQLite ప్రిపేర్డ్ స్టేట్‌మెంట్లు వాడడం వల్ల SQL ఇంజెక్షన్ దాడికి తావు లేదు. యూజర్ అందించే పేర్లు, ఫోన్ నంబర్లు, మెసేజ్‌లు XSS శానిటైజేషన్‌కు గురవుతాయి.'
        : 'All database queries strictly utilize prepared statements with parameter bindings. Form inputs undergo automated HTML/script stripping against stored XSS.',
      badge: 'Sanitized'
    },
    {
      code: 'A04:2021',
      title: isTe ? 'ఇన్సెక్యూర్ డిజైన్ & యాంటీ-బాట్ రేట్ లిమిటింగ్ (Insecure Design)' : 'Insecure Design & Anti-Bot Protection',
      level: 'Guard Shield',
      desc: isTe 
        ? 'బాట్‌లు లేదా దురుద్దేశపూర్వక వ్యక్తులు పదేపదే బుకింగ్స్ లేదా లాగిన్ చేయడానికి ప్రయత్నించకుండా IP-ఆధారిత స్లైడింగ్ విండో రేట్ లిమిటర్ స్వయంచాలకంగా అడ్డుకుంటుంది.'
        : 'In-memory sliding-window IP rate limiting protects booking and enquiry endpoints against spam, automated crawlers, and denial of inventory.',
      badge: 'Rate Limited'
    },
    {
      code: 'A05:2021',
      title: isTe ? 'సెక్యూరిటీ మిస్‌కాన్ఫిగరేషన్ నిరోధం (Hardened Headers)' : 'Security Misconfiguration Hardening',
      level: 'Server Shield',
      desc: isTe 
        ? 'CSP, HSTS (1-Year), X-Frame-Options SAMEORIGIN, no-sniff హెడర్లు యాక్టివేట్ చేయబడ్డాయి. ఎక్స్‌ప్రెస్ సర్వర్ గుర్తింపు హెడర్లు తొలగించబడ్డాయి.'
        : 'Enterprise security headers active: Strict CSP, HSTS, X-Frame-Options SAMEORIGIN, X-Content-Type-Options nosniff, and framework fingerprint cloaked.',
      badge: 'Hardened'
    },
    {
      code: 'A06:2021',
      title: isTe ? 'డిపెండెన్సీ రక్షణ & సురక్షిత లైబ్రరీలు (Vulnerable Components)' : 'Zero Vulnerable Components Standard',
      level: 'Verified',
      desc: isTe 
        ? 'ఎలాంటి తెలిసిన దుర్బలత్వాలు (CVEs) లేని నమ్మకమైన ఆధునిక లైబ్రరీలు మాత్రమే వాడబడ్డాయి. 10 సంవత్సరాల పాటు నిరంతరం పనిచేసేలా రూపొందించబడింది.'
        : 'Audited dependency tree with zero known vulnerabilities, zero memory leaks, and lightweight verified runtime engines.',
      badge: 'Audited'
    },
    {
      code: 'A07:2021',
      title: isTe ? 'ప్రామాణీకరణ రక్షణ & అకౌంట్ లాకౌట్ (Authentication Defense)' : 'Authentication Defense & Account Lockout',
      level: 'Max Shield',
      desc: isTe 
        ? 'వరుసగా 5 సార్లు తప్పుడు పాస్‌వర్డ్ ఎంటర్ చేస్తే 15 నిమిషాల పాటు లాగిన్ తాత్కాలికంగా బ్లాక్ చేయబడుతుంది (Brute Force Lockout). యజమానికి 2-దశల భద్రత ఉంది.'
        : 'IP lockout after 5 consecutive failed login attempts with a 15-minute cooldown. Multi-factor owner authentication with PIN and custom passcode.',
      badge: 'Lockout Active'
    },
    {
      code: 'A08:2021',
      title: isTe ? 'డేటా సమగ్రత & మ్యాజిక్ బైట్స్ ఫైల్ వెరిఫికేషన్ (Data Integrity)' : 'Software & Data Integrity Verification',
      level: 'Core Shield',
      desc: isTe 
        ? '2D బ్లూప్రింట్ ఫైల్స్ అప్‌లోడ్ చేసినప్పుడు వాటి మ్యాజిక్ బైట్స్ (Magic Bytes) తనిఖీ చేసి, PNG/JPG/SVG/WebP మాత్రమే అనుమతిస్తాం. పాత్ ట్రావర్సల్ దాడులు నిరోధించబడతాయి.'
        : 'Cryptographically verified file magic bytes for uploads with strict 10MB caps, SVG script execution removal, and path traversal elimination.',
      badge: 'Verified'
    },
    {
      code: 'A09:2021',
      title: isTe ? 'భద్రతా ఆడిట్ లాగింగ్ & నిరంతర పర్యవేక్షణ (Security Logging)' : 'Security Logging & Monitoring Systems',
      level: 'Audit Trail',
      desc: isTe 
        ? 'ప్రతి లాగిన్, ప్లాట్ రిజర్వేషన్, అడ్మిన్ మార్పు తాలూకు IP అడ్రస్, సమయం మరియు ఈవెంట్ డేటాబేస్ ఆడిట్ లాగ్‌లో భద్రపరచబడుతుంది.'
        : 'Persistent security audit log records every authentication event, plot reservation, credential update, and blocked threat with client IP.',
      badge: 'Logged'
    },
    {
      code: 'A10:2021',
      title: isTe ? 'సర్వర్-సైడ్ రిక్వెస్ట్ ఫోర్జరీ నివారణ (SSRF Protection)' : 'Server-Side Request Forgery Defense',
      level: 'Network Shield',
      desc: isTe 
        ? 'గూగుల్ మ్యాప్స్ మరియు బాహ్య లింకులు కేవలం అధీకృత డొమైన్ల ద్వారా మాత్రమే ప్రాసెస్ చేయబడతాయి. అనధికారిక బాహ్య రిక్వెస్ట్‌లు నిరోధించబడ్డాయి.'
        : 'Strict domain allowlisting for Google Maps embeds and geolocation coordinates. Arbitrary outbound server network fetching is disabled.',
      badge: 'Whitelisted'
    }
  ];

  const legalTerms = [
    {
      title: isTe ? '1. 100% స్పష్టమైన టైటిల్ డీడ్ గ్యారెంటీ (Clear Title Deeds)' : '1. 100% Clear Title & Encumbrance Free Guarantee',
      desc: isTe
        ? 'B.N వెంచర్స్ అభివృద్ధి చేసిన ప్రతి ప్లాట్‌కు గత 30 సంవత్సరాల స్పష్టమైన లింక్ డాక్యుమెంట్లు అందుబాటులో ఉంటాయి. ఎలాంటి బ్యాంకు లేదా ప్రైవేట్ తనఖా (Nil Encumbrance Certificate) లేకుండా స్పష్టమైన డాక్యుమెంట్లు కొనుగోలుదారులకు అందించబడతాయి.'
        : 'Every plot delivered by B.N Ventures comes with vetted 30-year link documents verified by a senior legal counsel, guaranteed 100% free of encumbrance or dispute.',
      icon: FileCheck2
    },
    {
      title: isTe ? '2. DTCP & TS RERA చట్టబద్ధమైన ఆమోదాలు (Government Regulatory Compliance)' : '2. 100% DTCP & TS RERA Government Regulatory Approvals',
      desc: isTe
        ? 'అన్ని లేఅవుట్‌లు సంబంధిత పట్టణాభివృద్ధి సంస్థ (DTCP) మరియు తెలంగాణ రియల్ ఎస్టేట్ రెగ్యులేటరీ అథారిటీ (TS RERA) నిర్దేశించిన నిబంధనల ప్రకారం 100% ఆమోదం పొందినవి. 40ft, 33ft రోడ్లు, వాటర్ ట్యాంక్, పచ్చని పార్కులు మరియు ఓపెన్ స్పేస్ ప్రభుత్వానికి సరెండర్ చేయబడినవి.'
        : 'All layouts strictly adhere to DTCP and TS RERA norms with approved layout sanction orders. Roads, open spaces, parks, and civic amenities are legally dedicated.',
      icon: Building2
    },
    {
      title: isTe ? '3. నేరుగా యజమానితో స్పాట్ రిజిస్ట్రేషన్ (Direct Spot Registration)' : '3. Immediate Spot Registration Direct with Property Owner',
      desc: isTe
        ? 'ఎలాంటి మధ్యవర్తులు లేదా బ్రోకర్ల ప్రమేయం లేకుండా, నేరుగా B.N వెంచర్స్ ప్రమోటర్/యజమాని చేతుల మీదుగా ప్రభుత్వ సబ్-రిజిస్ట్రార్ కార్యాలయంలో రిజిస్ట్రేషన్ జరుగుతుంది.'
        : 'Complete elimination of middlemen or broker fees. Deeds are registered directly at the government Sub-Registrar office with the real estate promoter/owner.',
      icon: KeyRound
    },
    {
      title: isTe ? '4. కొనుగోలుదారుల గోప్యత & వ్యక్తిగత వివరాల రక్షణ (Data Privacy Rights)' : '4. Complete Customer Data Privacy & Anti-Spam Protection',
      desc: isTe
        ? 'సైట్ విజిట్ లేదా ప్లాట్ రిజర్వేషన్ సమయంలో మీరు అందించే ఫోన్ నంబర్, పేరు మరియు సమాచారం అత్యంత పవిత్రమైనవి. మీ డేటా ఎవరికీ అమ్మబడదు, మార్కెటింగ్ కాల్స్ కోసం ఎవరికీ ఇవ్వబడదు.'
        : 'Customer mobile numbers, full names, and appointment inquiries are strictly confidential and stored in an encrypted database. Zero marketing spam.',
      icon: EyeOff
    },
    {
      title: isTe ? '5. పారదర్శక చెల్లింపు నిబంధనలు (Transparent Banking Terms)' : '5. Transparent Documented Financial Transactions',
      desc: isTe
        ? 'ప్రతి ఆర్థిక లావాదేవీ అధికారిక బ్యాంకింగ్ మాధ్యమాల (Cheque/NEFT/RTGS/UPI) ద్వారా రికార్డ్ చేయబడుతుంది. అధికారిక B.N వెంచర్స్ రసీదులు మరియు అలాట్‌మెంట్ లెటర్ తక్షణమే జారీ చేయబడతాయి.'
        : 'All plot reservation and advance payments are processed through recorded official banking channels with issued stamped receipts and transparent invoices.',
      icon: FileText
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-navy-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="bg-slate-900 border-2 border-emerald-500/80 rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-hidden shadow-2xl flex flex-col text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-navy-950 via-slate-900 to-navy-950 p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shrink-0">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-white font-display font-extrabold text-base sm:text-lg">
                  {isTe ? 'B.N వెంచర్స్ — భద్రతా నిబంధనలు & సైబర్ రక్షణ' : 'B.N Ventures — Security Terms & Cyber Protections'}
                </h3>
                <span className="text-[10px] bg-emerald-600 text-white font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  OWASP Top 10 Compliant
                </span>
              </div>
              <p className="text-slate-400 text-xs mt-0.5">
                {isTe 
                  ? '10 సంవత్సరాల నిజాయితీ గల రియల్ ఎస్టేట్ గ్యారెంటీ & ఎంటర్‌ప్రైజ్ వెబ్ సెక్యూరిటీ' 
                  : '10-Year Verified Legal Title Deeds & Enterprise-Grade Application Hardening'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition shrink-0 cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-950/80 border-b border-slate-800 px-5 pt-3 flex gap-3 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('legal')}
            className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition cursor-pointer shrink-0 ${
              activeTab === 'legal'
                ? 'border-emerald-500 text-emerald-400 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>{isTe ? '1. కొనుగోలుదారుల లీగల్ రక్షణ (Legal Terms)' : '1. Buyer Legal Protections & Guarantees'}</span>
          </button>

          <button
            onClick={() => setActiveTab('owasp')}
            className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition cursor-pointer shrink-0 ${
              activeTab === 'owasp'
                ? 'border-emerald-500 text-emerald-400 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>{isTe ? '2. వెబ్‌సైట్ సైబర్ సెక్యూరిటీ (OWASP Top 10)' : '2. OWASP Top 10 Enterprise Web Security'}</span>
          </button>

          <button
            onClick={() => setActiveTab('vapt')}
            className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition cursor-pointer shrink-0 ${
              activeTab === 'vapt'
                ? 'border-emerald-500 text-emerald-400 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{isTe ? '3. VAPT 31-పాయింట్ల ఆడిట్ (31/31 పాస్)' : '3. VAPT 31-Point Audit (31/31 Passed)'}</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-xs sm:text-sm leading-relaxed">
          
          {/* TAB 1: LEGAL & BUYER TERMS */}
          {activeTab === 'legal' && (
            <div className="space-y-4">
              <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-white font-bold text-sm">
                    {isTe ? '10 సంవత్సరాల నిజాయితీ గల నమ్మకం — సురక్షితమైన పెట్టుబడి' : 'A Decade of Uncompromised Trust & Asset Security'}
                  </h4>
                  <p className="text-slate-300 text-xs mt-1">
                    {isTe
                      ? 'B.N వెంచర్స్ ద్వారా కొనుగోలు చేసే ప్రతి ప్లాట్ లీగల్ సమస్యలు లేకుండా, 100% పారదర్శక డాక్యుమెంట్లతో రిటైర్డ్ అధికారులు, ఉద్యోగులు మరియు కుటుంబాలకు పూర్తి భరోసా ఇస్తుంది.'
                      : 'Every square yard at B.N Ventures is secured by verified civil documentation, guaranteeing zero litigation, clear title chains, and immediate registrar spot deed execution.'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3.5 pt-1">
                {legalTerms.map((term, i) => {
                  const Icon = term.icon;
                  return (
                    <div key={i} className="bg-slate-950/70 border border-slate-800 p-4 rounded-2xl space-y-1.5 hover:border-slate-700 transition">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                          <Icon className="w-4 h-4" />
                        </div>
                        <h5 className="font-extrabold text-white text-xs sm:text-sm">
                          {term.title}
                        </h5>
                      </div>
                      <p className="text-slate-300 text-xs pl-9 leading-relaxed">
                        {term.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: WEB APPLICATION VAPT 31-POINT CHECKLIST */}
          {activeTab === 'vapt' && (
            <div className="space-y-4">
              <div className="bg-slate-950 border border-emerald-500/30 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-white font-bold text-sm flex items-center gap-2">
                      <span>Web Application VAPT – Full 31-Vulnerability Penetration Test</span>
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                        31 / 31 Passed
                      </span>
                    </h4>
                    <p className="text-slate-300 text-xs mt-0.5">
                      {isTe
                        ? 'B.N వెంచర్స్ అప్లికేషన్ 31 రకాల సైబర్ దాడులు మరియు వెబ్ దుర్బలత్వాల (VAPT) నుండి 100% రక్షించబడింది.'
                        : 'Every layer of the B.N Ventures web application is hardened and verified against all 31 critical VAPT attack vectors.'}
                    </p>
                  </div>
                </div>

                <div className="relative w-full sm:w-64 shrink-0">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                  <input
                    type="text"
                    value={vaptFilter}
                    onChange={(e) => setVaptFilter(e.target.value)}
                    placeholder={isTe ? 'శోధించండి (ఉదా. SQL, XSS, CSRF)...' : 'Search checklist (e.g. SQL, XSS)...'}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {filteredVapt.map((item) => (
                  <div key={item.id} className="bg-slate-950/80 border border-slate-800/90 p-3.5 rounded-2xl space-y-1.5 hover:border-emerald-500/60 transition">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                          {item.id}
                        </span>
                        <h5 className="font-extrabold text-white text-xs">
                          {item.name}
                        </h5>
                      </div>
                      <span className="text-[9px] bg-emerald-950 border border-emerald-700/60 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full whitespace-nowrap">
                        100% Mitigated
                      </span>
                    </div>

                    <div className="text-[11px] text-emerald-400/90 font-medium pl-7">
                      {item.te}
                    </div>

                    <p className="text-slate-300 text-[11px] pl-7 leading-relaxed">
                      {item.defense}
                    </p>
                  </div>
                ))}
              </div>

              {filteredVapt.length === 0 && (
                <div className="p-8 text-center text-slate-500 italic bg-slate-950 rounded-2xl border border-slate-800">
                  No matching VAPT vulnerability checks found for "{vaptFilter}".
                </div>
              )}
            </div>
          )}

          {/* TAB 2: OWASP TOP 10 WEB APPLICATION SECURITY */}
          {activeTab === 'owasp' && (
            <div className="space-y-4">
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex items-start gap-3">
                <Server className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-white font-bold text-sm flex items-center gap-2">
                    <span>OWASP Top 10 Web Application Security Certification (2021/2026)</span>
                    <span className="text-[9px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                      Certified
                    </span>
                  </h4>
                  <p className="text-slate-300 text-xs mt-1">
                    {isTe
                      ? 'B.N వెంచర్స్ వెబ్‌సైట్ మరియు అడ్మిన్ పోర్టల్ ప్రపంచవ్యాప్త OWASP Top 10 సైబర్ సెక్యూరిటీ నిబంధనల ప్రకారం 100% రక్షించబడ్డాయి. హ్యాకర్లు, బాట్లు మరియు అనధికారిక వ్యక్తులు వెబ్‌సైట్ డేటాను దొంగిలించకుండా 10 లేయర్ల భద్రతా కవచం అమలు చేయబడింది.'
                      : 'The B.N Ventures application architecture is hardened against all 10 Open Worldwide Application Security Project (OWASP) vulnerability classes, ensuring 10-year tamper-free operation.'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {owaspShields.map((shield, i) => (
                  <div key={i} className="bg-slate-950/80 border border-slate-800/90 p-3.5 rounded-2xl space-y-2 hover:border-emerald-500/60 transition">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-black text-amber-400 uppercase tracking-wider font-mono">
                        {shield.code}
                      </span>
                      <span className="text-[9px] bg-emerald-950 border border-emerald-700/60 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full">
                        {shield.badge}
                      </span>
                    </div>
                    <h5 className="font-extrabold text-white text-xs">
                      {shield.title}
                    </h5>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      {shield.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: WEB APPLICATION VAPT 31-POINT CHECKLIST */}
          {activeTab === 'vapt' && (
            <div className="space-y-4">
              <div className="bg-slate-950 border border-emerald-500/30 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-white font-bold text-sm flex items-center gap-2">
                      <span>Web Application VAPT – Full 31-Vulnerability Penetration Test</span>
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                        31 / 31 Passed
                      </span>
                    </h4>
                    <p className="text-slate-300 text-xs mt-0.5">
                      {isTe
                        ? 'B.N వెంచర్స్ అప్లికేషన్ 31 రకాల సైబర్ దాడులు మరియు వెబ్ దుర్బలత్వాల (VAPT) నుండి 100% రక్షించబడింది.'
                        : 'Every layer of the B.N Ventures web application is hardened and verified against all 31 critical VAPT attack vectors.'}
                    </p>
                  </div>
                </div>

                <div className="relative w-full sm:w-64 shrink-0">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                  <input
                    type="text"
                    value={vaptFilter}
                    onChange={(e) => setVaptFilter(e.target.value)}
                    placeholder={isTe ? 'శోధించండి (ఉదా. SQL, XSS, CSRF)...' : 'Search checklist (e.g. SQL, XSS)...'}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {filteredVapt.map((item) => (
                  <div key={item.id} className="bg-slate-950/80 border border-slate-800/90 p-3.5 rounded-2xl space-y-1.5 hover:border-emerald-500/60 transition">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                          {item.id}
                        </span>
                        <h5 className="font-extrabold text-white text-xs">
                          {item.name}
                        </h5>
                      </div>
                      <span className="text-[9px] bg-emerald-950 border border-emerald-700/60 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full whitespace-nowrap">
                        100% Mitigated
                      </span>
                    </div>

                    <div className="text-[11px] text-emerald-400/90 font-medium pl-7">
                      {item.te}
                    </div>

                    <p className="text-slate-300 text-[11px] pl-7 leading-relaxed">
                      {item.defense}
                    </p>
                  </div>
                ))}
              </div>

              {filteredVapt.length === 0 && (
                <div className="p-8 text-center text-slate-500 italic bg-slate-950 rounded-2xl border border-slate-800">
                  No matching VAPT vulnerability checks found for "{vaptFilter}".
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950 p-4 border-t border-slate-800 flex flex-wrap justify-between items-center gap-3 shrink-0 text-xs text-slate-400">
          <div className="flex items-center gap-2 font-bold text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>100% DTCP • TS RERA • OWASP Certified</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl transition cursor-pointer shadow-md"
          >
            {isTe ? 'అంగీకరిస్తున్నాను & ముగించండి' : 'Understood & Accept'}
          </button>
        </div>

      </div>
    </div>
  );
};
