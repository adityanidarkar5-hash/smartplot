import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEFAULT_DB_FILE = path.join(__dirname, 'bnventures.db');
const DB_FILE = process.env.VERCEL ? path.join('/tmp', 'bnventures.db') : DEFAULT_DB_FILE;

if (process.env.VERCEL && !fs.existsSync(DB_FILE) && fs.existsSync(DEFAULT_DB_FILE)) {
  try {
    fs.copyFileSync(DEFAULT_DB_FILE, DB_FILE);
  } catch (e) {}
}

let db = null;
let SQL = null;

export async function initDatabase() {
  if (db) return db;

  SQL = await initSqlJs();

  // If old DB exists or new DB exists, load or create fresh
  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing B.N Ventures SQLite database.');
    } catch (err) {
      console.warn('Could not read existing DB file, creating a fresh one:', err.message);
      db = new SQL.Database();
    }
  } else {
    console.log('Creating fresh B.N Ventures SQLite database...');
    db = new SQL.Database();
  }

  createTables();
  cleanNonOurVentures();
  seedDataIfNeeded();
  seedNirmalVentureIfNeeded();
  seedOwnerSecurity();
  saveDatabase();

  return db;
}

export function cleanNonOurVentures() {
  if (!db) return;
  // User Requirement: "it has to show only our ventures"
  // Keep only B.N Ventures' authentic ventures (e.g. Nirmal District 504106 and Golden County)
  const genericSlugs = ['bn-royal-enclave', 'bn-green-city', 'bn-mega-township', 'bn-highway-pride'];
  for (const s of genericSlugs) {
    try {
      const rows = queryAll("SELECT id FROM ventures WHERE slug = ?", [s]);
      if (rows.length > 0) {
        const vId = rows[0].id;
        execute("DELETE FROM plots WHERE venture_id = ?", [vId]);
        execute("DELETE FROM appointments WHERE venture_id = ?", [vId]);
        execute("DELETE FROM bookings WHERE venture_id = ?", [vId]);
        execute("DELETE FROM ventures WHERE id = ?", [vId]);
        console.log(`Cleaned non-B.N venture '${s}' (id: ${vId})`);
      }
    } catch (e) {}
  }
}

export function saveDatabase() {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('Failed to save SQLite database to disk:', err);
  }
}

function createTables() {
  db.run(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS ventures (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      tagline TEXT,
      tagline_te TEXT,
      location TEXT NOT NULL,
      location_te TEXT,
      district TEXT DEFAULT 'Nirmal',
      district_te TEXT DEFAULT 'నిర్మల్ జిల్లా',
      pincode TEXT DEFAULT '504106',
      city TEXT NOT NULL,
      city_te TEXT,
      state TEXT NOT NULL,
      description TEXT,
      description_te TEXT,
      price_per_sqyd_min INTEGER NOT NULL,
      price_per_sqyd_max INTEGER NOT NULL,
      total_plots INTEGER DEFAULT 0,
      status TEXT DEFAULT 'Open for Booking',
      status_te TEXT DEFAULT 'బుకింగ్ అందుబాటులో ఉంది',
      hero_image TEXT,
      gallery_json TEXT,
      videos_json TEXT DEFAULT '[]',
      amenities_json TEXT,
      launch_date TEXT,
      rera_number TEXT,
      map_embed_url TEXT,
      brochure_filename TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS plots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      venture_id INTEGER NOT NULL,
      plot_number TEXT NOT NULL,
      area_sqyd INTEGER NOT NULL,
      dimension_length INTEGER NOT NULL,
      dimension_width INTEGER NOT NULL,
      facing TEXT NOT NULL,
      price_per_sqyd INTEGER NOT NULL,
      total_price INTEGER NOT NULL,
      is_corner INTEGER DEFAULT 0,
      road_width_ft INTEGER DEFAULT 33,
      status TEXT DEFAULT 'available', -- available, pending, booked, sold, blocked
      block_name TEXT DEFAULT 'Sector A',
      pos_x REAL NOT NULL,
      pos_y REAL NOT NULL,
      width REAL NOT NULL,
      height REAL NOT NULL,
      owner_name TEXT DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(venture_id) REFERENCES ventures(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reference_code TEXT UNIQUE NOT NULL,
      venture_id INTEGER NOT NULL,
      plot_id INTEGER,
      plot_number TEXT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      customer_email TEXT,
      preferred_date TEXT NOT NULL,
      time_slot TEXT NOT NULL,
      message TEXT,
      status TEXT DEFAULT 'pending', -- pending, confirmed, completed, cancelled
      admin_notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(venture_id) REFERENCES ventures(id)
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reference_code TEXT UNIQUE NOT NULL,
      plot_id INTEGER NOT NULL,
      venture_id INTEGER NOT NULL,
      plot_number TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      customer_email TEXT,
      amount_paid INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending', -- pending, approved, rejected
      booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(plot_id) REFERENCES plots(id),
      FOREIGN KEY(venture_id) REFERENCES ventures(id)
    );

    CREATE TABLE IF NOT EXISTS enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      venture_id INTEGER,
      plot_number TEXT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      customer_email TEXT,
      subject TEXT,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'new',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- OWASP A09: Security Logging and Monitoring Table
    CREATE TABLE IF NOT EXISTS security_audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      ip_address TEXT,
      user_agent TEXT,
      details TEXT,
      status TEXT DEFAULT 'SUCCESS',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Safe schema migrations for district, district_te, and pincode
  try { db.run("ALTER TABLE ventures ADD COLUMN district TEXT DEFAULT 'Nirmal'"); } catch (e) {}
  try { db.run("ALTER TABLE ventures ADD COLUMN district_te TEXT DEFAULT 'నిర్మల్ జిల్లా'"); } catch (e) {}
  try { db.run("ALTER TABLE ventures ADD COLUMN pincode TEXT DEFAULT '504106'"); } catch (e) {}
  try { db.run("ALTER TABLE ventures ADD COLUMN layout_image_url TEXT DEFAULT NULL"); } catch (e) {}
}

export function seedOwnerSecurity() {
  if (!db) return;
  try { db.run("ALTER TABLE admins ADD COLUMN verification_code TEXT DEFAULT '504106'"); } catch (e) {}
  try { db.run("ALTER TABLE admins ADD COLUMN owner_passcode TEXT DEFAULT 'BNVentures@2026'"); } catch (e) {}

  try {
    const adminRes = db.exec("SELECT id, verification_code, owner_passcode FROM admins LIMIT 1");
    if (adminRes.length === 0 || adminRes[0].values.length === 0) {
      db.run(`
        INSERT INTO admins (username, email, password_hash, name, role, verification_code, owner_passcode)
        VALUES ('owner', 'owner@bnventures.in', 'BNVentures@2026', 'B.N Reddy (Owner & Founder)', 'owner', '504106', 'BNVentures@2026')
      `);
    } else {
      const row = adminRes[0].values[0];
      const existingCode = row[1];
      const existingPasscode = row[2];
      db.run(`
        UPDATE admins 
        SET verification_code = ?,
            owner_passcode = ?,
            role = 'owner',
            name = 'B.N Reddy (Owner & Founder)'
        WHERE id = ?
      `, [existingCode || '504106', existingPasscode || 'BNVentures@2026', row[0]]);
    }
  } catch (err) {
    console.error('Error seeding owner security:', err.message);
  }
}

function seedDataIfNeeded() {
  const result = db.exec("SELECT COUNT(*) AS count FROM ventures");
  const count = result[0]?.values[0][0] || 0;

  if (count > 0) return;

  console.log('Seeding B.N Ventures 5 Landmark Developments...');

  // 5 Ventures representing the owner's 10-year journey from small beginnings to 5 successful developments
  const amenitiesStandard = JSON.stringify([
    "40 & 33 Feet Wide Blacktop Roads (40 మరియు 33 అడుగుల తారు రోడ్లు)",
    "Underground Electricity & Solar Street Lights (భూగర్భ విద్యుత్, సోలార్ దీపాలు)",
    "Grand Entrance Arch with 24/7 Security (భద్రతా గేటు, సెక్యూరిటీ)",
    "Landscaped Parks & Walking Tracks (పచ్చని పార్కులు, వాకింగ్ ట్రాక్)",
    "Overhead Water Tank with Tap Connections (ఓవర్‌హెడ్ వాటర్ ట్యాంక్, ఇంటింటికీ నీటి కనెక్షన్)",
    "100% Vaastu Compliant Layout (100% వాస్తు ప్రకారం రూపొందించిన లేఅవుట్)",
    "Underground Drainage System (భూగర్భ డ్రైనేజీ వ్యవస్థ)",
    "Immediate Spot Registration & Clear Title (వెంటనే స్పాట్ రిజిస్ట్రేషన్, క్లియర్ టైటిల్)"
  ]);

  const sampleVideos = JSON.stringify([
    {
      title: "Venture Drone View & Layout Tour (లేఅవుట్ డ్రోన్ వీడియో)",
      url: "https://www.youtube.com/embed/dQw4w9WgXcQ"
    }
  ]);

  // 1. Venture 1: B.N Golden County (Hyderabad)
  db.run(`
    INSERT INTO ventures (
      slug, name, tagline, tagline_te, location, location_te, city, city_te, state,
      description, description_te, price_per_sqyd_min, price_per_sqyd_max, total_plots,
      status, status_te, hero_image, gallery_json, videos_json, amenities_json,
      launch_date, rera_number, map_embed_url, brochure_filename
    ) VALUES (
      'bn-golden-county',
      'B.N Golden County',
      'DTCP & RERA Approved Luxury Villa Plots near Hyderabad Regional Growth Ring Road',
      'హైదరాబాద్ హైవే సమీపంలో DTCP మరియు RERA అనుమతి పొందిన విల్లా ప్లాట్లు',
      'Highway Corridor, Gachibowli Extended',
      'హైవే కారిడార్, హైదరాబాద్',
      'Hyderabad',
      'హైదరాబాద్',
      'Telangana',
      'B.N Golden County is the flagship venture of B.N Ventures. Designed for peaceful living and high capital growth with 40ft wide roads, underground electricity, full vaastu, and clear title deeds.',
      'B.N గోల్డెన్ కౌంటీ మా ప్రతిష్టాత్మక వెంచర్. 10 సంవత్సరాల అనుభవంతో 40 అడుగుల రోడ్లు, భూగర్భ విద్యుత్, పూర్తి వాస్తు మరియు స్పష్టమైన టైటిల్ డాక్యుమెంట్లతో నిర్మించబడింది.',
      18500,
      24000,
      36,
      'Open for Booking',
      'బుకింగ్ అందుబాటులో ఉంది',
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
      '["https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80"]',
      '${sampleVideos}',
      '${amenitiesStandard.replace(/'/g, "''")}',
      '2026-01-10',
      'RERA/TEL/2026/0842-BN',
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121820.67756191494!2d78.36195764065604!3d17.41684346452296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99daeaebd2c7%3A0xae93b78392bafbc2!2sHyderabad%2C%20Telangana!5e0!3m2!1sen!2sin!4v1700000000000',
      'BN_Golden_County_Brochure.pdf'
    )
  `);

  // 2. Venture 2: B.N Royal Enclave (Vijayawada)
  db.run(`
    INSERT INTO ventures (
      slug, name, tagline, tagline_te, location, location_te, city, city_te, state,
      description, description_te, price_per_sqyd_min, price_per_sqyd_max, total_plots,
      status, status_te, hero_image, gallery_json, videos_json, amenities_json,
      launch_date, rera_number, map_embed_url, brochure_filename
    ) VALUES (
      'bn-royal-enclave',
      'B.N Royal Enclave',
      'Prime Gated Villa Community near Vijayawada Highway & Capital Zone',
      'విజయవాడ రాజధాని బైపాస్ సమీపంలో గేటెడ్ కమ్యూనిటీ ప్లాట్లు',
      'Amaravati Bypass Expressway',
      'అమరావతి బైపాస్, విజయవాడ',
      'Vijayawada',
      'విజయవాడ',
      'Andhra Pradesh',
      'Experience elite community living surrounded by nature and rapid commercial development. Spot registration ready with bank loan facility.',
      'విజయవాడలో అత్యంత వేగంగా అభివృద్ధి చెందుతున్న ప్రదేశంలో గేటెడ్ ప్లాట్లు. బ్యాంకు లోన్ సదుపాయం, వెంటనే రిజిస్ట్రేషన్ సౌకర్యం.',
      16500,
      21000,
      32,
      'Fast Selling',
      'వేగంగా అమ్ముడవుతున్నాయి',
      'https://images.unsplash.com/photo-1582407947304-fd86f028f716?auto=format&fit=crop&w=1200&q=80',
      '["https://images.unsplash.com/photo-1582407947304-fd86f028f716?auto=format&fit=crop&w=1200&q=80"]',
      '${sampleVideos}',
      '${amenitiesStandard.replace(/'/g, "''")}',
      '2026-02-15',
      'RERA/AP/2026/1022-BN',
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d122434.79257697157!2d80.5709439241699!3d16.510148483321598!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a35eff9432d0e43%3A0x53948e10034a0210!2sVijayawada%2C%20Andhra%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000',
      'BN_Royal_Enclave_Brochure.pdf'
    )
  `);

  // 3. Venture 3: B.N Green City (Warangal)
  db.run(`
    INSERT INTO ventures (
      slug, name, tagline, tagline_te, location, location_te, city, city_te, state,
      description, description_te, price_per_sqyd_min, price_per_sqyd_max, total_plots,
      status, status_te, hero_image, gallery_json, videos_json, amenities_json,
      launch_date, rera_number, map_embed_url, brochure_filename
    ) VALUES (
      'bn-green-city',
      'B.N Green City',
      'Eco-Friendly Plotted Layout on Hyderabad-Warangal Industrial Corridor',
      'వరంగల్ ఇండస్ట్రియల్ కారిడార్‌లో ప్రకృతితో కూడిన ప్లాట్లు',
      'Warangal Highway NH-163',
      'వరంగల్ నేషనల్ హైవే',
      'Warangal',
      'వరంగల్',
      'Telangana',
      'Affordable investment plots with guaranteed appreciation, park amenities, and blacktop roads.',
      'సామాన్య ప్రజలు, రిటైర్డ్ ఉద్యోగులకు అందుబాటు ధరలో వరంగల్ హైవే వద్ద ప్లాట్లు.',
      12000,
      15500,
      28,
      'New Launch',
      'కొత్తగా ప్రారంభించబడింది',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      '["https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80"]',
      '${sampleVideos}',
      '${amenitiesStandard.replace(/'/g, "''")}',
      '2026-03-01',
      'RERA/TEL/2026/2219-BN',
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121342.34845610196!2d79.51260408542277!3d17.97858900000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3345dfa640523f%3A0x6b6df1e6b35fb196!2sWarangal%2C%20Telangana!5e0!3m2!1sen!2sin!4v1700000000000',
      'BN_Green_City_Brochure.pdf'
    )
  `);

  // 4. Venture 4: B.N Mega Township (Visakhapatnam)
  db.run(`
    INSERT INTO ventures (
      slug, name, tagline, tagline_te, location, location_te, city, city_te, state,
      description, description_te, price_per_sqyd_min, price_per_sqyd_max, total_plots,
      status, status_te, hero_image, gallery_json, videos_json, amenities_json,
      launch_date, rera_number, map_embed_url, brochure_filename
    ) VALUES (
      'bn-mega-township',
      'B.N Mega Township',
      'Ultra Luxury Coastal Gateway Township near Bhogapuram International Airport',
      'భోగాపురం విమానాశ్రయం సమీపంలో లగ్జరీ టౌన్‌షిప్ ప్లాట్లు',
      'Bhogapuram Airport Expressway',
      'భోగాపురం రోడ్డు, విశాఖపట్నం',
      'Visakhapatnam',
      'విశాఖపట్నం',
      'Andhra Pradesh',
      'Massive 40-acre master-planned venture with 50ft avenues and sea breeze atmosphere.',
      'విశాఖపట్నం ఎయిర్‌పోర్ట్ కారిడార్‌లో భవిష్యత్ అవసరాల కోసం అద్భుతమైన టౌన్‌షిప్.',
      19500,
      27000,
      40,
      'Open for Booking',
      'బుకింగ్ అందుబాటులో ఉంది',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
      '["https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"]',
      '${sampleVideos}',
      '${amenitiesStandard.replace(/'/g, "''")}',
      '2026-04-10',
      'RERA/AP/2026/3390-BN',
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121545.9877142436!2d83.21848154999999!3d17.6868159!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a39431389e6973f%3A0x92d9c20395498468!2sVisakhapatnam%2C%20Andhra%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000',
      'BN_Mega_Township_Brochure.pdf'
    )
  `);

  // 5. Venture 5: B.N Highway Pride (Bengaluru)
  db.run(`
    INSERT INTO ventures (
      slug, name, tagline, tagline_te, location, location_te, city, city_te, state,
      description, description_te, price_per_sqyd_min, price_per_sqyd_max, total_plots,
      status, status_te, hero_image, gallery_json, videos_json, amenities_json,
      launch_date, rera_number, map_embed_url, brochure_filename
    ) VALUES (
      'bn-highway-pride',
      'B.N Highway Pride',
      'Serene Nature-Inspired Gated Enclave on Bengaluru Airport Corridor',
      'బెంగళూరు విమానాశ్రయ కారిడార్‌లో గేటెడ్ విల్లా ప్లాట్లు',
      'Airport North Corridor, Devanahalli Extension',
      'ఎయిర్‌పోర్ట్ కారిడార్, బెంగళూరు',
      'Bengaluru',
      'బెంగళూరు',
      'Karnataka',
      'High returns plot enclave with clubhouse, underground cables, and immediate construction readiness.',
      'బెంగళూరు ఎయిర్‌పోర్ట్ కారిడార్‌లో వెంటనే ఇల్లు కట్టుకోవడానికి సిద్ధంగా ఉన్న ప్లాట్లు.',
      22000,
      31000,
      24,
      'Fast Selling',
      'వేగంగా అమ్ముడవుతున్నాయి',
      'https://images.unsplash.com/photo-1542314831-c6a4d27299a9?auto=format&fit=crop&w=1200&q=80',
      '["https://images.unsplash.com/photo-1542314831-c6a4d27299a9?auto=format&fit=crop&w=1200&q=80"]',
      '${sampleVideos}',
      '${amenitiesStandard.replace(/'/g, "''")}',
      '2026-05-15',
      'RERA/KAR/2026/4102-BN',
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d248849.8865390924!2d77.49085444984182!3d12.953960013994303!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1670c9b44e6d%3A0xf8dfc3e8517e4fe0!2sBengaluru%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1700000000000',
      'BN_Highway_Pride_Brochure.pdf'
    )
  `);

  // Seed 36 plots for B.N Golden County (venture_id = 1)
  seedPlotsForGoldenCounty();
}

function seedPlotsForGoldenCounty() {
  // Requirement 10: "When a person books a plot, that person's name should appear directly on the respective plot in the layout. Display only the plot owner's name on the booked plot."
  const plotsData = [
    // Block A - Row 1 (Plots 101 to 109)
    { num: 'P-101', area: 267, l: 60, w: 40, facing: 'East', price: 21500, corner: 1, road: 40, status: 'available', owner: null, x: 60, y: 70, w_svg: 75, h_svg: 95 },
    { num: 'P-102', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-103', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'pending', owner: 'M. Ramesh', x: 210, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-104', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'booked', owner: 'K. Satyanarayana (Retd. MRO)', x: 280, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-105', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'sold', owner: 'P. Venkata Ramana', x: 350, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-106', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'available', owner: null, x: 420, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-107', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'blocked', owner: null, x: 490, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-108', area: 200, l: 50, w: 36, facing: 'North', price: 19500, corner: 0, road: 33, status: 'available', owner: null, x: 560, y: 70, w_svg: 65, h_svg: 95 },
    { num: 'P-109', area: 280, l: 60, w: 42, facing: 'North-East', price: 23000, corner: 1, road: 40, status: 'available', owner: null, x: 630, y: 70, w_svg: 80, h_svg: 95 },

    // Block A - Row 2 (Plots 110 to 118)
    { num: 'P-110', area: 267, l: 60, w: 40, facing: 'South', price: 20500, corner: 1, road: 40, status: 'sold', owner: 'B. Nageswara Rao', x: 60, y: 170, w_svg: 75, h_svg: 95 },
    { num: 'P-111', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-112', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'available', owner: null, x: 210, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-113', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'pending', owner: 'S. Anjaneyulu', x: 280, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-114', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'booked', owner: 'Ch. Srinivas (Govt. Teacher)', x: 350, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-115', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'available', owner: null, x: 420, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-116', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'blocked', owner: null, x: 490, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-117', area: 200, l: 50, w: 36, facing: 'South', price: 18500, corner: 0, road: 33, status: 'available', owner: null, x: 560, y: 170, w_svg: 65, h_svg: 95 },
    { num: 'P-118', area: 280, l: 60, w: 42, facing: 'South-East', price: 22000, corner: 1, road: 40, status: 'booked', owner: 'D. Sitaramaiah', x: 630, y: 170, w_svg: 80, h_svg: 95 },

    // Block B - Row 1 (Plots 119 to 127)
    { num: 'P-119', area: 300, l: 65, w: 42, facing: 'East', price: 22500, corner: 1, road: 40, status: 'available', owner: null, x: 60, y: 340, w_svg: 75, h_svg: 95 },
    { num: 'P-120', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-121', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'sold', owner: 'M. Anji Reddy', x: 210, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-122', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'available', owner: null, x: 280, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-123', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'available', owner: null, x: 350, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-124', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'pending', owner: 'G. Madhusudhan', x: 420, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-125', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'available', owner: null, x: 490, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-126', area: 240, l: 55, w: 39, facing: 'North', price: 20000, corner: 0, road: 33, status: 'booked', owner: 'V. Krishna Murthy', x: 560, y: 340, w_svg: 65, h_svg: 95 },
    { num: 'P-127', area: 320, l: 65, w: 44, facing: 'North-East', price: 24000, corner: 1, road: 40, status: 'available', owner: null, x: 630, y: 340, w_svg: 80, h_svg: 95 },

    // Block B - Row 2 (Plots 128 to 136)
    { num: 'P-128', area: 300, l: 65, w: 42, facing: 'West', price: 21000, corner: 1, road: 40, status: 'available', owner: null, x: 60, y: 440, w_svg: 75, h_svg: 95 },
    { num: 'P-129', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-130', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'available', owner: null, x: 210, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-131', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'blocked', owner: null, x: 280, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-132', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'sold', owner: 'A. Subba Rao', x: 350, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-133', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'available', owner: null, x: 420, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-134', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'pending', owner: 'T. Prakash', x: 490, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-135', area: 240, l: 55, w: 39, facing: 'South', price: 19000, corner: 0, road: 33, status: 'available', owner: null, x: 560, y: 440, w_svg: 65, h_svg: 95 },
    { num: 'P-136', area: 320, l: 65, w: 44, facing: 'South-East', price: 23500, corner: 1, road: 40, status: 'available', owner: null, x: 630, y: 440, w_svg: 80, h_svg: 95 }
  ];

  for (const p of plotsData) {
    const totalPrice = p.area * p.price;
    const blockName = p.num <= 'P-118' ? 'Sector 1 (North Boulevard)' : 'Sector 2 (Garden View)';
    db.run(`
      INSERT INTO plots (
        venture_id, plot_number, area_sqyd, dimension_length, dimension_width,
        facing, price_per_sqyd, total_price, is_corner, road_width_ft,
        status, block_name, pos_x, pos_y, width, height, owner_name
      ) VALUES (
        1, '${p.num}', ${p.area}, ${p.l}, ${p.w},
        '${p.facing}', ${p.price}, ${totalPrice}, ${p.corner}, ${p.road},
        '${p.status}', '${blockName}', ${p.x}, ${p.y}, ${p.w_svg}, ${p.h_svg},
        ${p.owner ? `'${p.owner}'` : 'NULL'}
      )
    `);
  }
}

function seedNirmalVentureIfNeeded() {
  try {
    const res = db.exec("SELECT id FROM ventures WHERE slug = 'bn-nirmal-greenfield'");
    if (res.length > 0 && res[0].values.length > 0) {
      return; // Already exists
    }

    console.log('Seeding B.N Nirmal Greenfield County (Nirmal District, 504106, Telangana)...');

    const amenitiesNirmal = JSON.stringify([
      "40 & 33 Feet Wide Blacktop Roads (40 మరియు 33 అడుగుల తారు రోడ్లు)",
      "Underground Electricity & Solar Street Lights (భూగర్భ విద్యుత్, సోలార్ దీపాలు)",
      "Grand Entrance Arch with 24/7 Security (భద్రతా గేటు, సెక్యూరిటీ క్యాబిన్)",
      "Landscaped Children Parks & Jogging Track (పచ్చని పార్కులు, జాగింగ్ ట్రాక్)",
      "Overhead Water Tank with Tap Connections (రక్షిత మంచినీటి ట్యాంక్, ఇంటింటికీ కొళాయిలు)",
      "100% Vaastu Compliant Layout (100% వాస్తు ప్రకారం రూపొందించిన లేఅవుట్)",
      "Underground Drainage System (భూగర్భ డ్రైనేజీ వ్యవస్థ)",
      "Immediate Spot Registration & Clear Title (వెంటనే స్పాట్ రిజిస్ట్రేషన్, క్లియర్ టైటిల్)"
    ]);

    const nirmalVideos = JSON.stringify([
      {
        title: "Nirmal Greenfield Layout Drone Walkthrough (నిర్మల్ డ్రోన్ వీడియో టూర్)",
        url: "https://www.youtube.com/embed/dQw4w9WgXcQ"
      }
    ]);

    db.run(`
      INSERT INTO ventures (
        slug, name, tagline, tagline_te, location, location_te,
        district, district_te, pincode, city, city_te, state,
        description, description_te, price_per_sqyd_min, price_per_sqyd_max, total_plots,
        status, status_te, hero_image, gallery_json, videos_json, amenities_json,
        launch_date, rera_number, map_embed_url, brochure_filename
      ) VALUES (
        'bn-nirmal-greenfield',
        'B.N Nirmal Greenfield County',
        'DTCP & RERA Approved Luxury Villa Layout on NH-44 Corridor, Nirmal (504106)',
        'నిర్మల్ NH-44 బైపాస్ సమీపంలో DTCP మరియు RERA అనుమతి పొందిన విల్లా ప్లాట్లు (504106)',
        'NH-44 Bypass & Mancherial Road Junction, Nirmal',
        'NH-44 బైపాస్ మరియు మంచిర్యాల రోడ్డు, నిర్మల్',
        'Nirmal',
        'నిర్మల్ జిల్లా',
        '504106',
        'Nirmal',
        'నిర్మల్',
        'Telangana',
        'B.N Nirmal Greenfield County is a premium 25-acre gated plotted development situated along the high-growth NH-44 / Mancherial Road corridor in Nirmal District (504106), Telangana. Complete with 40ft blacktop roads, underground electricity, central water supply, landscaped children parks, and 100% Vaastu compliance. Perfect for government officers, teachers, businessmen, and investors with spot registration ready.',
        'తెలంగాణలోని నిర్మల్ జిల్లా (504106), NH-44 మరియు మంచిర్యాల రోడ్డు కారిడార్‌లో నిర్మించబడిన 25 ఎకరాల ప్రీమియం గేటెడ్ లేఅవుట్. 40 అడుగుల విశాలమైన తారు రోడ్లు, భూగర్భ విద్యుత్, తాగునీటి సరఫరా, పిల్లల పార్కులు మరియు 100% స్పష్టమైన టైటిల్ డాక్యుమెంట్లు. ప్రభుత్వ ఉద్యోగులు, ఉపాధ్యాయులు మరియు కుటుంబాలకు సురక్షితమైన పెట్టుబడి.',
        11500,
        15500,
        36,
        'Open for Booking',
        'బుకింగ్ అందుబాటులో ఉంది',
        'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
        '["https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80"]',
        '${nirmalVideos}',
        '${amenitiesNirmal.replace(/'/g, "''")}',
        '2026-01-15',
        'RERA/TEL/NIRMAL/2026/0504',
        'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60447.53036665796!2d78.31422789179686!3d19.094625299999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd28b9fb6c75c87%3A0x6bfe76e271c777d4!2sNirmal%2C%20Telangana%20504106!5e0!3m2!1sen!2sin!4v1700000000000',
        'BN_Nirmal_Greenfield_Brochure.pdf'
      )
    `);

    const nirmalIdRes = db.exec("SELECT id FROM ventures WHERE slug = 'bn-nirmal-greenfield'");
    const nirmalVentureId = nirmalIdRes[0]?.values[0][0];

    if (nirmalVentureId) {
      const nirmalPlots = [
        { num: 'P-101', area: 267, l: 60, w: 40, facing: 'East', price: 14500, corner: 1, road: 40, status: 'available', owner: null, x: 60, y: 70, w_svg: 75, h_svg: 95 },
        { num: 'P-102', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-103', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'pending', owner: 'M. Santosh (Nirmal)', x: 210, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-104', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'booked', owner: 'K. Rajeshwar (Retd. MRO, Nirmal)', x: 280, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-105', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'sold', owner: 'G. Srinivas Reddy (Govt. Officer)', x: 350, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-106', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 420, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-107', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'blocked', owner: null, x: 490, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-108', area: 200, l: 50, w: 36, facing: 'North', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 560, y: 70, w_svg: 65, h_svg: 95 },
        { num: 'P-109', area: 280, l: 60, w: 42, facing: 'North-East', price: 15500, corner: 1, road: 40, status: 'available', owner: null, x: 630, y: 70, w_svg: 80, h_svg: 95 },
        { num: 'P-110', area: 267, l: 60, w: 40, facing: 'South', price: 13500, corner: 1, road: 40, status: 'sold', owner: 'B. Mohan Rao (Nirmal 504106)', x: 60, y: 170, w_svg: 75, h_svg: 95 },
        { num: 'P-111', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-112', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'available', owner: null, x: 210, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-113', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'pending', owner: 'P. Ravinder (Nirmal)', x: 280, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-114', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'booked', owner: 'V. Prabhakar (Govt. High School)', x: 350, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-115', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'available', owner: null, x: 420, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-116', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'blocked', owner: null, x: 490, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-117', area: 200, l: 50, w: 36, facing: 'South', price: 12000, corner: 0, road: 33, status: 'available', owner: null, x: 560, y: 170, w_svg: 65, h_svg: 95 },
        { num: 'P-118', area: 280, l: 60, w: 42, facing: 'South-East', price: 14000, corner: 1, road: 40, status: 'booked', owner: 'S. Laxminarayana (Nirmal)', x: 630, y: 170, w_svg: 80, h_svg: 95 },
        { num: 'P-119', area: 300, l: 65, w: 42, facing: 'East', price: 15000, corner: 1, road: 40, status: 'available', owner: null, x: 60, y: 340, w_svg: 75, h_svg: 95 },
        { num: 'P-120', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-121', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'sold', owner: 'Ch. Madhusudhan Rao', x: 210, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-122', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'available', owner: null, x: 280, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-123', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'available', owner: null, x: 350, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-124', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'pending', owner: 'E. Mallesh (Nirmal)', x: 420, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-125', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'available', owner: null, x: 490, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-126', area: 240, l: 55, w: 39, facing: 'North', price: 13000, corner: 0, road: 33, status: 'booked', owner: 'A. Ganga Reddy', x: 560, y: 340, w_svg: 65, h_svg: 95 },
        { num: 'P-127', area: 320, l: 65, w: 44, facing: 'North-East', price: 16000, corner: 1, road: 40, status: 'available', owner: null, x: 630, y: 340, w_svg: 80, h_svg: 95 },
        { num: 'P-128', area: 300, l: 65, w: 42, facing: 'West', price: 14000, corner: 1, road: 40, status: 'available', owner: null, x: 60, y: 440, w_svg: 75, h_svg: 95 },
        { num: 'P-129', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 140, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-130', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 210, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-131', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'blocked', owner: null, x: 280, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-132', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'sold', owner: 'K. Narsing Rao (Nirmal)', x: 350, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-133', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 420, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-134', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'pending', owner: 'T. Vittal (Nirmal)', x: 490, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-135', area: 240, l: 55, w: 39, facing: 'South', price: 12500, corner: 0, road: 33, status: 'available', owner: null, x: 560, y: 440, w_svg: 65, h_svg: 95 },
        { num: 'P-136', area: 320, l: 65, w: 44, facing: 'South-East', price: 15500, corner: 1, road: 40, status: 'available', owner: null, x: 630, y: 440, w_svg: 80, h_svg: 95 }
      ];

      for (const p of nirmalPlots) {
        const totalPrice = p.area * p.price;
        const blockName = p.num <= 'P-118' ? 'Sector 1 (NH-44 Boulevard)' : 'Sector 2 (Mancherial View)';
        db.run(`
          INSERT INTO plots (
            venture_id, plot_number, area_sqyd, dimension_length, dimension_width,
            facing, price_per_sqyd, total_price, is_corner, road_width_ft,
            status, block_name, pos_x, pos_y, width, height, owner_name
          ) VALUES (
            ${nirmalVentureId}, '${p.num}', ${p.area}, ${p.l}, ${p.w},
            '${p.facing}', ${p.price}, ${totalPrice}, ${p.corner}, ${p.road},
            '${p.status}', '${blockName}', ${p.x}, ${p.y}, ${p.w_svg}, ${p.h_svg},
            ${p.owner ? `'${p.owner}'` : 'NULL'}
          )
        `);
      }
    }
  } catch (err) {
    console.error('Failed to seed Nirmal venture:', err.message);
  }
}

export function queryAll(sql, params = []) {
  if (!db) throw new Error('Database not initialized');
  const stmt = db.prepare(sql);
  if (params && params.length) stmt.bind(params);
  const rows = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

export function queryOne(sql, params = []) {
  const rows = queryAll(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

export function execute(sql, params = []) {
  if (!db) throw new Error('Database not initialized');
  db.run(sql, params);
  const rowsModified = typeof db.getRowsModified === 'function' ? db.getRowsModified() : 1;
  saveDatabase();
  const lastId = queryOne("SELECT last_insert_rowid() AS id");
  return { changes: rowsModified, lastInsertRowid: lastId?.id };
}

// OWASP A09: Security Audit Logging System
export function logSecurityEvent(eventType, ip = '127.0.0.1', userAgent = '', details = '', status = 'SUCCESS') {
  if (!db) return;
  try {
    const cleanDetails = typeof details === 'object' ? JSON.stringify(details) : String(details);
    execute(
      "INSERT INTO security_audit_logs (event_type, ip_address, user_agent, details, status) VALUES (?, ?, ?, ?, ?)",
      [eventType, String(ip).slice(0, 45), String(userAgent).slice(0, 255), cleanDetails.slice(0, 1000), status]
    );
  } catch (err) {
    console.error('[SECURITY AUDIT LOG ERROR]:', err.message);
  }
}
