import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { X, Sparkles, ShieldCheck, AlertCircle, CheckCircle2, User, Phone, ArrowRight, UserCheck } from 'lucide-react';
import { Plot, Language } from '../types';
import { translations } from '../i18n';
import { api } from '../api';
import { syncReservationToFirebase } from '../firebase';

interface ReservePlotModalProps {
  plot: Plot | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (updatedPlotId: number, ownerName: string) => void;
  currentLang?: Language;
}

export const ReservePlotModal: React.FC<ReservePlotModalProps> = ({
  plot,
  isOpen,
  onClose,
  onSuccess,
  currentLang = 'en',
}) => {
  if (!isOpen || !plot) return null;

  const t = translations[currentLang];

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bookingResult, setBookingResult] = useState<{
    referenceCode: string;
    message: string;
    ownerName: string;
  } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!customerName.trim() || !customerPhone.trim()) {
      setError(currentLang === 'te' ? 'దయచేసి పూర్తి పేరు మరియు ఫోన్ నెంబర్ నమోదు చేయండి.' : 'Please enter full name and mobile number.');
      return;
    }

    const cleanedPhone = customerPhone.replace(/\D/g, '');
    if (cleanedPhone.length < 10) {
      setError(currentLang === 'te' ? 'సరైన 10 అంకెల మొబైల్ నెంబర్ నమోదు చేయండి.' : 'Please enter a valid 10-digit mobile number.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.reservePlot({
        plot_id: plot.id,
        customer_name: customerName,
        customer_phone: customerPhone,
        customer_email: '',
      });

      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });

      setBookingResult({
        referenceCode: res.referenceCode,
        message: res.message,
        ownerName: customerName.trim()
      });

      // Firebase Cloud Sync (mirrors lead to Cloud Firestore)
      syncReservationToFirebase({
        plot_id: plot.id,
        plot_number: plot.plot_number,
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        reference_code: res.referenceCode,
        venture_id: plot.venture_id,
      });

      onSuccess(plot.id, customerName.trim());
    } catch (err: any) {
      setError(err.message || 'Plot is no longer available. Please select another plot.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border-2 border-emerald-500 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-950 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-white/70 hover:text-white p-1 rounded-full hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="flex items-center gap-2 text-emerald-300 text-xs font-black uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" /> B.N Ventures
          </div>
          <h3 className="font-display font-black text-2xl text-white">
            {t.reserveTitle} — Plot {plot.plot_number}
          </h3>
          <p className="text-emerald-100 text-xs mt-1">
            {t.reserveSubtitle}
          </p>
        </div>

        {/* Content */}
        <div className="p-6">
          {bookingResult ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
                  {currentLang === 'te' ? 'ప్లాట్ మీ పేరు మీద లాక్ చేయబడింది' : 'Plot Locked Under Your Name'}
                </span>
                <h4 className="font-display font-black text-2xl text-navy-950 pt-2">
                  {currentLang === 'te' ? 'రిజర్వేషన్ పూర్తయింది!' : 'Reservation Successful!'}
                </h4>
                <p className="text-sm text-navy-600">
                  {t.reserveSuccess}
                </p>
              </div>

              {/* Display Booked Owner Name (Requirement 10) */}
              <div className="bg-slate-50 border-2 border-emerald-200 rounded-2xl p-4 text-left space-y-2 text-xs">
                <div className="flex justify-between items-center border-b border-navy-200 pb-2">
                  <span className="text-navy-500 font-bold">Booking Ref ID:</span>
                  <span className="font-mono font-black text-sm text-emerald-700 bg-white px-2 py-0.5 rounded border border-emerald-300">
                    {bookingResult.referenceCode}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-navy-500 font-bold">{t.ownerNameLabel}:</span>
                  <strong className="text-navy-950 text-sm font-display font-black">{bookingResult.ownerName}</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-navy-500 font-bold">Plot Number:</span>
                  <strong className="text-navy-950">Plot {plot.plot_number} ({plot.area_sqyd} sq.yd)</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-navy-500 font-bold">Total Consideration:</span>
                  <strong className="text-emerald-700 text-sm font-bold">₹{plot.total_price.toLocaleString('en-IN')}</strong>
                </div>
              </div>

              <button
                onClick={onClose}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 px-6 rounded-xl transition shadow-md text-xs sm:text-sm"
              >
                {currentLang === 'te' ? 'లేఅవుట్ ప్లాన్‌లో నా పేరు చూడండి' : 'View My Name on Layout Map'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              {/* Plot Selected Bar */}
              <div className="bg-slate-50 border border-navy-200 rounded-2xl p-4 flex justify-between items-center text-xs">
                <div>
                  <span className="text-navy-500 block font-medium">Selected Plot</span>
                  <strong className="text-navy-950 font-display text-base">Plot {plot.plot_number}</strong>
                  <span className="text-navy-500 text-[11px] block">{plot.area_sqyd} sq.yd • {plot.facing}</span>
                </div>
                <div className="text-right">
                  <span className="text-navy-500 block font-medium">Total Price</span>
                  <strong className="text-emerald-700 font-display text-base">₹{plot.total_price.toLocaleString('en-IN')}</strong>
                  <span className="text-navy-500 text-[11px] block">₹{plot.price_per_sqyd}/sq.yd</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                  {currentLang === 'te' ? 'మీ పూర్తి పేరు (లేఅవుట్ మ్యాప్‌పై కనిపిస్తుంది) *' : 'Your Full Name (Appears directly on the Plot Layout) *'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-navy-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. K. Satyanarayana"
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl pl-9 pr-3 py-2.5 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                  {t.phoneNumber} *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-navy-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="10-digit mobile"
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl pl-9 pr-3 py-2.5 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                  />
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-[11px] text-emerald-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Anti-Duplicate Security:</strong> Plot {plot.plot_number} will be instantly locked under your name to prevent any other person from taking it.
                </span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm disabled:opacity-50"
              >
                {loading ? 'Validating Availability...' : (currentLang === 'te' ? 'ప్లాట్ రిజర్వ్ చేయండి' : 'Confirm Plot Reservation')}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
