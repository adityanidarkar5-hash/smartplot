import React, { useState } from 'react';
import { 
  MapPin, 
  ArrowLeft, 
  Calendar, 
  FileText, 
  ShieldCheck, 
  CheckCircle2, 
  Rotate3d, 
  Compass, 
  ExternalLink,
  PhoneCall,
  Video,
  Image as ImageIcon,
  MessageCircle,
  Play,
  Navigation
} from 'lucide-react';
import { Venture, Plot, Language } from '../types';
import { InteractivePlotMap } from './InteractivePlotMap';
import { ThreeDPlotView } from './ThreeDPlotView';
import { t } from '../i18n';
import { getVentureGoogleMapsUrl, getGoogleMapsEmbedUrl, openInGoogleMaps } from '../utils/googleMaps';

interface VentureDetailViewProps {
  venture: Venture;
  plots: Plot[];
  onBack: () => void;
  selectedPlot: Plot | null;
  onSelectPlot: (plot: Plot) => void;
  onBookSiteVisit: () => void;
  onOpenBrochure: (venture: Venture) => void;
  lang?: Language;
}

export const VentureDetailView: React.FC<VentureDetailViewProps> = ({
  venture,
  plots,
  onBack,
  selectedPlot,
  onSelectPlot,
  onBookSiteVisit,
  onOpenBrochure,
  lang = 'en',
}) => {
  const [viewMode, setViewMode] = useState<'2d' | '3d' | 'blueprint'>('2d');
  const [activeTab, setActiveTab] = useState<'layout' | 'amenities' | 'location' | 'media'>('layout');
  const [mediaSubTab, setMediaSubTab] = useState<'photos' | 'videos'>('photos');

  const counts = venture.counts || {
    total: plots.length,
    available: plots.filter(p => p.status === 'available').length,
    pending: plots.filter(p => p.status === 'pending').length,
    booked: plots.filter(p => p.status === 'booked' || p.status === 'sold').length,
    blocked: plots.filter(p => p.status === 'blocked').length
  };

  const displayName = (lang === 'te' && venture.tagline_te) ? venture.name : venture.name;
  const displayTagline = (lang === 'te' && venture.tagline_te) ? venture.tagline_te : venture.tagline;
  const displayDesc = (lang === 'te' && venture.description_te) ? venture.description_te : venture.description;
  const displayLocation = (lang === 'te' && venture.location_te) ? venture.location_te : venture.location;

  const handleWhatsApp = () => {
    const text = `Namaste B.N Ventures! I am interested in ${venture.name} located at ${venture.location}. Please share complete layout pricing and details.`;
    window.open(`https://wa.me/919848012345?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      
      {/* Top Breadcrumb & Hero Header */}
      <div className="bg-navy-950 text-white border-b border-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-6">
          
          {/* Back button */}
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-sm font-bold text-slate-300 hover:text-white transition group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            {lang === 'te' ? '← అన్ని వెంచర్లు చూడండి' : '← Back to All Ventures'}
          </button>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="flex flex-wrap items-center gap-2">
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold px-3 py-1 rounded-full">
                  {lang === 'te' && venture.status_te ? venture.status_te : venture.status}
                </span>
                <span className="text-slate-300 text-xs sm:text-sm flex items-center gap-1 font-mono bg-navy-900 px-3 py-1 rounded-full border border-navy-700">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> RERA: {venture.rera_number}
                </span>
                <span className="text-amber-300 text-xs font-bold bg-amber-950/40 border border-amber-800/40 px-3 py-1 rounded-full">
                  ★ B.N Ventures Verified
                </span>
              </div>

              <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
                {displayName}
              </h1>

              <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
                {displayTagline}
              </p>

              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-2 text-sm text-slate-300 font-medium">
                  <MapPin className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>{displayLocation}, {venture.city}, {venture.state}</span>
                </div>
                <button
                  type="button"
                  onClick={() => openInGoogleMaps(venture)}
                  className="bg-amber-400 hover:bg-amber-500 text-navy-950 font-black text-xs px-3 py-1 rounded-xl transition flex items-center gap-1.5 shadow-md border border-amber-300"
                  title="Open exact venture coordinates in Google Maps"
                >
                  <Navigation className="w-3.5 h-3.5 fill-navy-950" />
                  <span>{lang === 'te' ? 'గూగుల్ మ్యాప్స్' : 'Google Maps'}</span>
                  <ExternalLink className="w-3 h-3 opacity-80" />
                </button>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={onBookSiteVisit}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg shadow-emerald-600/30 transition flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" /> {t(lang, 'bookSiteVisit')}
              </button>

              <button
                onClick={handleWhatsApp}
                className="bg-emerald-700/80 hover:bg-emerald-600 text-white border border-emerald-500/50 font-bold text-sm px-5 py-3.5 rounded-xl transition flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-300" /> {t(lang, 'instantWhatsAppDesk')}
              </button>

              <button
                onClick={() => onOpenBrochure(venture)}
                className="bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-sm px-5 py-3.5 rounded-xl transition flex items-center gap-2"
              >
                <FileText className="w-4 h-4 text-emerald-400" /> {t(lang, 'digitalBrochure')}
              </button>
            </div>
          </div>

          {/* Quick Metrics Ribbon */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-4 border-t border-navy-800 text-xs sm:text-sm">
            <div className="bg-navy-900/80 p-3 rounded-xl border border-navy-800">
              <span className="text-slate-400 block font-medium">{t(lang, 'totalPlots')}</span>
              <strong className="text-white text-xl font-display">{counts.total} Plots</strong>
            </div>

            {/* GREEN: Available */}
            <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/40">
              <span className="text-emerald-400 block font-bold">{t(lang, 'available')} (Green)</span>
              <strong className="text-emerald-300 text-xl font-display">{counts.available} Units</strong>
            </div>

            {/* YELLOW: Pending */}
            <div className="bg-amber-950/40 p-3 rounded-xl border border-amber-800/40">
              <span className="text-amber-400 block font-bold">{t(lang, 'pending')} (Yellow)</span>
              <strong className="text-amber-300 text-xl font-display">{counts.pending} Units</strong>
            </div>

            {/* RED: Booked / Sold */}
            <div className="bg-red-950/40 p-3 rounded-xl border border-red-800/40">
              <span className="text-red-400 block font-bold">{t(lang, 'booked')} / Sold (Red)</span>
              <strong className="text-red-300 text-xl font-display">{counts.booked} Units</strong>
            </div>

            {/* BLACK: Blocked */}
            <div className="bg-slate-900 p-3 rounded-xl border border-slate-700">
              <span className="text-slate-300 block font-bold">{t(lang, 'blocked')} (Black)</span>
              <strong className="text-slate-200 text-xl font-display">{counts.blocked} Units</strong>
            </div>
          </div>

        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-8">
        
        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-navy-200 pb-2 overflow-x-auto gap-4">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('layout')}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition flex items-center gap-2 ${
                activeTab === 'layout' 
                  ? 'bg-emerald-600 text-white shadow-md' 
                  : 'bg-white text-navy-800 hover:bg-slate-100 border border-navy-200'
              }`}
            >
              <Compass className="w-4 h-4" /> {t(lang, 'interactiveLayout')}
            </button>

            <button
              onClick={() => setActiveTab('amenities')}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition ${
                activeTab === 'amenities' 
                  ? 'bg-emerald-600 text-white shadow-md' 
                  : 'bg-white text-navy-800 hover:bg-slate-100 border border-navy-200'
              }`}
            >
              {lang === 'te' ? 'సౌకర్యాలు & రోడ్లు' : 'Amenities & Roads'}
            </button>

            <button
              onClick={() => setActiveTab('location')}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition ${
                activeTab === 'location' 
                  ? 'bg-emerald-600 text-white shadow-md' 
                  : 'bg-white text-navy-800 hover:bg-slate-100 border border-navy-200'
              }`}
            >
              {lang === 'te' ? 'స్థలం & మ్యాప్' : 'Location & Map'}
            </button>

            <button
              onClick={() => setActiveTab('media')}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition flex items-center gap-1.5 ${
                activeTab === 'media' 
                  ? 'bg-emerald-600 text-white shadow-md' 
                  : 'bg-white text-navy-800 hover:bg-slate-100 border border-navy-200'
              }`}
            >
              <Video className="w-4 h-4 text-emerald-500" />
              {t(lang, 'venturePhotosVideos')}
            </button>
          </div>

          {/* 2D vs 3D vs Blueprint Switcher (Only visible in Layout tab) */}
          {activeTab === 'layout' && (
            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-navy-200 shadow-sm shrink-0 flex-wrap">
              <button
                onClick={() => setViewMode('2d')}
                className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${
                  viewMode === '2d' 
                    ? 'bg-navy-950 text-white shadow' 
                    : 'text-navy-700 hover:text-navy-950'
                }`}
              >
                <Compass className="w-4 h-4 text-emerald-400" /> 2D SVG Map
              </button>

              <button
                onClick={() => setViewMode('3d')}
                className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${
                  viewMode === '3d' 
                    ? 'bg-navy-950 text-white shadow' 
                    : 'text-navy-700 hover:text-navy-950'
                }`}
              >
                <Rotate3d className="w-4 h-4 text-emerald-400" /> 3D View
              </button>

              {venture.layout_image_url && (
                <button
                  onClick={() => setViewMode('blueprint')}
                  className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${
                    viewMode === 'blueprint' 
                      ? 'bg-navy-950 text-white shadow' 
                      : 'text-navy-700 hover:text-navy-950'
                  }`}
                >
                  <FileText className="w-4 h-4 text-blue-500" />
                  {lang === 'te' ? 'అసలు బ్లూప్రింట్' : 'Original Blueprint'}
                </button>
              )}
            </div>
          )}
        </div>

        {/* Tab 1: Layout Viewer */}
        {activeTab === 'layout' && (
          <div className="space-y-6">
            <div className="space-y-1">
              <h3 className="font-display font-extrabold text-2xl sm:text-3xl text-navy-950">
                {t(lang, 'interactiveLayout')} — {venture.name}
              </h3>
              <p className="text-sm text-navy-600 font-medium">
                {lang === 'te' 
                  ? 'ఏ ప్లాట్ అయినా క్లిక్ చేసి దాని విస్తీర్ణం, ఫేసింగ్, రోడ్డు వెడల్పు, ధర మరియు బుకింగ్ వివరాలు చూడండి. బుక్ అయిన ప్లాట్లపై యజమాని పేరు కనిపిస్తుంది.'
                  : 'Click any plot rectangle to reveal dimensions, facing, road width, total price, and booking options. Booked plots display owner names directly.'}
              </p>
            </div>

            {/* Interactive Layout View (2D, 3D, or Blueprint) */}
            {viewMode === '2d' ? (
              <InteractivePlotMap
                plots={plots}
                selectedPlot={selectedPlot}
                onSelectPlot={onSelectPlot}
                ventureName={venture.name}
                lang={lang}
                layoutImageUrl={venture.layout_image_url}
              />
            ) : viewMode === '3d' ? (
              <ThreeDPlotView
                plots={plots}
                selectedPlot={selectedPlot}
                onSelectPlot={onSelectPlot}
                ventureName={venture.name}
                lang={lang}
              />
            ) : (
              <div className="bg-white rounded-2xl border-2 border-navy-100 shadow-xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-navy-50/80 p-4 rounded-xl border border-navy-100">
                  <div className="space-y-0.5">
                    <h4 className="font-bold text-navy-950 flex items-center gap-2 text-base">
                      <ImageIcon className="w-4 h-4 text-navy-700" />
                      {lang === 'te' ? 'అధికారిక ఆమోదిత బ్లూప్రింట్ పత్రం / లేఅవుట్ ఫోటో' : 'Official Approved Blueprint Document / Layout Survey'}
                    </h4>
                    <p className="text-xs text-navy-600">
                      {lang === 'te' 
                        ? 'ఈ పత్రం రియల్ ఎస్టేట్ సంస్థ లేదా ప్రభుత్వ ఆమోదిత శాఖ ద్వారా సమర్పించబడిన అధికారిక బ్లూప్రింట్ పత్రం.'
                        : 'Official original blueprint and survey map uploaded for this venture.'}
                    </p>
                  </div>
                  {venture.layout_image_url && (
                    <a
                      href={venture.layout_image_url}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2 bg-navy-900 hover:bg-navy-950 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow"
                    >
                      <span>{lang === 'te' ? 'పూర్తి పరిమాణంలో చూడండి' : 'Open Full Image'}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>

                <div className="w-full min-h-[460px] max-h-[750px] bg-slate-900 rounded-xl overflow-auto border border-slate-750 flex items-center justify-center p-4">
                  {venture.layout_image_url ? (
                    <img
                      src={venture.layout_image_url}
                      alt={`${venture.name} Blueprint`}
                      className="max-w-full max-h-[700px] object-contain rounded-lg shadow-2xl"
                    />
                  ) : (
                    <div className="text-center text-slate-400 py-12">
                      <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>{lang === 'te' ? 'బ్లూప్రింట్ పత్రం అందుబాటులో లేదు' : 'No original blueprint uploaded yet'}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Amenities & Roads */}
        {activeTab === 'amenities' && (
          <div className="bg-white rounded-3xl p-8 border border-navy-100 shadow-sm space-y-6">
            <h3 className="font-display font-bold text-2xl text-navy-950">
              {lang === 'te' ? 'వెంచర్ సౌకర్యాలు & డెవలప్‌మెంట్' : 'Project Amenities & Infrastructure'}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(venture.amenities || []).map((amenity, index) => (
                <div key={index} className="flex items-start gap-4 p-5 bg-slate-50 rounded-2xl border border-navy-100">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-bold text-navy-950 text-base">{amenity}</h5>
                    <p className="text-xs text-navy-600 mt-1">
                      {lang === 'te' 
                        ? 'DTCP / HMDA మరియు RERA నిబంధనల ప్రకారం నాణ్యమైన నిర్మాణం.' 
                        : 'Fully approved infrastructure built strictly to DTCP/HMDA/RERA standards.'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Location & Map */}
        {activeTab === 'location' && (
          <div className="bg-white rounded-3xl p-8 border border-navy-100 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
              <div>
                <h3 className="font-display font-bold text-2xl text-navy-950">
                  {lang === 'te' ? 'లొకేషన్ ప్రత్యేకతలు' : 'Location Advantage'}
                </h3>
                <p className="text-sm text-navy-600 mt-1">{displayLocation}, {venture.city}, {venture.state}</p>
              </div>

              <a
                href={getVentureGoogleMapsUrl(venture)}
                target="_blank"
                rel="noreferrer"
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm px-5 py-2.5 rounded-xl transition flex items-center gap-2 w-fit shadow-md border border-emerald-400/30"
              >
                <Navigation className="w-4 h-4 text-amber-300 fill-amber-300" />
                <span>{lang === 'te' ? 'గూగుల్ మ్యాప్స్‌లో తెరవండి' : 'Open in Google Maps'}</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            <div className="rounded-2xl overflow-hidden h-[450px] border border-navy-200 shadow-inner relative bg-slate-100">
              <iframe
                title={`Venture Location Map - ${venture.name}`}
                src={getGoogleMapsEmbedUrl(venture)}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                allowFullScreen
              />
            </div>
          </div>
        )}

        {/* Tab 4: Photos and Videos (Requirement 8) */}
        {activeTab === 'media' && (
          <div className="bg-white rounded-3xl p-8 border border-navy-100 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-100 pb-4">
              <div>
                <h3 className="font-display font-bold text-2xl text-navy-950">
                  {t(lang, 'venturePhotosVideos')}
                </h3>
                <p className="text-xs text-navy-500 mt-1">
                  {lang === 'te' 
                    ? 'బి.ఎన్ వెంచర్స్ సైట్ ఫోటోలు మరియు డ్రోన్ వీడియోలు' 
                    : 'Authentic on-site development photos and drone tour walkthroughs'}
                </p>
              </div>

              {/* Sub-tabs for Photos vs Videos */}
              <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
                <button
                  onClick={() => setMediaSubTab('photos')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    mediaSubTab === 'photos'
                      ? 'bg-white text-navy-900 shadow-sm'
                      : 'text-navy-600 hover:text-navy-900'
                  }`}
                >
                  <ImageIcon className="w-4 h-4 text-emerald-600" /> {lang === 'te' ? 'ఫోటోలు' : 'Photos'} ({venture.gallery?.length || 1})
                </button>
                <button
                  onClick={() => setMediaSubTab('videos')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    mediaSubTab === 'videos'
                      ? 'bg-white text-navy-900 shadow-sm'
                      : 'text-navy-600 hover:text-navy-900'
                  }`}
                >
                  <Video className="w-4 h-4 text-emerald-600" /> {lang === 'te' ? 'వీడియోలు' : 'Videos'} ({venture.videos?.length || 0})
                </button>
              </div>
            </div>

            {mediaSubTab === 'photos' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {(venture.gallery || [venture.hero_image]).map((img, i) => (
                  <div key={i} className="rounded-2xl overflow-hidden shadow-md h-64 group relative border border-navy-100 bg-slate-100">
                    <img
                      src={img}
                      alt={`${venture.name} photo ${i + 1}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity"></div>
                    <div className="absolute bottom-3 left-4 right-4 text-white text-xs font-semibold">
                      {venture.name} — Site View #{i + 1}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {venture.videos && venture.videos.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {venture.videos.map((vid, idx) => (
                      <div key={idx} className="bg-slate-900 rounded-2xl overflow-hidden border border-navy-800 shadow-lg flex flex-col">
                        <div className="aspect-video w-full bg-black relative flex items-center justify-center">
                          {vid.url.includes('youtube.com') || vid.url.includes('youtu.be') ? (
                            <iframe
                              src={vid.url}
                              title={vid.title}
                              className="w-full h-full"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            />
                          ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-slate-300 bg-navy-950">
                              <Play className="w-12 h-12 text-emerald-400 mb-3" />
                              <h4 className="text-white font-bold text-base">{vid.title}</h4>
                              <p className="text-xs text-slate-400 mt-1 mb-4 font-mono">{vid.url}</p>
                              <a
                                href={vid.url}
                                target="_blank"
                                rel="noreferrer"
                                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition flex items-center gap-2"
                              >
                                {lang === 'te' ? 'వీడియో చూడండి' : 'Watch Drone Tour'} <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          )}
                        </div>
                        <div className="p-4 bg-navy-900 border-t border-navy-800">
                          <h4 className="text-white font-bold text-sm">{vid.title}</h4>
                          <span className="text-emerald-400 text-xs font-medium">B.N Ventures Official Tour</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                    <Video className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                    <h4 className="text-navy-900 font-bold text-base">
                      {lang === 'te' ? 'త్వరలో డ్రోన్ వీడియోలు అందుబాటులో ఉంటాయి' : 'Drone Videos Coming Soon'}
                    </h4>
                    <p className="text-xs text-navy-500 mt-1">
                      {lang === 'te' 
                        ? 'అడ్మిన్ వీడియోలను అప్‌లోడ్ చేసిన వెంటనే ఇక్కడ కనిపిస్తాయి.' 
                        : 'Official videos uploaded by the administrator will be visible here.'}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
