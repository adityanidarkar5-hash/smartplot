import React from 'react';
import { X, Printer, Building2, ShieldCheck, MapPin, CheckCircle2, Phone, Award } from 'lucide-react';
import { Venture, Language } from '../types';

interface DigitalBrochureModalProps {
  isOpen: boolean;
  onClose: () => void;
  venture: Venture | null;
  lang?: Language;
}

export const DigitalBrochureModal: React.FC<DigitalBrochureModalProps> = ({
  isOpen,
  onClose,
  venture,
  lang = 'en',
}) => {
  if (!isOpen || !venture) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-navy-100 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Top Controls Bar (Hidden during print) */}
        <div className="print:hidden bg-slate-900 text-white p-4 flex justify-between items-center border-b border-navy-800">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <ShieldCheck className="w-4 h-4" /> B.N Ventures — Official Property Brochure
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 px-4 rounded-xl flex items-center gap-1.5 transition shadow"
            >
              <Printer className="w-4 h-4" /> {lang === 'te' ? 'ప్రింట్ / పిడిఎఫ్ డౌన్‌లోడ్' : 'Print / Save as PDF'}
            </button>
            <button
              onClick={onClose}
              className="text-white/70 hover:text-white p-1.5 rounded-full hover:bg-white/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Brochure Document */}
        <div className="p-8 space-y-6 text-navy-900 bg-white">
          
          {/* Cover Header */}
          <div className="border-b-2 border-emerald-600 pb-6 flex justify-between items-end">
            <div>
              <div className="flex items-center gap-2.5 mb-2">
                <div className="w-10 h-10 rounded-xl bg-navy-950 flex items-center justify-center text-emerald-400 font-black text-xl border border-emerald-500/30">
                  BN
                </div>
                <div>
                  <span className="font-display font-black text-2xl tracking-tight text-navy-950 block">
                    B.N <span className="text-emerald-600">Ventures</span>
                  </span>
                  <span className="text-[10px] text-amber-700 font-bold uppercase tracking-wider flex items-center gap-1">
                    <Award className="w-3 h-3 text-amber-600" /> 10 Years Trust • 5 Landmark Ventures
                  </span>
                </div>
              </div>
              <h2 className="font-display font-extrabold text-3xl text-navy-950">{venture.name}</h2>
              <p className="text-sm text-navy-600 flex items-center gap-1 mt-1 font-medium">
                <MapPin className="w-4 h-4 text-emerald-600" /> {venture.location}, {venture.city}, {venture.state}
              </p>
            </div>

            <div className="text-right">
              <span className="inline-block bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-300">
                {venture.status}
              </span>
              <p className="text-[11px] font-mono text-navy-500 mt-1 font-semibold">
                RERA: {venture.rera_number}
              </p>
            </div>
          </div>

          {/* Hero Banner inside Brochure */}
          <div className="relative rounded-2xl overflow-hidden h-56 shadow-md border border-navy-100">
            <img
              src={venture.hero_image}
              alt={venture.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent"></div>
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <p className="text-xs uppercase tracking-widest text-emerald-300 font-bold">100% CLEAR TITLE • DTCP / HMDA APPROVED</p>
              <h3 className="font-display text-xl font-bold">{venture.tagline}</h3>
            </div>
          </div>

          {/* Overview & Key Highlights */}
          <div className="space-y-2">
            <h4 className="font-display font-bold text-lg text-navy-950 border-b border-navy-100 pb-1">
              {lang === 'te' ? 'వెంచర్ వివరాలు' : 'Project Overview'}
            </h4>
            <p className="text-xs sm:text-sm text-navy-700 leading-relaxed font-medium">
              {lang === 'te' && venture.description_te ? venture.description_te : venture.description}
            </p>
          </div>

          {/* Pricing & Units Schedule */}
          <div className="grid grid-cols-3 gap-3 text-center bg-slate-50 border border-navy-200 rounded-2xl p-4">
            <div>
              <span className="text-[11px] text-navy-500 uppercase font-semibold block">{lang === 'te' ? 'మొత్తం ప్లాట్లు' : 'Total Planned Plots'}</span>
              <strong className="font-display text-xl text-navy-950">{venture.total_plots || 36} Units</strong>
            </div>
            <div>
              <span className="text-[11px] text-navy-500 uppercase font-semibold block">{lang === 'te' ? 'గజం ధర' : 'Plot Price Range'}</span>
              <strong className="font-display text-xl text-emerald-700">
                ₹{venture.price_per_sqyd_min.toLocaleString('en-IN')} - ₹{venture.price_per_sqyd_max.toLocaleString('en-IN')}
                <span className="text-xs font-normal text-navy-500"> / sq.yd</span>
              </strong>
            </div>
            <div>
              <span className="text-[11px] text-navy-500 uppercase font-semibold block">{lang === 'te' ? 'స్థితి' : 'Launch Status'}</span>
              <strong className="font-display text-xl text-navy-950">{venture.status}</strong>
            </div>
          </div>

          {/* Infrastructure & Amenities List */}
          <div className="space-y-3">
            <h4 className="font-display font-bold text-lg text-navy-950 border-b border-navy-100 pb-1">
              {lang === 'te' ? 'సౌకర్యాలు & ప్రాజెక్ట్ విశేషాలు' : 'Master Plan Infrastructure & Features'}
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {(venture.amenities || []).map((amenity, i) => (
                <div key={i} className="flex items-center gap-2 text-navy-800 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer & Contact in Brochure */}
          <div className="pt-4 border-t border-navy-200 flex flex-wrap justify-between items-center gap-4 text-xs text-navy-600">
            <div>
              <p className="font-bold text-navy-950 text-sm">B.N Ventures Property Developers</p>
              <p>Regional HQ: Nirmal District (504106) & Hyderabad, Telangana India</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-emerald-700 text-sm flex items-center justify-end gap-1">
                <Phone className="w-3.5 h-3.5" /> Direct: +91 98480 12345
              </p>
              <p>Instant WhatsApp Desk: +91 98480 12345 • contact@bnventures.in</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
