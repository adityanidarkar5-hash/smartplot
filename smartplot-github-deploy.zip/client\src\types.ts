export type Language = 'en' | 'te' | 'hi';

export interface VentureVideo {
  title: string;
  url: string;
}

export interface Venture {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  tagline_te?: string;
  location: string;
  location_te?: string;
  district?: string;
  district_te?: string;
  pincode?: string;
  city: string;
  city_te?: string;
  state: string;
  description: string;
  description_te?: string;
  price_per_sqyd_min: number;
  price_per_sqyd_max: number;
  total_plots: number;
  status: string;
  status_te?: string;
  hero_image: string;
  gallery: string[];
  videos: VentureVideo[];
  amenities: string[];
  launch_date: string;
  rera_number: string;
  map_embed_url: string;
  brochure_filename: string;
  layout_image_url?: string;
  counts?: {
    total: number;
    available: number;
    pending: number;
    booked: number;
    blocked: number;
  };
}

export type PlotStatus = 'available' | 'pending' | 'booked' | 'sold' | 'blocked';

export interface Plot {
  id: number;
  venture_id: number;
  venture_name?: string;
  venture_slug?: string;
  plot_number: string;
  area_sqyd: number;
  dimension_length: number;
  dimension_width: number;
  facing: 'East' | 'West' | 'North' | 'South' | 'North-East' | 'South-East' | 'North-West' | 'South-West';
  price_per_sqyd: number;
  total_price: number;
  is_corner: number; // 0 or 1
  road_width_ft: number;
  status: PlotStatus;
  block_name: string;
  pos_x: number;
  pos_y: number;
  width: number;
  height: number;
  owner_name?: string | null; // Requirement 10
  created_at?: string;
  updated_at?: string;
}

export interface Appointment {
  id: number;
  reference_code: string;
  venture_id: number;
  venture_name?: string;
  plot_id?: number | null;
  plot_number?: string | null;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  preferred_date: string;
  time_slot: string;
  message?: string;
  status: 'pending' | 'confirmed' | 'rescheduled' | 'completed' | 'cancelled';
  admin_notes?: string;
  created_at: string;
}

export interface Booking {
  id: number;
  reference_code: string;
  plot_id: number;
  venture_id: number;
  venture_name?: string;
  plot_number: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  amount_paid: number;
  status: 'pending' | 'approved' | 'rejected';
  booking_date: string;
  created_at: string;
}

export interface Enquiry {
  id: number;
  venture_id?: number;
  plot_number?: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
}

export interface AdminMetrics {
  venturesCount: number;
  plots: {
    total: number;
    available: number;
    pending: number;
    booked: number;
    sold: number;
    blocked: number;
  };
  appointments: {
    total: number;
    pending: number;
    confirmed: number;
  };
  bookings: {
    total: number;
    pending: number;
    approved: number;
  };
  enquiriesCount: number;
}
