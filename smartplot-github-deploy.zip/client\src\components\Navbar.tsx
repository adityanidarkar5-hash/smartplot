import React, { useState, useRef } from 'react';
import { 
  Building2, 
  MapPin, 
  Phone, 
  Calendar, 
  Globe, 
  Menu, 
  X, 
  Layers, 
  Compass, 
  Home, 
  Info, 
  PhoneCall,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface NavbarProps {
  activePage: string;
  setActivePage: (page: string) => void;
  onOpenSiteVisit: () => void;
  currentLang: Language;
  onSelectLang: (lang: Language) => void;
  selectedLocation: string;
  onOpenLangModal: () => void;
  onOpenSecurityTerms?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  onOpenSiteVisit,
  currentLang,
  onSelectLang,
  selectedLocation,
  onOpenLangModal,
  onOpenSecurityTerms,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[currentLang];

  // Secret Owner Portal Access: 3 rapid clicks on logo unlocks owner security vault
  const [logoClicks, setLogoClicks] = useState(0);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleLogoClick = () => {
    setLogoClicks(prev => {
      const next = prev + 1;
      if (next >= 3) {
        handleNavClick('admin');
        return 0;
      }
      return next;
    });

    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    clickTimerRef.current = setTimeout(() => {
      setLogoClicks(0);
    }, 1200);

    if (logoClicks === 0) {
      handleNavClick('home');
    }
  };

  const navLinks = [
    { id: 'home', label: t.navHome, icon: Home },
    { id: 'ventures', label: t.navVentures, icon: Layers },
    { id: 'explore-plots', label: t.navPlots, icon: Compass },
    { id: 'about', label: t.navAbout, icon: Info },
    { id: 'contact', label: t.navContact, icon: PhoneCall },
  ];

  const handleNavClick = (pageId: string) => {
    setActivePage(pageId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-navy-100 shadow-sm">
      
      {/* Top Utility Bar */}
      <div className="bg-navy-950 text-slate-300 text-xs py-2 px-4 sm:px-8 border-b border-navy-800">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          
          {/* Trust Banner & 10 Years Experience */}
          <div className="flex items-center gap-4 flex-wrap">
            <span className="flex items-center gap-1.5 text-emerald-400 font-extrabold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              {currentLang === 'te' 
                ? '10 సంవత్సరాల అనుభవం • 5 విజయవంతమైన వెంచర్లు' 
                : '10 Years of Proven Experience • 5 Delivered Ventures'}
            </span>
            <span className="hidden md:inline-block text-slate-600">•</span>
            <span className="hidden md:flex items-center gap-1 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <strong className="text-emerald-400">Nirmal Dist (504106)</strong> • Hyderabad, Telangana India
            </span>
          </div>

          {/* Language Switcher & Direct Calling Shortcuts */}
          <div className="flex items-center gap-3 sm:gap-5 ml-auto">
            
            {/* Quick Language Toggle Pill */}
            <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-0.5">
              <button
                onClick={() => onSelectLang('te')}
                className={`px-2 py-0.5 rounded text-[11px] font-black transition ${
                  currentLang === 'te' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                తెలుగు
              </button>
              <button
                onClick={() => onSelectLang('en')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition ${
                  currentLang === 'en' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => onSelectLang('hi')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition ${
                  currentLang === 'hi' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                हिन्दी
              </button>
            </div>

            {/* OWASP & Security Terms Button */}
            {onOpenSecurityTerms && (
              <button
                onClick={onOpenSecurityTerms}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 hover:text-white hover:bg-emerald-900 transition text-[11px] font-bold cursor-pointer"
                title="View Legal Protections & OWASP Top 10 Security Shield"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{currentLang === 'te' ? 'భద్రతా నిబంధనలు' : 'Security Terms'}</span>
                <span className="text-[9px] bg-emerald-600 text-white px-1.5 py-0.2 rounded font-black">
                  OWASP
                </span>
              </button>
            )}

            {/* Direct Owner Phone Calling */}
            <a 
              href="tel:+919876543210"
              className="text-white hover:text-emerald-400 transition flex items-center gap-1 font-bold"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">+91 98765 43210</span>
            </a>

          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* B.N Ventures Logo (Triple-tap secretly triggers Owner Vault) */}
          <div 
            onClick={handleLogoClick}
            className="flex items-center gap-3 cursor-pointer group select-none"
            title="B.N Ventures"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <span className="font-display font-black text-2xl sm:text-3xl tracking-tight text-navy-950 flex items-center gap-1.5">
                B.N <span className="text-emerald-600">Ventures</span>
              </span>
              <p className="text-[11px] text-emerald-800 font-extrabold tracking-wide">
                10 Years Real Estate Experience
              </p>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-bold transition-all ${
                    isActive 
                      ? 'text-emerald-800 bg-emerald-50 shadow-sm border border-emerald-200' 
                      : 'text-navy-800 hover:text-emerald-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-navy-400'}`} />
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            
            {/* Location Selector Pill (Shows Location ON status) */}
            <button
              onClick={onOpenLangModal}
              className="bg-slate-100 hover:bg-emerald-50 text-navy-800 hover:text-emerald-800 border border-navy-200 hover:border-emerald-300 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
              title="Location ON - Click to switch district or explore Google Maps"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>{selectedLocation || t.allLocations}</span>
              <ChevronDown className="w-3 h-3 text-navy-400" />
            </button>

            {/* Instant WhatsApp Desk (Requirement 6) */}
            <a
              href="https://wa.me/919876543210?text=Hello%20B.N%20Ventures,%20I%20want%20to%20know%20more%20about%20plots"
              target="_blank"
              rel="noreferrer"
              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold text-xs px-3.5 py-2.5 rounded-xl transition flex items-center gap-1.5"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
              {t.whatsappDesk}
            </a>

            {/* Book a Site Visit Button */}
            <button
              onClick={onOpenSiteVisit}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md transition flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              {t.bookSiteVisit}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={onOpenLangModal}
              className="p-2 rounded-xl border border-navy-200 text-navy-800 bg-slate-50 text-xs font-bold flex items-center gap-1"
            >
              <Globe className="w-4 h-4 text-emerald-600" />
              <span>{currentLang.toUpperCase()}</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl text-navy-900 bg-slate-100 transition"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b-2 border-navy-200 px-4 pt-3 pb-6 space-y-3 shadow-2xl animate-in slide-in-from-top-4 duration-200">
          <div className="space-y-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-base font-bold ${
                    isActive 
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                      : 'text-navy-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-5 h-5 text-emerald-600" />
                  {link.label}
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-navy-100 space-y-2">
            <a
              href="https://wa.me/919876543210?text=Hello%20B.N%20Ventures,%20I%20want%20to%20know%20more%20about%20plots"
              target="_blank"
              rel="noreferrer"
              className="w-full bg-emerald-50 text-emerald-900 border border-emerald-300 font-extrabold py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-sm shadow-sm"
            >
              <PhoneCall className="w-4 h-4 text-emerald-600" />
              {t.whatsappDesk}
            </a>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSiteVisit();
              }}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-sm shadow-md"
            >
              <Calendar className="w-4 h-4" />
              {t.bookSiteVisit}
            </button>
          </div>
        </div>
      )}

    </header>
  );
};
