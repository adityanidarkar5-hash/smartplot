import { Language } from './types';

export const translations: Record<Language, Record<string, string>> = {
  te: {
    // Branding & Header
    brandName: "B.N వెంచర్స్",
    brandTagline: "10 సంవత్సరాల నిజాయితీ గల రియల్ ఎస్టేట్ అనుభవం • 5 విజయవంతమైన లేఅవుట్‌లు",
    selectLanguage: "భాషను మార్చండి",
    selectLocation: "ప్రాంతం (లొకేషన్)",
    allLocations: "అన్ని ప్రాంతాలు",
    changeLocation: "లొకేషన్ మార్చుకోండి",
    adminPortal: "అడ్మిన్ లాగిన్",
    directCall: "యజమానికి ఫోన్ చేయండి",
    whatsappDesk: "వాట్సాప్ ద్వారా మాట్లాడండి",
    bookSiteVisit: "సైట్ చూడటానికి రండి (ఉచిత ప్రయాణం)",
    
    // Welcome / Entry Modal
    welcomeTitle: "B.N వెంచర్స్‌కు స్వాగతం",
    welcomeSubtitle: "దయచేసి మీ భాషను మరియు లొకేషన్ ఎంచుకోండి",
    step1Language: "1. మీ భాషను ఎంచుకోండి",
    step2Location: "2. మీరు ప్లాట్లు చూడాలనుకుంటున్న ప్రాంతం (లొకేషన్) ఎంచుకోండి",
    continueBtn: "వెంచర్లు & ప్లాట్లు చూడండి",

    // Navigation
    navHome: "హోమ్",
    navVentures: "మా వెంచర్లు (5)",
    navPlots: "ప్లాట్ల లేఅవుట్",
    navAbout: "మా గురించి (10 ఏళ్ల అనుభవం)",
    navContact: "సంప్రదించండి",

    // Founder Story & Trust (Requirement 2)
    ownerExpTitle: "10 సంవత్సరాల అనుభవం — చిన్నగా మొదలై 5 ప్రతిష్టాత్మక వెంచర్లు",
    ownerExpDesc: "B.N వెంచర్స్ యజమాని గత 10 సంవత్సరాలుగా రియల్ ఎస్టేట్ రంగంలో నమ్మకమైన సేవలు అందిస్తున్నారు. అతి సాధారణంగా, చిన్నగా ప్రారంభించి నిజాయితీతో కూడిన నాణ్యతతో ఇప్పటివరకు 5 పెద్ద వెంచర్లను విజయవంతంగా అభివృద్ధి చేసి వందలాది కుటుంబాలకు రిజిస్ట్రేషన్ పూర్తి చేశారు.",
    stat1: "10 సంవత్సరాల అనుభవం",
    stat2: "5 విజయవంతమైన వెంచర్లు",
    stat3: "100% క్లియర్ టైటిల్ & DTCP/RERA",
    stat4: "వెంటనే స్పాట్ రిజిస్ట్రేషన్",

    // Hero Section
    heroBadge: "ప్రభుత్వ నిబంధనల ప్రకారం 100% ఆమోదం పొందిన ప్లాట్లు",
    heroTitle: "భవిష్యత్తుకు బంగారు పెట్టుబడి — B.N వెంచర్స్ విల్లా ప్లాట్లు",
    heroSubtitle: "రిటైర్డ్ అధికారులు, ఉద్యోగులు, కుటుంబాల కోసం ఎలాంటి సమస్యలు లేని స్పష్టమైన ప్లాట్లు. నచ్చిన ప్లాట్ క్లిక్ చేసి నేరుగా చూడండి.",
    exploreVenturesBtn: "వెంచర్లు చూడండి",
    viewPlotsBtn: "మాస్టర్ ప్లాన్ మ్యాప్ చూడండి",

    // Status Colors (Requirement 9 & 10)
    legendTitle: "ప్లాట్ల రంగుల వివరాలు:",
    statusAvailable: "అందుబాటులో ఉంది (ఆకుపచ్చ)",
    statusPending: "బుకింగ్ పరిశీలనలో ఉంది (పసుపు)",
    statusBooked: "బుక్ చేయబడింది (ఎరుపు)",
    statusSold: "అమ్మబడింది (ఎరుపు)",
    statusBlocked: "బ్లాక్ చేయబడింది (నలుపు)",
    ownerNameLabel: "యజమాని పేరు",
    bookedByLabel: "కొనుగోలు చేసిన యజమాని",

    // 2D & 3D Map
    map2DTab: "2D స్పష్టమైన ప్లాన్ మ్యాప్ (పెద్ద అక్షరాలు)",
    map3DTab: "3D తిరిగే వీడియో వ్యూ",
    zoomInBtn: "పెద్దది చేయండి (+)",
    zoomOutBtn: "చిన్నది చేయండి (-)",
    resetBtn: "మొదటి రూపం",
    rotate3dHelper: "చేతితో తిప్పి నాలుగు వైపులా చూడవచ్చు",

    // Investment Section (Requirement 5)
    investTitle: "ఇన్వెస్ట్ ఇన్ ఫీచర్ (భవిష్యత్ పెట్టుబడి)",
    investSubtitle: "B.N వెంచర్స్ ప్లాట్లలో పెట్టుబడి పెట్టడం ఎందుకు అత్యంత సురక్షితం?",
    investPoint1Title: "1. రెట్టింపు ఆదాయం & వేగవంతమైన వృద్ధి",
    investPoint1Desc: "నేషనల్ హైవేలు, గ్రోత్ కారిడార్ల వద్ద ఉన్నందున మీ పెట్టుబడి వేగంగా పెరుగుతుంది.",
    investPoint2Title: "2. ప్రభుత్వ ఉద్యోగులు, అధికారులకు పూర్తి భరోసా",
    investPoint2Desc: "ఎలాంటి లీగల్ సమస్యలు లేని పక్కా 30 సంవత్సరాల లింక్ డాక్యుమెంట్లు, ప్రభుత్వ రిజిస్ట్రేషన్.",
    investPoint3Title: "3. వెంటనే ఇల్లు కట్టుకోవడానికి సిద్ధం",
    investPoint3Desc: "40 అడుగుల రోడ్లు, కరెంట్ స్తంభాలు, నీటి ట్యాంక్, ప్రహరీ గోడ నిర్మాణం పూర్తయిన ప్లాట్లు.",

    // Regional Headquarters (Requirement 6)
    hqTitle: "ప్రాంతీయ ప్రధాన కార్యాలయం & యజమాని సంప్రదింపులు",
    hqAddress: "B.N వెంచర్స్ ప్రాంతీయ ప్రధాన కార్యాలయం: NH-44 బైపాస్ & మంచిర్యాల రోడ్డు, నిర్మల్ జిల్లా (PIN: 504106), తెలంగాణ & ఫైనాన్షియల్ డిస్ట్రిక్ట్, హైదరాబాద్",
    callOwner: "నేరుగా యజమానితో మాట్లాడండి",
    instantWhatsapp: "ఇన్‌స్టంట్ వాట్సాప్ డెస్క్",

    // Site Visit Form (Requirement 3: Simplified)
    siteVisitTitle: "సైట్ చూడటానికి రండి (ఉచిత ప్రయాణం)",
    siteVisitSubtitle: "మా వెంచర్ దగ్గరకు రండి, మీ కళ్లతో ప్లాట్ చూసి నిర్ణయం తీసుకోండి.",
    fullName: "మీ పూర్తి పేరు",
    phoneNumber: "మీ ఫోన్ నెంబర్",
    visitDate: "రావాలనుకుంటున్న తేదీ",
    timeSlot: "సమయం",
    submitVisit: "సైట్ విజిట్ బుక్ చేయండి",

    // Plot Reservation (Requirement 10)
    reserveTitle: "ప్లాట్ రిజర్వ్ చేసుకోండి",
    reserveSubtitle: "ఈ ప్లాట్ ఇతరులు తీసుకోకుండా మీ పేరు మీద తాత్కాలికంగా లాక్ చేయబడుతుంది",
    reserveSuccess: "అభినందనలు! ప్లాట్ విజయవంతంగా మీ పేరు మీద రిజర్వ్ చేయబడింది. ప్లాన్ మ్యాప్‌లో మీ పేరు కనిపిస్తుంది.",

    // Media
    sitePhotos: "సైట్ ఫోటోలు",
    siteVideos: "సైట్ డ్రోన్ వీడియోలు",
    watchVideo: "వీడియో చూడండి",

    // Common shortcuts
    available: "లభ్యం",
    pending: "పరిశీలనలో ఉంది",
    booked: "బుక్ చేయబడింది",
    blocked: "బ్లాక్ చేయబడింది",
    totalPlots: "మొత్తం ప్లాట్లు",
    interactiveLayout: "ఇంటరాక్టివ్ మాస్టర్ లేఅవుట్",
    masterLayoutPlan: "మాస్టర్ లేఅవుట్ ప్లాన్",
    conceptual3DView: "3D తిరిగే వీడియో వ్యూ",
    instantWhatsAppDesk: "ఇన్‌స్టంట్ వాట్సాప్ డెస్క్",
    digitalBrochure: "డిజిటల్ బ్రోచర్",
    venturePhotosVideos: "వెంచర్ ఫోటోలు & వీడియోలు",
    explorePlots: "ప్లాట్ల జాబితా",
    plotArea: "విస్తీర్ణం",
    facing: "ఫేసింగ్ (దిశ)",
    roadWidth: "రోడ్డు వెడల్పు",
    owner: "యజమాని",
    totalPrice: "మొత్తం ధర",
    reserveOnline: "ఆన్‌లైన్‌లో రిజర్వ్ చేయండి",

    // Cardinal & Vastu Directions (East, West, North, South)
    dirNorth: "ఉత్తరం (NORTH)",
    dirSouth: "దక్షిణం (SOUTH)",
    dirEast: "తూర్పు (EAST)",
    dirWest: "పడమర (WEST)",
    dirNorthFull: "ఉత్తరం (NORTH) • 33 అడుగుల సెక్టార్ రోడ్డు",
    dirSouthFull: "దక్షిణం (SOUTH) • 33 అడుగుల రోడ్డు & ప్రధాన గేట్",
    dirEastFull: "తూర్పు (EAST - వాస్తు శ్రేష్ఠం) • సెంట్రల్ పార్క్ & 60 అడుగుల రోడ్డు",
    dirWestFull: "పడమర (WEST) • నివాస ప్లాట్లు సరిహద్దు",
    vastuGuide: "దిశలు & వాస్తు గైడ్"
  },

  en: {
    // Branding & Header
    brandName: "B.N Ventures",
    brandTagline: "10 Years of Trusted Real Estate Excellence • 5 Landmark Ventures Delivered",
    selectLanguage: "Change Language",
    selectLocation: "Location",
    allLocations: "All Locations",
    changeLocation: "Change Location",
    adminPortal: "Admin Portal",
    directCall: "Direct Call to Owner",
    whatsappDesk: "Instant WhatsApp Desk",
    bookSiteVisit: "Book a Site Visit",

    // Welcome / Entry Modal
    welcomeTitle: "Welcome to B.N Ventures",
    welcomeSubtitle: "Please select your preferred language and venture location",
    step1Language: "1. Select Language",
    step2Location: "2. Select Your Preferred Venture Location",
    continueBtn: "Explore Ventures & Master Layouts",

    // Navigation
    navHome: "Home",
    navVentures: "Our Ventures (5)",
    navPlots: "Master Layout",
    navAbout: "About Us (10 Yrs Experience)",
    navContact: "Contact Desk",

    // Founder Story & Trust (Requirement 2)
    ownerExpTitle: "10 Years of Experience — Started Small & Delivered 5 Landmark Ventures",
    ownerExpDesc: "The founder of B.N Ventures brings over a decade of hands-on real estate mastery. Starting with humble beginnings, built upon uncompromising integrity, legal transparency, and personal customer service, the promoter has successfully developed and delivered 5 premium plotted ventures with spot registration for hundreds of happy families.",
    stat1: "10 Years Experience",
    stat2: "5 Delivered Ventures",
    stat3: "100% Clear Title Deeds",
    stat4: "Instant Spot Registration",

    // Hero Section
    heroBadge: "100% DTCP & RERA APPROVED VILLA PLOTS",
    heroTitle: "Secure Your Family's Future with B.N Ventures",
    heroSubtitle: "Handpicked premium plotted developments designed for retirement security, government officers, and investors. Click any plot on our interactive layout to explore.",
    exploreVenturesBtn: "Explore Ventures",
    viewPlotsBtn: "View Master Layout Map",

    // Status Colors (Requirement 9 & 10)
    legendTitle: "Plot Status Legend:",
    statusAvailable: "Available (Green)",
    statusPending: "Booking Pending (Yellow)",
    statusBooked: "Booked (Red)",
    statusSold: "Sold (Red)",
    statusBlocked: "Blocked / Reserved (Black)",
    ownerNameLabel: "Owner Name",
    bookedByLabel: "Registered Owner",

    // 2D & 3D Map
    map2DTab: "2D Master SVG Layout (Large Legible Text)",
    map3DTab: "Conceptual 3D Interactive View",
    zoomInBtn: "Zoom In (+)",
    zoomOutBtn: "Zoom Out (-)",
    resetBtn: "Reset View",
    rotate3dHelper: "Drag with mouse/touch to inspect in 360° space",

    // Investment Section (Requirement 5)
    investTitle: "Invest in Feature",
    investSubtitle: "Why B.N Ventures Plotted Land is the Safest High-Return Asset for Your Future",
    investPoint1Title: "1. Rapid Capital Appreciation Along High-Growth Corridors",
    investPoint1Desc: "Situated right on major national expressways and upcoming orbital ring roads, multiplying your asset value safely.",
    investPoint2Title: "2. Absolute Legal Protection for Officers & Families",
    investPoint2Desc: "30-year vetted title documents, clear government encumbrance certificates, and direct registrar deed execution.",
    investPoint3Title: "3. Fully Developed Infrastructure Ready for Construction",
    investPoint3Desc: "40ft blacktop tar roads, underground electricity, overhead water tanks, and landscaped parks already developed on-site.",

    // Regional Headquarters (Requirement 6)
    hqTitle: "Regional Headquarters & Direct Contact",
    hqAddress: "B.N Ventures Regional Headquarters: NH-44 Bypass & Mancherial Road, Nirmal District (PIN: 504106), Telangana & Financial District Corridor, Hyderabad",
    callOwner: "Direct Call to Real Estate Owner",
    instantWhatsapp: "Instant WhatsApp Desk",

    // Site Visit Form (Requirement 3: Simplified)
    siteVisitTitle: "Schedule a Site Visit (Free Chauffeured Transport)",
    siteVisitSubtitle: "Visit the venture in person, walk the roads, and inspect your plot boundary with our senior advisor.",
    fullName: "Full Name",
    phoneNumber: "Mobile Number (10 Digits)",
    visitDate: "Preferred Visit Date",
    timeSlot: "Select Time Slot",
    submitVisit: "Confirm Site Visit Appointment",

    // Plot Reservation (Requirement 10)
    reserveTitle: "Reserve This Plot Online",
    reserveSubtitle: "Instantly locks the plot under your name and displays your ownership directly on the master layout map.",
    reserveSuccess: "Congratulations! Plot successfully reserved. Your name is now displayed on the plot layout map.",

    // Media
    sitePhotos: "Site Photos",
    siteVideos: "Site Drone Tour Videos",
    watchVideo: "Watch Video Tour",

    // Common shortcuts
    available: "Available",
    pending: "Pending",
    booked: "Booked",
    blocked: "Blocked",
    totalPlots: "Total Plots",
    interactiveLayout: "Interactive Master Layout",
    masterLayoutPlan: "Master Layout Plan",
    conceptual3DView: "Conceptual 3D View",
    instantWhatsAppDesk: "Instant WhatsApp Desk",
    digitalBrochure: "Digital Brochure",
    venturePhotosVideos: "Venture Photos & Videos",
    explorePlots: "Explore Plots",
    plotArea: "Area",
    facing: "Facing",
    roadWidth: "Road Width",
    owner: "Owner",
    totalPrice: "Total Price",
    reserveOnline: "Reserve Online",

    // Cardinal & Vastu Directions (East, West, North, South)
    dirNorth: "NORTH (ఉత్తరం)",
    dirSouth: "SOUTH (దక్షిణం)",
    dirEast: "EAST (తూర్పు)",
    dirWest: "WEST (పడమర)",
    dirNorthFull: "NORTH (ఉత్తరం) • 33 Ft Sector Road",
    dirSouthFull: "SOUTH (దక్షిణం) • 33 Ft Road & Main Entrance",
    dirEastFull: "EAST (తూర్పు - Vastu Auspicious) • Central Park & 60 Ft Boulevard",
    dirWestFull: "WEST (పడమర) • Residential Boundary",
    vastuGuide: "Cardinal & Vastu Directions Guide"
  },

  hi: {
    // Branding & Header
    brandName: "B.N वेंचर्स",
    brandTagline: "10 वर्षों का विश्वसनीय रियल एस्टेट अनुभव • 5 सफल लैंडमार्क वेंचर्स",
    selectLanguage: "भाषा बदलें",
    selectLocation: "स्थान",
    allLocations: "सभी स्थान",
    changeLocation: "स्थान बदलें",
    adminPortal: "एडमिन पोर्टल",
    directCall: "मालिक से सीधे बात करें",
    whatsappDesk: "इंस्टेंट व्हाट्सएप डेस्क",
    bookSiteVisit: "साइट विजिट बुक करें (मुफ्त वाहन)",

    // Welcome / Entry Modal
    welcomeTitle: "B.N वेंचर्स में आपका स्वागत है",
    welcomeSubtitle: "कृपया अपनी भाषा और पसंदीदा स्थान चुनें",
    step1Language: "1. अपनी भाषा चुनें",
    step2Location: "2. स्थान चुनें",
    continueBtn: "वेंचर्स और प्लॉट लेआउट देखें",

    // Navigation
    navHome: "होम",
    navVentures: "हमारे वेंचर्स (5)",
    navPlots: "मास्टर लेआउट",
    navAbout: "हमारे बारे में (10 साल अनुभव)",
    navContact: "संपर्क",

    // Founder Story & Trust (Requirement 2)
    ownerExpTitle: "10 साल का अनुभव — छोटी शुरुआत से 5 सफल वेंचर्स तक",
    ownerExpDesc: "B.N वेंचर्स के संस्थापक के पास रियल एस्टेट का 10 वर्षों का गहरा और पारदर्शी अनुभव है। शुरुआत से लेकर आज तक 5 बड़े गेटेड वेंचर्स सफलतापूर्वक विकसित कर सैकड़ों परिवारों को स्पॉट रजिस्ट्री दी गई है।",
    stat1: "10 साल का अनुभव",
    stat2: "5 सफल वेंचर्स",
    stat3: "100% क्लियर टाइटल दस्तावेज",
    stat4: "तुरंत स्पॉट रजिस्ट्री",

    // Hero Section
    heroBadge: "100% DTCP और RERA स्वीकृत प्लॉट",
    heroTitle: "अपने परिवार के भविष्य के लिए B.N वेंचर्स के साथ निवेश करें",
    heroSubtitle: "सरकारी अधिकारियों, कर्मचारियों और परिवारों के लिए सबसे सुरक्षित और पारदर्शी प्लॉट।",
    exploreVenturesBtn: "वेंचर्स देखें",
    viewPlotsBtn: "मास्टर प्लान मैप देखें",

    // Status Colors (Requirement 9 & 10)
    legendTitle: "प्लॉट की स्थिति:",
    statusAvailable: "उपलब्ध (हरा)",
    statusPending: "बुकिंग समीक्षाधीन (पीला)",
    statusBooked: "बुक किया गया (लाल)",
    statusSold: "बिक चुका है (लाल)",
    statusBlocked: "ब्लॉक / आरक्षित (काला)",
    ownerNameLabel: "मालिक का नाम",
    bookedByLabel: "प्लॉट मालिक",

    // 2D & 3D Map
    map2DTab: "2D मास्टर SVG लेआउट (बड़े अक्षर)",
    map3DTab: "3D इंटरैक्टिव व्यू",
    zoomInBtn: "बड़ा करें (+)",
    zoomOutBtn: "छोटा करें (-)",
    resetBtn: "रीसेट",
    rotate3dHelper: "माउस या उंगली से घुमाकर 360° में देखें",

    // Investment Section (Requirement 5)
    investTitle: "इन्वेस्ट इन फीचर",
    investSubtitle: "B.N वेंचर्स में जमीन खरीदना आपके भविष्य के लिए सबसे सुरक्षित निवेश क्यों है?",
    investPoint1Title: "1. हाईवे कॉरिडोर पर तेजी से बढ़ती कीमतें",
    investPoint1Desc: "नेशनल हाईवे और रिंग रोड के पास होने के कारण जमीन का मूल्य तेजी से बढ़ता है।",
    investPoint2Title: "2. सरकारी अधिकारियों और परिवारों के लिए 100% कानूनी सुरक्षा",
    investPoint2Desc: "30 साल के क्लियर टाइटल दस्तावेज और तुरंत सरकारी रजिस्ट्री।",
    investPoint3Title: "3. तुरंत घर बनाने के लिए पूर्ण सुविधाएं",
    investPoint3Desc: "40 फीट पक्की डामर सड़कें, भूमिगत बिजली, पानी की टंकी और पार्क की पूरी सुविधा।",

    // Regional Headquarters (Requirement 6)
    hqTitle: "मुख्यालय और सीधा संपर्क",
    hqAddress: "B.N वेंचर्स टावर्स, हाईवे कॉरिडोर, हैदराबाद • विजयवाड़ा",
    callOwner: "सीधे मालिक को कॉल करें",
    instantWhatsapp: "इंस्टेंट व्हाट्सएप डेस्क",

    // Site Visit Form
    siteVisitTitle: "साइट विजिट बुक करें",
    siteVisitSubtitle: "हमारे साथ आकर जमीन देखें और संतुष्ट होने के बाद निर्णय लें।",
    fullName: "पूरा नाम",
    phoneNumber: "मोबाइल नंबर",
    visitDate: "तारीख",
    timeSlot: "समय",
    submitVisit: "साइट विजिट कन्फर्म करें",

    // Plot Reservation
    reserveTitle: "प्लॉट ऑनलाइन रिजर्व करें",
    reserveSubtitle: "यह प्लॉट आपके नाम पर तुरंत लॉक हो जाएगा और लेआउट में आपका नाम दिखेगा।",
    reserveSuccess: "बधाई हो! प्लॉट आपके नाम पर रिजर्व हो गया है।",

    // Media
    sitePhotos: "साइट तस्वीरें",
    siteVideos: "साइट ड्रोन वीडियो",
    watchVideo: "वीडियो देखें",

    // Common shortcuts
    available: "उपलब्ध",
    pending: "समीक्षाधीन",
    booked: "बुक किया गया",
    blocked: "ब्लॉक किया गया",
    totalPlots: "कुल प्लॉट्स",
    interactiveLayout: "इंटरएक्टिव मास्टर लेआउट",
    masterLayoutPlan: "मास्टर लेआउट योजना",
    conceptual3DView: "3D इंटरएक्टिव व्यू",
    instantWhatsAppDesk: "इंस्टेंट व्हाट्सएप डेस्क",
    digitalBrochure: "डिजिटल ब्रोशर",
    venturePhotosVideos: "वेंचर तस्वीरें और वीडियो",
    explorePlots: "प्लॉट देखें",
    plotArea: "क्षेत्रफल",
    facing: "दिशा (फेसिंग)",
    roadWidth: "सड़क की चौड़ाई",
    owner: "मालिक",
    totalPrice: "कुल कीमत",
    reserveOnline: "ऑनलाइन रिजर्व करें",

    // Cardinal & Vastu Directions (East, West, North, South)
    dirNorth: "उत्तर (NORTH)",
    dirSouth: "दक्षिण (SOUTH)",
    dirEast: "पूर्व (EAST)",
    dirWest: "पश्चिम (WEST)",
    dirNorthFull: "उत्तर (NORTH) • 33 फीट सेक्टर रोड",
    dirSouthFull: "दक्षिण (SOUTH) • 33 फीट रोड & मुख्य द्वार",
    dirEastFull: "पूर्व (EAST - वास्तु शुभ) • सेंट्रल पार्क & 60 फीट रोड",
    dirWestFull: "पश्चिम (WEST) • आवासीय सीमा",
    vastuGuide: "दिशा निर्देश और वास्तु गाइड"
  }
};

export function t(lang: Language = 'en', key: string): string {
  const dict = translations[lang] || translations.en;
  return dict[key] || translations.en[key] || key;
}
