import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle, 
  PhoneCall,
  Send,
  ExternalLink
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';
import { api } from '../api';

interface ContactSectionProps {
  currentLang?: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ currentLang = 'en' }) => {
  const [form, setForm] = useState({ name: '', phone: '', email: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const t = translations[currentLang];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg(null);
    setErrorMsg(null);

    if (!form.name || !form.phone || !form.message) {
      setErrorMsg(currentLang === 'te' ? 'దయచేసి పేరు, ఫోన్ నెంబర్ మరియు సందేశం నమోదు చేయండి.' : 'Please enter your name, phone number, and message.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.sendContact(form);
      setSuccessMsg(res.message);
      setForm({ name: '', phone: '', email: '', subject: '', message: '' });
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to send message.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-16 sm:py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-800 bg-emerald-100/70 px-3.5 py-1 rounded-full border border-emerald-300">
            <PhoneCall className="w-4 h-4 text-emerald-700" /> {t.navContact}
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-navy-950">
            {t.hqTitle}
          </h2>
          <p className="text-navy-600 text-sm">
            {currentLang === 'te' 
              ? 'ప్లాట్ల వివరాలు లేదా రిజిస్ట్రేషన్ సమాచారం కోసం నేరుగా రియల్ ఎస్టేట్ యజమానికి కాల్ చేయండి లేదా వాట్సాప్‌లో మాట్లాడండి.' 
              : 'Direct hotline to the developer owner and regional venture coordination desk.'}
          </p>
        </div>

        {/* Contact Grid: Headquarters & Instant WhatsApp (Requirement 6) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Regional Headquarters (Requirement 6) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-navy-100 shadow-sm space-y-6">
              <h4 className="font-display font-black text-xl text-navy-950">
                {t.hqTitle}
              </h4>

              <div className="space-y-4 text-xs sm:text-sm">
                
                {/* Office Location */}
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <strong className="text-navy-900 block font-bold text-sm">
                      {currentLang === 'te' ? 'కార్యాలయ చిరునామా' : 'Headquarters Address'}
                    </strong>
                    <p className="text-navy-600 leading-relaxed mt-0.5">
                      {t.hqAddress}
                    </p>
                  </div>
                </div>

                {/* Direct Phone Calling (Requirement 6) */}
                <div className="p-4 bg-slate-50 border-2 border-navy-100 rounded-2xl space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="text-navy-950 block text-sm font-display font-extrabold">
                        {t.callOwner}
                      </strong>
                      <span className="text-emerald-700 font-extrabold text-sm">+91 98765 43210</span>
                    </div>
                  </div>

                  <a
                    href="tel:+919876543210"
                    className="w-full bg-navy-900 hover:bg-navy-950 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition flex items-center justify-center gap-2"
                  >
                    <PhoneCall className="w-4 h-4 text-emerald-400" />
                    <span>{currentLang === 'te' ? 'ఇప్పుడే కాల్ చేయండి' : 'Call Owner Now'}</span>
                  </a>
                </div>

                {/* Instant WhatsApp Desk (Requirement 6) */}
                <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <strong className="text-emerald-950 text-sm block font-black">
                        {t.instantWhatsapp}
                      </strong>
                      <span className="text-xs text-emerald-800">
                        {currentLang === 'te' ? 'ఫోటోలు, ప్లాన్ మరియు ధరల కోసం' : 'Direct WhatsApp chat for layout maps & pricing'}
                      </span>
                    </div>
                    <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></span>
                  </div>

                  <a
                    href="https://wa.me/919876543210?text=Hello%20B.N%20Ventures,%20I%20am%20interested%20in%20plots"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black py-3 px-4 rounded-xl transition flex items-center justify-center gap-2 shadow-md"
                  >
                    <span>{t.whatsappDesk}</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>

              </div>
            </div>
          </div>

          {/* Right Column: Direct Inquiry Message Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border-2 border-navy-100 shadow-sm space-y-5">
            <h4 className="font-display font-black text-xl text-navy-950">
              {currentLang === 'te' ? 'సందేశం పంపండి' : 'Send a Message'}
            </h4>

            {successMsg && (
              <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-2xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                {successMsg}
              </div>
            )}

            {errorMsg && (
              <div className="p-4 bg-red-50 border border-red-300 text-red-800 rounded-2xl text-xs flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {t.fullName} *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g. Ramesh Kumar"
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                    {t.phoneNumber} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="10-digit mobile"
                    className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-navy-800 mb-1">
                  {currentLang === 'te' ? 'మీ సందేశం / ఏ వెంచర్ కావాలి?' : 'Message / Which venture are you interested in?'} *
                </label>
                <textarea
                  rows={4}
                  required
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder={currentLang === 'te' ? 'నాకు ఈస్ట్ ఫేసింగ్ ప్లాట్ కావాలి...' : 'Looking for East facing plot details...'}
                  className="w-full bg-slate-50 border border-navy-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none font-medium"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3.5 px-4 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{loading ? 'Submitting...' : (currentLang === 'te' ? 'సందేశం పంపండి' : 'Send Message to Owner')}</span>
              </button>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
