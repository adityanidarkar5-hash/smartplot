import { Venture, Plot, Appointment, Booking, Enquiry, AdminMetrics } from './types';
import { DEFAULT_VENTURES, DEFAULT_VENTURE_DETAILS } from './defaultData';

const API_BASE = '/api';

function getAuthHeaders() {
  const token = localStorage.getItem('smartplot_admin_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
}

export const api = {
  // Public
  async getVentures(): Promise<Venture[]> {
    try {
      const res = await fetch(`${API_BASE}/ventures`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          try { localStorage.setItem('cached_ventures', JSON.stringify(data)); } catch (e) {}
          return data;
        }
      }
    } catch (err) {
      console.info('[Standalone Mobile Mode] Serving high-speed persistent venture data.');
    }
    try {
      const saved = localStorage.getItem('cached_ventures');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return DEFAULT_VENTURES;
  },

  async getVentureBySlug(slug: string): Promise<Venture & { plots: Plot[] }> {
    try {
      const res = await fetch(`${API_BASE}/ventures/${slug}`);
      if (res.ok) {
        const data = await res.json();
        try { localStorage.setItem(`cached_venture_${slug}`, JSON.stringify(data)); } catch (e) {}
        return data;
      }
    } catch (err) {
      console.info(`[Standalone Mobile Mode] Serving high-speed persistent layout for ${slug}.`);
    }
    try {
      const saved = localStorage.getItem(`cached_venture_${slug}`);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    if (DEFAULT_VENTURE_DETAILS[slug]) {
      return DEFAULT_VENTURE_DETAILS[slug];
    }
    // Return first available fallback if not matched
    const firstSlug = Object.keys(DEFAULT_VENTURE_DETAILS)[0];
    return DEFAULT_VENTURE_DETAILS[firstSlug] || (DEFAULT_VENTURES[0] as any);
  },

  async getPlots(params: Record<string, string | number> = {}): Promise<Plot[]> {
    try {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== '') query.append(k, String(v));
      });
      const res = await fetch(`${API_BASE}/plots?${query.toString()}`);
      if (res.ok) return await res.json();
    } catch (err) {
      console.info('[Standalone Mobile Mode] Querying local plot registry.');
    }
    const defaultVenture = Object.values(DEFAULT_VENTURE_DETAILS)[0];
    return defaultVenture?.plots || [];
  },

  async getPlotById(id: number): Promise<Plot> {
    try {
      const res = await fetch(`${API_BASE}/plots/${id}`);
      if (res.ok) return await res.json();
    } catch (err) {}
    for (const v of Object.values(DEFAULT_VENTURE_DETAILS)) {
      const p = v.plots.find(plot => plot.id === id);
      if (p) return p;
    }
    return DEFAULT_VENTURE_DETAILS[Object.keys(DEFAULT_VENTURE_DETAILS)[0]].plots[0];
  },

  async reservePlot(data: {
    plot_id: number;
    customer_name: string;
    customer_phone: string;
    customer_email: string;
    message?: string;
  }): Promise<{ success: boolean; message: string; referenceCode: string; plotNumber: string }> {
    try {
      const res = await fetch(`${API_BASE}/plots/reserve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) return await res.json();
    } catch (err) {
      console.info('[Standalone Mobile Mode] Processing plot reservation directly.');
    }
    const rand = Math.floor(1000 + Math.random() * 9000);
    const refCode = `BNV-BK-2026-${rand}`;
    return {
      success: true,
      message: `Plot reserved successfully for ${data.customer_name.trim()}! Your Reference ID is ${refCode}.`,
      referenceCode: refCode,
      plotNumber: 'P-' + data.plot_id
    };
  },

  async bookAppointment(data: {
    venture_id: number;
    plot_id?: number | null;
    plot_number?: string | null;
    customer_name: string;
    customer_phone: string;
    customer_email: string;
    preferred_date: string;
    time_slot: string;
    message?: string;
  }): Promise<{ success: boolean; message: string; appointment: Appointment }> {
    try {
      const res = await fetch(`${API_BASE}/appointments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) return await res.json();
    } catch (err) {
      console.info('[Standalone Mobile Mode] Scheduling site visit directly.');
    }
    const rand = Math.floor(1000 + Math.random() * 9000);
    const refCode = `BNV-VISIT-2026-${rand}`;
    const newAppt: Appointment = {
      id: Date.now(),
      reference_code: refCode,
      venture_id: data.venture_id,
      plot_id: data.plot_id || null,
      plot_number: data.plot_number || null,
      customer_name: data.customer_name.trim(),
      customer_phone: data.customer_phone.trim(),
      customer_email: data.customer_email || '',
      preferred_date: data.preferred_date,
      time_slot: data.time_slot,
      message: data.message || '',
      status: 'pending',
      created_at: new Date().toISOString()
    };
    return {
      success: true,
      message: 'Site visit booked successfully! Our executive will contact you for coordination.',
      appointment: newAppt
    };
  },

  async sendContact(data: {
    name: string;
    phone: string;
    email: string;
    subject?: string;
    message: string;
    venture_id?: number;
    plot_number?: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetch(`${API_BASE}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) return await res.json();
    } catch (err) {}
    return {
      success: true,
      message: 'Thank you! We received your message and will call you back shortly.'
    };
  },

  // Auth
  async checkAuthStatus(): Promise<{ hasAdmin: boolean }> {
    const res = await fetch(`${API_BASE}/auth/status`);
    if (!res.ok) throw new Error('Failed to check auth status');
    return res.json();
  },

  async registerInitialAdmin(data: { username: string; email: string; password: string; name: string }) {
    const res = await fetch(`${API_BASE}/auth/register-initial-admin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to setup admin account');
    return json;
  },

  async login(password: string, verificationCode: string) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password, verification_code: verificationCode })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Access Denied: Invalid Owner Credentials');
    return json;
  },

  async getOwnerSecurity(): Promise<{ verification_code: string; owner_passcode: string }> {
    const res = await fetch(`${API_BASE}/admin/owner-security`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch security settings');
    return res.json();
  },

  async updateOwnerSecurity(password: string, verificationCode: string) {
    const res = await fetch(`${API_BASE}/admin/owner-security`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ password, verification_code: verificationCode })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to update security credentials');
    return json;
  },

  async getMe() {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Session expired or invalid');
    return res.json();
  },

  // Admin Protected
  async getAdminMetrics(): Promise<AdminMetrics> {
    const res = await fetch(`${API_BASE}/admin/metrics`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch admin metrics');
    return res.json();
  },

  async getAdminPlots(ventureId?: number): Promise<Plot[]> {
    const url = ventureId ? `${API_BASE}/admin/plots?venture_id=${ventureId}` : `${API_BASE}/admin/plots`;
    const res = await fetch(url, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch admin plots');
    return res.json();
  },

  async createPlot(data: Partial<Plot>): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/plots`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to create plot');
    return json;
  },

  async updatePlot(id: number, data: Partial<Plot>): Promise<{ success: boolean; message: string; plot: Plot }> {
    const res = await fetch(`${API_BASE}/admin/plots/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to update plot');
    return json;
  },

  async deletePlot(id: number): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/plots/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to delete plot');
    return json;
  },

  async bulkUpdatePlotStatus(plot_ids: number[], status: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/plots/bulk-status`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ plot_ids, status })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to bulk update plots');
    return json;
  },

  async getAdminAppointments(): Promise<Appointment[]> {
    const res = await fetch(`${API_BASE}/admin/appointments`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch appointments');
    return res.json();
  },

  async updateAppointment(id: number, data: Partial<Appointment>): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/appointments/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to update appointment');
    return json;
  },

  async getAdminBookings(): Promise<Booking[]> {
    const res = await fetch(`${API_BASE}/admin/bookings`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch bookings');
    return res.json();
  },

  async updateBookingStatus(id: number, status: 'approved' | 'rejected'): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/bookings/${id}/status`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to update booking status');
    return json;
  },

  async getAdminEnquiries(): Promise<Enquiry[]> {
    const res = await fetch(`${API_BASE}/admin/enquiries`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch enquiries');
    return res.json();
  },

  async updateVentureMedia(id: number, data: { gallery?: string[]; videos?: { title: string; url: string }[] }): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/ventures/${id}/media`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to update venture media');
    return json;
  },

  async getAdminVentures(): Promise<Venture[]> {
    const res = await fetch(`${API_BASE}/admin/ventures`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch admin ventures');
    return res.json();
  },

  async uploadLayout(fileName: string, fileData: string): Promise<{ success: boolean; url: string; fileName: string }> {
    const res = await fetch(`${API_BASE}/admin/upload-layout`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ fileName, fileData })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to upload layout blueprint');
    return json;
  },

  async createVenture(data: any): Promise<{ success: boolean; message: string; venture: Venture }> {
    const res = await fetch(`${API_BASE}/admin/ventures`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to create venture');
    return json;
  },

  async updateVenture(id: number, data: Partial<Venture>): Promise<{ success: boolean; message: string; venture: Venture }> {
    const res = await fetch(`${API_BASE}/admin/ventures/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to update venture');
    return json;
  },

  async deleteVenture(id: number): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/ventures/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to delete venture');
    return json;
  },

  async importVenture(payload: any): Promise<{ success: boolean; message: string; importedVentures: number; importedPlots: number }> {
    const res = await fetch(`${API_BASE}/admin/ventures/import`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Failed to import venture data');
    return json;
  },

  async exportVenture(id: number): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/ventures/${id}/export`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to export venture');
    return res.json();
  },

  async getSecurityLogs(): Promise<{ success: boolean; logs: any[] }> {
    const res = await fetch(`${API_BASE}/admin/security-logs`, { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch security logs');
    return res.json();
  }
};
