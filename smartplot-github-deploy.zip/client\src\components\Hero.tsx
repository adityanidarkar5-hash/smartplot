import React from 'react';
import { MapPin, Calendar, ArrowRight, ShieldCheck, CheckCircle2, Compass, Award, Navigation, ExternalLink } from 'lucide-react';
import { Venture, Language } from '../types';
import { translations } from '../i18n';
import { openInGoogleMaps } from '../utils/googleMaps';

interface HeroProps {
  ventures: Venture[];
  selectedLocation: string;
  onSelectLocation: (loc: string) => void;
  onExploreVentures: () => void;
  onViewPlots: () => void;
  onBookSiteVisit: () => void;
  currentLang: Language;
}

export const Hero: React.FC<HeroProps> = ({
  ventures,
  selectedLocation,
  onSelectLocation,
  onExploreVentures,
  onViewPlots,
  onBookSiteVisit,
  currentLang,
}) => {
  const t = translations[currentLang];
  const uniqueCities = Array.from(new Set(ventures.map(v => v.city))).filter(Boolean);

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-50 via-white to-white py-12 lg:py-18 border-b border-navy-100">
      
      {/* Background radial decorations */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#059669_1px,transparent_1px)] [background-size:24px_24px]"></div>
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-emerald-200/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Heading & 10 Years Experience */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Experience Badge (Requirement 2) */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100/70 border border-emerald-300 text-emerald-900 text-xs sm:text-sm font-black tracking-wide shadow-sm">
              <Award className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>
                {currentLang === 'te' 
                  ? `10 సంవత్సరాల నిజాయితీ గల రియల్ ఎస్టేట్ అనుభవం • ${ventures.length || 5} ప్రతిష్టాత్మక వెంచర్లు` 
                  : `10 Years of Trusted Real Estate Experience • ${ventures.length || 5} Delivered Ventures`}
              </span>
            </div>

            <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold text-navy-950 leading-[1.14] tracking-tight">
              {t.heroTitle}
            </h1>

            <p className="text-navy-700 text-sm sm:text-lg max-w-xl leading-relaxed font-medium">
              {t.heroSubtitle}
            </p>

            {/* Trust Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="flex items-center gap-2 text-xs font-bold text-navy-900 bg-emerald-50/70 p-3 rounded-2xl border border-emerald-200 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="block font-black">{currentLang === 'te' ? '100% క్లియర్ టైటిల్' : '100% Clear Title'}</span>
                  <span className="text-[10px] text-navy-600">{currentLang === 'te' ? '30 సంవత్సరాల లింక్ డాక్యుమెంట్లు' : '30-Year Vetted Deeds'}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-navy-900 bg-emerald-50/70 p-3 rounded-2xl border border-emerald-200 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="block font-black">{currentLang === 'te' ? 'DTCP & RERA ఆమోదం' : 'DTCP & TG-RERA Approved'}</span>
                  <span className="text-[10px] text-navy-600">{currentLang === 'te' ? 'ప్రభుత్వ గుర్తింపు పొందిన లేఅవుట్' : 'Govt Sanctioned Plan'}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-navy-900 bg-emerald-50/70 p-3 rounded-2xl border border-emerald-200 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="block font-black">{currentLang === 'te' ? 'స్పాట్ రిజిస్ట్రేషన్' : 'Spot Registration Ready'}</span>
                  <span className="text-[10px] text-navy-600">{currentLang === 'te' ? 'సబ్-రిజిస్ట్రార్ ఆఫీసులో వెంటనే' : 'Direct Sub-Registrar Deed'}</span>
                </div>
              </div>
            </div>

            {/* Special Government Officer & NRI Guarantee Note */}
            <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-2xl text-[11px] sm:text-xs text-amber-900 font-medium flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                {currentLang === 'te'
                  ? 'ప్రభుత్వ ఉద్యోగులు, ఉపాధ్యాయులు, రిటైర్డ్ అధికారులు & NRIలకు ప్రత్యేక లీగల్ పరిశీలన మరియు ఉచిత ఏసీ కార్ సైట్ విజిట్ సౌకర్యం.'
                  : 'Special Legal Document Verification & Free AC Car site visit provided for Government Officers, Teachers & NRI Families.'}
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <button
                onClick={onExploreVentures}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-6 py-3.5 rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2 text-sm"
              >
                <span>{t.exploreVenturesBtn}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onViewPlots}
                className="bg-navy-900 hover:bg-navy-950 text-white font-bold px-6 py-3.5 rounded-xl transition-all flex items-center gap-2 text-sm shadow-sm"
              >
                <Compass className="w-4 h-4 text-emerald-400" />
                <span>{t.viewPlotsBtn}</span>
              </button>

              <button
                onClick={onBookSiteVisit}
                className="border-2 border-emerald-600 text-emerald-800 hover:bg-emerald-50 font-extrabold px-5 py-3.5 rounded-xl transition-all flex items-center gap-2 text-sm"
              >
                <Calendar className="w-4 h-4 text-emerald-700" />
                <span>{t.bookSiteVisit}</span>
              </button>
            </div>

          </div>

          {/* Right Column: B.N Ventures Visual Card with Founder Highlight */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-2 border-navy-100 bg-white group">
              <img
                src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
                alt="B.N Ventures Golden County Layout"
                className="w-full h-[400px] object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/30 to-transparent"></div>

              {/* Floating Badge */}
              <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
                <span className="bg-white/95 backdrop-blur-md text-navy-900 text-xs font-black px-3.5 py-1.5 rounded-full shadow flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  B.N Ventures Master Layout
                </span>
                <span className="bg-emerald-600 text-white text-xs font-black px-3 py-1 rounded-full shadow">
                  10 Years Trust
                </span>
              </div>

              {/* Bottom Card Info */}
              <div className="absolute bottom-4 left-4 right-4 text-white space-y-2">
                <span className="text-xs uppercase tracking-widest text-emerald-300 font-extrabold">
                  {currentLang === 'te' ? 'ప్రతిష్టాత్మక వెంచర్' : 'FLAGSHIP VENTURE'}
                </span>
                <h3 className="font-display font-black text-2xl text-white">B.N Golden County</h3>
                <p className="text-slate-200 text-xs flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" /> Highway Corridor, Hyderabad
                </p>
                <div className="flex items-center gap-3 pt-2 text-xs">
                  <div className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-lg">
                    <strong>36</strong> {currentLang === 'te' ? 'ప్లాట్లు' : 'Plots'}
                  </div>
                  <div className="bg-emerald-500/80 backdrop-blur-sm px-3 py-1 rounded-lg font-bold">
                    {currentLang === 'te' ? 'బుకింగ్ ప్రారంభం' : 'Open for Booking'}
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Location Filter Ribbon (Requirement 1) */}
        <div className="mt-10 bg-white rounded-2xl p-4 sm:p-5 shadow-lg border border-navy-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            <span className="text-xs sm:text-sm font-extrabold text-navy-950 uppercase tracking-wider">
              {currentLang === 'te' ? 'ప్రాంతాన్ని బట్టి వెంచర్లు చూడండి:' : 'Select Location to Filter Ventures:'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onSelectLocation('')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                selectedLocation === '' 
                  ? 'bg-emerald-600 text-white shadow' 
                  : 'bg-slate-100 text-navy-800 hover:bg-slate-200'
              }`}
            >
              {t.allLocations}
            </button>

            {/* Nirmal District Primary Selection (User Requirement) */}
            <button
              onClick={() => onSelectLocation('Nirmal')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ${
                selectedLocation.toLowerCase() === 'nirmal'
                  ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-400' 
                  : 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100'
              }`}
            >
              <span>★ {currentLang === 'te' ? 'నిర్మల్ జిల్లా (504106)' : 'Nirmal Dist (504106)'}</span>
            </button>

            {uniqueCities
              .filter(city => city.toLowerCase() !== 'nirmal')
              .map((city) => (
                <button
                  key={city}
                  onClick={() => onSelectLocation(city)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selectedLocation.toLowerCase() === city.toLowerCase()
                      ? 'bg-emerald-600 text-white shadow' 
                      : 'bg-slate-100 text-navy-800 hover:bg-slate-200'
                  }`}
                >
                  {city}
                </button>
            ))}

            {/* Google Maps Explore Option (User Requirement) */}
            <button
              onClick={() => openInGoogleMaps(selectedLocation || 'Nirmal, 504106')}
              className="bg-amber-400 hover:bg-amber-500 text-navy-950 px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-sm border border-amber-300 ml-auto"
              title="Open currently selected location in Google Maps"
            >
              <Navigation className="w-3.5 h-3.5 fill-navy-950" />
              <span>{currentLang === 'te' ? 'గూగుల్ మ్యాప్స్' : 'Google Maps'}</span>
              <ExternalLink className="w-3 h-3 opacity-80" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
