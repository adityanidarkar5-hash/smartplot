import React, { useState, useRef } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Compass, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  Maximize2,
  TreePine,
  CheckCircle2,
  UserCheck,
  Layers,
  Navigation,
  ExternalLink
} from 'lucide-react';
import { Plot, PlotStatus, Language } from '../types';
import { translations } from '../i18n';
import { openInGoogleMaps } from '../utils/googleMaps';

interface InteractivePlotMapProps {
  plots: Plot[];
  selectedPlot: Plot | null;
  onSelectPlot: (plot: Plot) => void;
  ventureName?: string;
  currentLang?: Language;
  lang?: Language;
  layoutImageUrl?: string;
}

export const InteractivePlotMap: React.FC<InteractivePlotMapProps> = ({
  plots,
  selectedPlot,
  onSelectPlot,
  ventureName = 'B.N Golden County',
  currentLang = 'en',
  lang,
  layoutImageUrl,
}) => {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredPlot, setHoveredPlot] = useState<Plot | null>(null);
  const hasRightSectorPlots = plots.some(p => p.pos_x >= 730 && p.pos_y < 540);

  const containerRef = useRef<HTMLDivElement>(null);
  const activeLang = lang || currentLang || 'te';
  const t = translations[activeLang] || translations.en;

  // Requirement 5 Color System
  const getPlotFill = (status: PlotStatus) => {
    switch (status) {
      case 'available':
        return '#10b981'; // Green
      case 'pending':
        return '#f59e0b'; // Yellow / Orange
      case 'booked':
      case 'sold':
        return '#dc2626'; // Red
      case 'blocked':
        return '#111827'; // Dark Charcoal Black
      default:
        return '#64748b';
    }
  };

  const getPlotStroke = (status: PlotStatus, isSelected: boolean) => {
    if (isSelected) return '#3b82f6'; // Bright blue selection halo
    switch (status) {
      case 'available': return '#047857';
      case 'pending': return '#b45309';
      case 'booked':
      case 'sold': return '#991b1b';
      case 'blocked': return '#000000';
      default: return '#334155';
    }
  };

  // Zoom & Pan buttons designed specifically for elders
  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.25, 2.8));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.25, 0.65));
  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handlePan = (dx: number, dy: number) => {
    setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
  };

  // Mouse pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleMouseUp = () => setIsDragging(false);

  // Touch handlers for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({ x: e.touches[0].clientX - pan.x, y: e.touches[0].clientY - pan.y });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    setPan({ x: e.touches[0].clientX - dragStart.x, y: e.touches[0].clientY - dragStart.y });
  };

  const handleTouchEnd = () => setIsDragging(false);

  // Counts for the legend
  const availableCount = plots.filter(p => p.status === 'available').length;
  const pendingCount = plots.filter(p => p.status === 'pending').length;
  const bookedCount = plots.filter(p => p.status === 'booked' || p.status === 'sold').length;
  const blockedCount = plots.filter(p => p.status === 'blocked').length;

  return (
    <div 
      ref={containerRef}
      className="relative bg-slate-900 rounded-3xl overflow-hidden border-2 border-navy-800 shadow-2xl select-none w-full"
    >
      {/* Top Controls Overlay */}
      <div className="absolute top-4 left-4 right-4 z-20 flex flex-col gap-2 pointer-events-none">
        <div className="flex flex-wrap justify-between items-center gap-3">
          {/* Title Badge */}
          <div className="bg-slate-950/95 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-slate-700 pointer-events-auto shadow-lg flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Compass className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h4 className="text-white font-display font-extrabold text-sm sm:text-base tracking-wide flex items-center gap-2">
                <span>{ventureName} — {t.navPlots}</span>
                <span className="text-[10px] bg-red-600/90 text-white font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Vastu Compliant
                </span>
              </h4>
              <p className="text-slate-300 text-xs">
                {currentLang === 'te' 
                  ? 'దిశలు (తూర్పు, పడమర, ఉత్తరం, దక్షిణం) & ప్లాట్ల వివరాలు' 
                  : 'Cardinal Directions (East, West, North, South) & Plot Vastu Guide'}
              </p>
            </div>
          </div>

          {/* Elder-Friendly Big Navigation Controls (Zoom & Directions) */}
          <div className="flex items-center gap-1.5 bg-slate-950/95 backdrop-blur-md p-1.5 rounded-2xl border border-slate-700 pointer-events-auto shadow-xl">
            {/* Zoom Buttons with Large Bold Text */}
            <button 
              onClick={handleZoomIn}
              className="p-2.5 bg-slate-800 hover:bg-emerald-600 text-white rounded-xl transition flex items-center gap-1 font-bold text-xs"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
              <span className="hidden sm:inline">{t.zoomInBtn}</span>
            </button>

            <button 
              onClick={handleZoomOut}
              className="p-2.5 bg-slate-800 hover:bg-emerald-600 text-white rounded-xl transition flex items-center gap-1 font-bold text-xs"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
              <span className="hidden sm:inline">{t.zoomOutBtn}</span>
            </button>

            <button 
              onClick={handleReset}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition text-xs font-semibold flex items-center gap-1"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline">{t.resetBtn}</span>
            </button>

            {/* Google Maps Location Button */}
            <button
              onClick={() => openInGoogleMaps(ventureName)}
              className="p-2.5 bg-amber-400 hover:bg-amber-500 text-navy-950 rounded-xl transition flex items-center gap-1 font-black text-xs shadow-md border border-amber-300"
              title="Open venture location in Google Maps"
            >
              <Navigation className="w-3.5 h-3.5 fill-navy-950" />
              <span className="hidden sm:inline">Google Maps</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </button>

            {/* Directional Pad for Elders */}
            <div className="hidden md:flex items-center gap-1 border-l border-slate-700 pl-1.5">
              <button onClick={() => handlePan(0, 60)} className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg" title="Move Up">
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => handlePan(0, -60)} className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg" title="Move Down">
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => handlePan(60, 0)} className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg" title="Move Left">
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => handlePan(-60, 0)} className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg" title="Move Right">
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* High-Visibility Cardinal Directions Guide Ribbon */}
        <div className="flex flex-wrap items-center gap-2 pointer-events-auto">
          <div className="bg-slate-950/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700 text-xs text-white flex items-center gap-2.5 shadow-lg overflow-x-auto max-w-full">
            <span className="text-amber-400 font-extrabold flex items-center gap-1 shrink-0 text-[11px] uppercase tracking-wider">
              <Compass className="w-3.5 h-3.5" />
              {activeLang === 'te' ? 'దిశల గైడ్' : 'Directions'}:
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-red-950/80 border border-red-700/80 text-red-200 font-bold shrink-0 text-xs">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              ⬆ NORTH (ఉత్తరం)
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-amber-950/80 border border-amber-600/80 text-amber-200 font-bold shrink-0 text-xs">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              ➡ EAST (తూర్పు - వాస్తు శ్రేష్ఠం)
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-slate-800/90 border border-slate-600/80 text-slate-200 font-bold shrink-0 text-xs">
              <span className="w-2 h-2 rounded-full bg-slate-400" />
              ⬇ SOUTH (దక్షిణం)
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-slate-800/90 border border-slate-600/80 text-slate-200 font-bold shrink-0 text-xs">
              <span className="w-2 h-2 rounded-full bg-slate-400" />
              ⬅ WEST (పడమర)
            </span>
          </div>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div 
        className="w-full h-[540px] sm:h-[660px] cursor-grab active:cursor-grabbing overflow-hidden bg-[#0c1322] relative"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <svg
          viewBox="-50 -45 1120 810"
          className="w-full h-full"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out',
          }}
        >
          <defs>
            <pattern id="siteGridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.8" />
            </pattern>
            <pattern id="parkGrassPattern" width="20" height="20" patternUnits="userSpaceOnUse">
              <rect width="20" height="20" fill="#064e3b" />
              <circle cx="5" cy="5" r="1.5" fill="#047857" opacity="0.6" />
              <circle cx="15" cy="15" r="1.5" fill="#047857" opacity="0.6" />
            </pattern>
          </defs>

          {/* Background ground & boundary */}
          <rect x="-50" y="-45" width="1120" height="810" fill="#0b1120" />
          <rect x="-50" y="-45" width="1120" height="810" fill="url(#siteGridPattern)" />

          {/* Master Perimeter Boundary Wall */}
          <rect 
            x="30" y="30" width="960" height="660" 
            fill="none" stroke="#475569" strokeWidth="3.5" strokeDasharray="8,5" rx="16" 
          />

          {/* ------------------------------------------------------------- */}
          {/* CARDINAL DIRECTION BORDERS (North, South, East, West) */}
          {/* ------------------------------------------------------------- */}

          {/* NORTH BANNER (Top) */}
          <g id="borderNorth" transform="translate(510, -5)">
            <rect x="-190" y="-28" width="380" height="36" rx="10" fill="#dc2626" stroke="#fca5a5" strokeWidth="2.5" />
            <polygon points="0,-22 9,-10 3,-10 3,-2 -3,-2 -3,-10 -9,-10" fill="#ffffff" />
            <text x="0" y="3" fill="#ffffff" fontSize="13" fontWeight="900" textAnchor="middle" letterSpacing="1.5">
              ▲ NORTH / ఉత్తర దిశ (33 FT SECTOR ROAD) ▲
            </text>
          </g>

          {/* SOUTH BANNER (Bottom) */}
          <g id="borderSouth" transform="translate(510, 725)">
            <rect x="-210" y="-8" width="420" height="36" rx="10" fill="#1e293b" stroke="#64748b" strokeWidth="2.5" />
            <polygon points="0,22 9,10 3,10 3,2 -3,2 -3,10 -9,10" fill="#ffffff" />
            <text x="0" y="15" fill="#f8fafc" fontSize="13" fontWeight="900" textAnchor="middle" letterSpacing="1.5">
              ▼ SOUTH / దక్షిణ దిశ (33 FT ROAD & MAIN GATE) ▼
            </text>
          </g>

          {/* EAST BANNER (Right - Vastu Auspicious) */}
          <g id="borderEast" transform="translate(1025, 360)">
            <rect x="-18" y="-160" width="36" height="320" rx="10" fill="#92400e" stroke="#fbbf24" strokeWidth="2.5" />
            <text transform="rotate(90)" x="0" y="5" fill="#fef08a" fontSize="12" fontWeight="900" textAnchor="middle" letterSpacing="2">
              ▶ EAST / తూర్పు దిశ ★ వాస్తు శ్రేష్ఠం (GATE & PARK) ▶
            </text>
          </g>

          {/* WEST BANNER (Left) */}
          <g id="borderWest" transform="translate(-15, 360)">
            <rect x="-18" y="-140" width="36" height="280" rx="10" fill="#1e293b" stroke="#64748b" strokeWidth="2.5" />
            <text transform="rotate(-90)" x="0" y="5" fill="#e2e8f0" fontSize="12" fontWeight="900" textAnchor="middle" letterSpacing="2">
              ◀ WEST / పడమర దిశ (నివాస సరిహద్దు) ◀
            </text>
          </g>

          {/* ------------------------------------------------------------- */}
          {/* ROADS (Large, clear labels) */}
          {/* ------------------------------------------------------------- */}

          {/* Grand Entrance Road at Bottom */}
          <rect x="740" y="560" width="120" height="130" fill="#1e293b" />
          <line x1="800" y1="570" x2="800" y2="685" stroke="#ffffff" strokeWidth="2.5" strokeDasharray="10,8" />
          <text x="800" y="650" fill="#cbd5e1" fontSize="12" fontWeight="900" textAnchor="middle" transform="rotate(-90, 800, 650)">
            MAIN ENTRANCE 60 FT ROAD
          </text>

          {/* Central 40-Feet Main Boulevard */}
          <rect x="40" y="275" width="940" height="55" fill="#1e293b" rx="4" />
          <line x1="50" y1="302" x2="970" y2="302" stroke="#ffffff" strokeWidth="2.5" strokeDasharray="14,10" />
          <text x="500" y="308" fill="#f8fafc" fontSize="14" fontWeight="900" letterSpacing="4" textAnchor="middle">
            ★ 40 FEET MAIN BOULEVARD ROAD (40 అడుగుల తారు రోడ్డు) ★
          </text>

          {/* North 33-Feet Road */}
          <rect x="40" y="40" width="940" height="25" fill="#1e293b" rx="3" />
          <text x="500" y="57" fill="#94a3b8" fontSize="11" fontWeight="bold" letterSpacing="2" textAnchor="middle">
            33 FEET SECTOR ROAD (33 అడుగుల రోడ్డు)
          </text>

          {/* South 33-Feet Road */}
          <rect x="40" y="545" width="690" height="25" fill="#1e293b" rx="3" />
          <text x="380" y="562" fill="#94a3b8" fontSize="11" fontWeight="bold" letterSpacing="2" textAnchor="middle">
            33 FEET SECTOR ROAD (33 అడుగుల రోడ్డు)
          </text>

          {/* ------------------------------------------------------------- */}
          {/* AMENITIES ZONES (Smartly positioned away from plots) */}
          {/* ------------------------------------------------------------- */}

          {/* Central Park */}
          {!hasRightSectorPlots && (
            <g transform="translate(750, 70)">
              <rect width="190" height="200" fill="url(#parkGrassPattern)" rx="16" stroke="#059669" strokeWidth="2.5" />
              <text x="95" y="30" fill="#a7f3d0" fontSize="13" fontWeight="900" textAnchor="middle">
                CENTRAL PARK
              </text>
              <text x="95" y="48" fill="#6ee7b7" fontSize="10" fontWeight="bold" textAnchor="middle">
                ల్యాండ్‌స్కేప్డ్ పచ్చని పార్క్
              </text>

              {/* Trees */}
              <circle cx="40" cy="90" r="15" fill="#047857" />
              <circle cx="40" cy="90" r="9" fill="#10b981" />
              <circle cx="150" cy="90" r="15" fill="#047857" />
              <circle cx="150" cy="90" r="9" fill="#10b981" />
              <circle cx="95" cy="140" r="18" fill="#047857" />
              <circle cx="95" cy="140" r="11" fill="#10b981" />

              {/* Gazebo */}
              <rect x="80" y="75" width="32" height="32" fill="#f59e0b" rx="6" />
              <text x="96" y="95" fill="#78350f" fontSize="9" fontWeight="bold" textAnchor="middle">GAZEBO</text>
            </g>
          )}

          {/* Clubhouse & Children Zone */}
          {!hasRightSectorPlots && (
            <g transform="translate(750, 340)">
              <rect width="190" height="195" fill="#0f172a" rx="16" stroke="#3b82f6" strokeWidth="2.5" />
              <text x="95" y="30" fill="#93c5fd" fontSize="13" fontWeight="900" textAnchor="middle">
                CLUBHOUSE & POOL
              </text>
              <text x="95" y="48" fill="#60a5fa" fontSize="10" fontWeight="bold" textAnchor="middle">
                క్లబ్‌హౌస్ & ఆట స్థలం
              </text>

              {/* Swimming Pool */}
              <rect x="30" y="65" width="130" height="55" fill="#0284c7" rx="8" stroke="#38bdf8" strokeWidth="1.5" />
              <text x="95" y="96" fill="#ffffff" fontSize="11" fontWeight="900" textAnchor="middle">
                SWIMMING POOL
              </text>

              <rect x="30" y="130" width="130" height="45" fill="#334155" rx="6" />
              <text x="95" y="152" fill="#f8fafc" fontSize="10" fontWeight="bold" textAnchor="middle">
                CHILDREN PLAY AREA
              </text>
              <text x="95" y="166" fill="#94a3b8" fontSize="9" textAnchor="middle">
                పిల్లల ఆట స్థలం
              </text>
            </g>
          )}

          {/* Security Gate Arch */}
          {!hasRightSectorPlots && (
            <g transform="translate(720, 605)">
              <rect x="0" y="0" width="160" height="50" fill="#047857" rx="10" stroke="#10b981" strokeWidth="2.5" />
              <text x="80" y="24" fill="#ffffff" fontSize="12" fontWeight="900" textAnchor="middle">
                B.N SECURITY ARCH
              </text>
              <text x="80" y="40" fill="#d1fae5" fontSize="9" fontWeight="bold" textAnchor="middle">
                24/7 CCTV & RFID బూమ్ బారియర్
              </text>
            </g>
          )}

          {/* VASTU & CARDINAL COMPASS ROSE (Clear English & Telugu Directions) */}
          <g transform="translate(930, 615)" id="vastuCompassRose">
            {/* Outer dial ring */}
            <circle cx="0" cy="0" r="44" fill="#0a0f1d" stroke="#334155" strokeWidth="2.5" />
            <circle cx="0" cy="0" r="38" fill="none" stroke="#475569" strokeWidth="1" strokeDasharray="3,3" />

            {/* Cardinal 4 Points Diamonds */}
            {/* NORTH Needle (Crimson / Red) */}
            <polygon points="0,-35 7,-10 0,-14" fill="#ef4444" />
            <polygon points="0,-35 -7,-10 0,-14" fill="#b91c1c" />

            {/* SOUTH Needle (Silver / Gray) */}
            <polygon points="0,35 7,10 0,14" fill="#e2e8f0" />
            <polygon points="0,35 -7,10 0,14" fill="#94a3b8" />

            {/* EAST Needle (Golden Sun / Amber) */}
            <polygon points="35,0 10,7 14,0" fill="#f59e0b" />
            <polygon points="35,0 10,-7 14,0" fill="#d97706" />

            {/* WEST Needle (Dark Silver) */}
            <polygon points="-35,0 -10,7 -14,0" fill="#cbd5e1" />
            <polygon points="-35,0 -10,-7 -14,0" fill="#64748b" />

            {/* Center Vastu Medallion */}
            <circle cx="0" cy="0" r="14" fill="#0f172a" stroke="#f59e0b" strokeWidth="1.5" />
            <text x="0" y="-2" fill="#f59e0b" fontSize="6.5" fontWeight="900" textAnchor="middle">VASTU</text>
            <text x="0" y="6" fill="#fef08a" fontSize="6" fontWeight="bold" textAnchor="middle">వాస్తు</text>

            {/* North Label Badge */}
            <rect x="-18" y="-52" width="36" height="15" rx="4" fill="#dc2626" />
            <text x="0" y="-41.5" fill="#ffffff" fontSize="8" fontWeight="900" textAnchor="middle">N / ఉ</text>

            {/* East Label Badge */}
            <rect x="36" y="-7.5" width="36" height="15" rx="4" fill="#b45309" />
            <text x="54" y="3.5" fill="#fef08a" fontSize="8" fontWeight="900" textAnchor="middle">E / తూ</text>

            {/* South Label Badge */}
            <rect x="-18" y="37" width="36" height="15" rx="4" fill="#1e293b" />
            <text x="0" y="47.5" fill="#ffffff" fontSize="8" fontWeight="900" textAnchor="middle">S / ద</text>

            {/* West Label Badge */}
            <rect x="-72" y="-7.5" width="36" height="15" rx="4" fill="#334155" />
            <text x="-54" y="3.5" fill="#ffffff" fontSize="8" fontWeight="900" textAnchor="middle">W / ప</text>
          </g>

          {/* ------------------------------------------------------------- */}
          {/* PLOT RECTANGLES (Requirement 9 & 10: Big text + Owner Names) */}
          {/* ------------------------------------------------------------- */}
          {plots.map((plot) => {
            const isSelected = selectedPlot?.id === plot.id;
            const isHovered = hoveredPlot?.id === plot.id;
            const fill = getPlotFill(plot.status);
            const stroke = getPlotStroke(plot.status, isSelected || isHovered);
            const isBookedOrSold = plot.status === 'booked' || plot.status === 'sold';

            return (
              <g
                key={plot.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectPlot(plot);
                }}
                onMouseEnter={() => setHoveredPlot(plot)}
                onMouseLeave={() => setHoveredPlot(null)}
                className="cursor-pointer transition-all duration-150"
              >
                {/* Plot Body */}
                <rect
                  x={plot.pos_x}
                  y={plot.pos_y}
                  width={plot.width}
                  height={plot.height}
                  fill={fill}
                  fillOpacity={isSelected ? 1 : 0.92}
                  stroke={stroke}
                  strokeWidth={isSelected ? 4 : isHovered ? 3 : 2}
                  rx="6"
                  className={plot.status === 'pending' ? 'pulse-plot' : ''}
                />

                {/* Plot Number: Extra Large and Bold for Elders (Requirement 9) */}
                <text
                  x={plot.pos_x + plot.width / 2}
                  y={plot.pos_y + 24}
                  fill={plot.status === 'blocked' ? '#ffffff' : '#0f172a'}
                  fontSize="14"
                  fontWeight="900"
                  textAnchor="middle"
                  pointerEvents="none"
                >
                  {plot.plot_number}
                </text>

                {/* Plot Area & Cardinal Direction */}
                <text
                  x={plot.pos_x + plot.width / 2}
                  y={plot.pos_y + 40}
                  fill={plot.status === 'blocked' ? '#e2e8f0' : '#1e293b'}
                  fontSize="10.5"
                  fontWeight="bold"
                  textAnchor="middle"
                  pointerEvents="none"
                >
                  {plot.area_sqyd} yd² • {plot.facing === 'East' ? 'తూ' : plot.facing === 'North' ? 'ఉ' : plot.facing === 'West' ? 'ప' : 'ద'} ({plot.facing[0]})
                </text>

                {/* Corner Badge */}
                {plot.is_corner === 1 && (
                  <g transform={`translate(${plot.pos_x + plot.width - 18}, ${plot.pos_y + 4})`}>
                    <circle cx="7" cy="7" r="7" fill="#f59e0b" stroke="#78350f" strokeWidth="1" />
                    <text x="7" y="10.5" fill="#78350f" fontSize="8" fontWeight="900" textAnchor="middle">C</text>
                  </g>
                )}

                {/* Requirement 10: DISPLAY OWNER NAME ON BOOKED / SOLD / PENDING PLOT */}
                {plot.owner_name ? (
                  <g>
                    {/* Owner Name Label Banner */}
                    <rect
                      x={plot.pos_x + 4}
                      y={plot.pos_y + plot.height - 34}
                      width={plot.width - 8}
                      height="28"
                      fill="#000000"
                      fillOpacity="0.75"
                      rx="4"
                    />
                    <text
                      x={plot.pos_x + plot.width / 2}
                      y={plot.pos_y + plot.height - 20}
                      fill="#fef08a"
                      fontSize="9.5"
                      fontWeight="900"
                      textAnchor="middle"
                      pointerEvents="none"
                    >
                      {plot.owner_name.length > 10 ? plot.owner_name.substring(0, 9) + '..' : plot.owner_name}
                    </text>
                    <text
                      x={plot.pos_x + plot.width / 2}
                      y={plot.pos_y + plot.height - 9}
                      fill="#ffffff"
                      fontSize="8"
                      fontWeight="bold"
                      textAnchor="middle"
                      pointerEvents="none"
                    >
                      {isBookedOrSold ? 'OWNER' : 'RESERVED'}
                    </text>
                  </g>
                ) : (
                  /* Price Banner for Available Plots */
                  <g>
                    <rect
                      x={plot.pos_x + 4}
                      y={plot.pos_y + plot.height - 22}
                      width={plot.width - 8}
                      height="17"
                      fill="#000000"
                      fillOpacity="0.5"
                      rx="3"
                    />
                    <text
                      x={plot.pos_x + plot.width / 2}
                      y={plot.pos_y + plot.height - 10}
                      fill="#ffffff"
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                      pointerEvents="none"
                    >
                      {plot.status === 'available' 
                        ? `₹${(plot.total_price / 100000).toFixed(1)}L` 
                        : plot.status.toUpperCase()}
                    </text>
                  </g>
                )}

                {/* Selection Highlight */}
                {isSelected && (
                  <rect
                    x={plot.pos_x - 4}
                    y={plot.pos_y - 4}
                    width={plot.width + 8}
                    height={plot.height + 8}
                    fill="none"
                    stroke="#60a5fa"
                    strokeWidth="3"
                    strokeDasharray="5,2"
                    rx="8"
                  />
                )}
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip Overlay */}
        {hoveredPlot && (
          <div 
            className="absolute z-30 pointer-events-none bg-slate-950/98 backdrop-blur-md text-white p-3.5 rounded-2xl border-2 border-emerald-500 shadow-2xl text-xs space-y-1.5"
            style={{
              left: Math.min(hoveredPlot.pos_x * zoom + pan.x + 20, 720),
              top: Math.max(hoveredPlot.pos_y * zoom + pan.y - 40, 20),
            }}
          >
            <div className="flex items-center justify-between gap-4 font-black border-b border-slate-800 pb-1.5">
              <span className="text-emerald-400 font-display text-base">
                Plot {hoveredPlot.plot_number}
              </span>
              <span 
                className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase"
                style={{
                  backgroundColor: getPlotFill(hoveredPlot.status),
                  color: hoveredPlot.status === 'blocked' ? '#ffffff' : '#0f172a'
                }}
              >
                {hoveredPlot.status}
              </span>
            </div>

            {/* Display Owner Name prominently if booked */}
            {hoveredPlot.owner_name && (
              <div className="bg-amber-500/20 border border-amber-400/40 p-2 rounded-xl text-amber-200 font-bold flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>
                  {t.bookedByLabel}: <strong className="text-white">{hoveredPlot.owner_name}</strong>
                </span>
              </div>
            )}

            <div className="space-y-1.5 text-slate-300">
              <div className="bg-amber-950/40 border border-amber-500/40 px-2.5 py-1 rounded-xl text-amber-200">
                <span className="text-[10px] uppercase font-bold tracking-wider block text-amber-400">
                  {currentLang === 'te' ? 'దిశ (వాస్తు ఫేసింగ్)' : 'Cardinal Facing'}:
                </span>
                <strong className="text-white text-xs">
                  {hoveredPlot.facing === 'East' ? '🌅 EAST / తూర్పు దిశ (వాస్తు శ్రేష్ఠం)' 
                    : hoveredPlot.facing === 'North' ? '🧭 NORTH / ఉత్తర దిశ (ధన వాస్తు శుభప్రదం)' 
                    : hoveredPlot.facing === 'West' ? '🏡 WEST / పడమర దిశ' 
                    : '🏛️ SOUTH / దక్షిణ దిశ'}
                </strong>
              </div>

              <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                <span>{currentLang === 'te' ? 'విస్తీర్ణం' : 'Area'}: <strong className="text-white">{hoveredPlot.area_sqyd} sq.yd</strong></span>
                <span>{currentLang === 'te' ? 'కొలతలు' : 'Size'}: <strong className="text-white">{hoveredPlot.dimension_length}' × {hoveredPlot.dimension_width}'</strong></span>
                <span>{currentLang === 'te' ? 'రోడ్డు వెడల్పు' : 'Road'}: <strong className="text-white">{hoveredPlot.road_width_ft} ft</strong></span>
                <span>{currentLang === 'te' ? 'ప్లాట్ రకం' : 'Type'}: <strong className="text-white">{hoveredPlot.is_corner === 1 ? 'Corner' : 'Regular'}</strong></span>
              </div>
            </div>

            <div className="pt-1 text-emerald-400 font-extrabold text-sm flex justify-between items-center border-t border-slate-800">
              <span>₹{hoveredPlot.total_price.toLocaleString('en-IN')}</span>
              {hoveredPlot.is_corner === 1 && <span className="text-amber-400 text-xs">★ Corner Plot</span>}
            </div>
          </div>
        )}
      </div>

      {/* Visible Status Legend (Requirement 9 & 10) */}
      <div className="bg-slate-950 border-t-2 border-slate-800 p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 text-xs sm:text-sm">
          
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <span className="font-extrabold text-slate-300 uppercase tracking-wider text-xs">
              {t.legendTitle}
            </span>

            {/* GREEN: Available */}
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-md bg-[#10b981] border border-[#047857] shadow-sm"></span>
              <span className="text-white font-bold">{t.statusAvailable}</span>
              <span className="bg-emerald-950 text-emerald-400 font-black px-2.5 py-0.5 rounded-full border border-emerald-800 text-xs">
                {availableCount}
              </span>
            </div>

            {/* YELLOW/ORANGE: Pending */}
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-md bg-[#f59e0b] border border-[#b45309] shadow-sm animate-pulse"></span>
              <span className="text-white font-bold">{t.statusPending}</span>
              <span className="bg-amber-950 text-amber-400 font-black px-2.5 py-0.5 rounded-full border border-amber-800 text-xs">
                {pendingCount}
              </span>
            </div>

            {/* RED: Booked / Sold with Owner Name */}
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-md bg-[#dc2626] border border-[#991b1b] shadow-sm"></span>
              <span className="text-white font-bold">{t.statusBooked} ({t.ownerNameLabel})</span>
              <span className="bg-red-950 text-red-400 font-black px-2.5 py-0.5 rounded-full border border-red-800 text-xs">
                {bookedCount}
              </span>
            </div>

            {/* BLACK: Blocked */}
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-md bg-[#111827] border border-[#475569] shadow-sm"></span>
              <span className="text-white font-bold">{t.statusBlocked}</span>
              <span className="bg-slate-900 text-slate-400 font-black px-2.5 py-0.5 rounded-full border border-slate-700 text-xs">
                {blockedCount}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-400 italic">
            * B.N Ventures Master Layout Plan. All plots DTCP/RERA certified.
          </p>

        </div>
      </div>
    </div>
  );
};
