import React from 'react';
import { TrendingUp, ShieldCheck, Award, Users, CheckCircle2, Building2, ArrowRight, PhoneCall } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface InvestInFeatureProps {
  currentLang: Language;
  onBookSiteVisit: () => void;
}

export const InvestInFeature: React.FC<InvestInFeatureProps> = ({ currentLang, onBookSiteVisit }) => {
  const t = translations[currentLang];

  return (
    <section className="py-16 sm:py-24 bg-gradient-to-b from-white via-emerald-50/40 to-slate-50 border-t border-navy-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3.5 py-1 rounded-full border border-emerald-300">
            <TrendingUp className="w-4 h-4 text-emerald-700" /> {t.investTitle}
          </div>

          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-navy-950 tracking-tight leading-tight">
            {t.investSubtitle}
          </h2>

          <p className="text-navy-600 text-sm sm:text-base leading-relaxed">
            {currentLang === 'te' 
              ? 'రియల్ ఎస్టేట్ రంగంలో 10 సంవత్సరాల నిజాయితీ గల అనుభవంతో B.N వెంచర్స్ అభివృద్ధి చేసిన లేఅవుట్లు మీ పిల్లల భవిష్యత్తుకు మరియు పదవీ విరమణ పొందిన ఉద్యోగులకు రక్షణ కవచం లాంటివి.'
              : 'Backed by 10 years of direct real estate experience and 5 landmark delivered ventures, B.N Ventures provides the safest asset allocation for retired officers, families, and smart investors.'}
          </p>
        </div>

        {/* 3 Major Pillars of "Invest in Feature" */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Feature 1 */}
          <div className="bg-white rounded-3xl p-8 border border-navy-100 shadow-sm hover:shadow-xl transition-all space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xl shadow-inner">
                <TrendingUp className="w-7 h-7" />
              </div>
              <h3 className="font-display font-extrabold text-xl text-navy-950">
                {t.investPoint1Title}
              </h3>
              <p className="text-xs sm:text-sm text-navy-600 leading-relaxed">
                {t.investPoint1Desc}
              </p>
            </div>
            <div className="pt-4 border-t border-navy-100 text-xs font-bold text-emerald-700 flex items-center gap-1">
              <span>{currentLang === 'te' ? 'హైవే వద్ద త్వరిత విలువ పెరుగుదల' : 'Strategic Growth Corridors'}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
          </div>

          {/* Feature 2 */}
          <div className="bg-white rounded-3xl p-8 border border-navy-100 shadow-sm hover:shadow-xl transition-all space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xl shadow-inner">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <h3 className="font-display font-extrabold text-xl text-navy-950">
                {t.investPoint2Title}
              </h3>
              <p className="text-xs sm:text-sm text-navy-600 leading-relaxed">
                {t.investPoint2Desc}
              </p>
            </div>
            <div className="pt-4 border-t border-navy-100 text-xs font-bold text-emerald-700 flex items-center gap-1">
              <span>{currentLang === 'te' ? '100% వివాదాలు లేని లీగల్ టైటిల్' : 'Zero Legal Encumbrance'}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
          </div>

          {/* Feature 3 */}
          <div className="bg-white rounded-3xl p-8 border border-navy-100 shadow-sm hover:shadow-xl transition-all space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xl shadow-inner">
                <Building2 className="w-7 h-7" />
              </div>
              <h3 className="font-display font-extrabold text-xl text-navy-950">
                {t.investPoint3Title}
              </h3>
              <p className="text-xs sm:text-sm text-navy-600 leading-relaxed">
                {t.investPoint3Desc}
              </p>
            </div>
            <div className="pt-4 border-t border-navy-100 text-xs font-bold text-emerald-700 flex items-center gap-1">
              <span>{currentLang === 'te' ? 'స్పాట్ రిజిస్ట్రేషన్ & స్వాధీనం' : 'Immediate Construction Ready'}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
          </div>

        </div>

        {/* Call to Action Box inside Invest Section */}
        <div className="bg-navy-950 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl border border-navy-800 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl text-center md:text-left">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950 px-3 py-1 rounded-full border border-emerald-800">
              {currentLang === 'te' ? '10 సంవత్సరాల నిజాయితీ భరోసా' : '10 Years of Proven Integrity'}
            </span>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-white">
              {currentLang === 'te' 
                ? 'నేరుగా వెంచర్‌ను పరిశీలించండి — ఉచిత రవాణా సదుపాయం' 
                : 'Inspect the Venture in Person with Free Transport'}
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm">
              {currentLang === 'te'
                ? 'మా వాహనంలో వచ్చి ప్లాట్ సరిహద్దులు, రోడ్లు, వాస్తు చూసి మీ పేరు మీద ప్లాట్ నమోదు చేసుకోండి.'
                : 'Experience the layout roads, amenities, and exact plot boundaries with our senior land advisor.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
            <button
              onClick={onBookSiteVisit}
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm py-4 px-8 rounded-2xl shadow-xl transition flex items-center justify-center gap-2"
            >
              <span>{t.bookSiteVisit}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href="tel:+919876543210"
              className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-sm py-4 px-6 rounded-2xl transition flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <span>{t.directCall}</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
